"""Start one worker process per GPU (or several per GPU) on this machine / pod.

  python launch.py                          # all visible GPUs; workers per GPU chosen from its VRAM
  python launch.py --gpus 0 1 2 3 --workers-per-gpu 1 --cpus 11
  python launch.py --workers-per-gpu 8      # e.g. 1 x B300 (275 GB): workers share it under a VRAM budget (default 12)
  python launch.py --kinds prepare coverage sizes survival --gpus none --workers 4   # CPU-only jobs

Several pods (Kubeflow) can run launch.py at the same time against the same --results and
cache directories on a shared volume: jobs are claimed by atomic rename, so each job runs once.
Workers exit when the queue is empty. Logs: results/logs/<job>.log and results/workers/*.log.
"""
import argparse
import os
import subprocess
import sys
import time


def detect_gpus():
    """[(index, total MiB)] of the visible GPUs."""
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.total", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, check=True).stdout
        res = []
        for l in out.splitlines():
            if l.strip():
                i, m = [x.strip() for x in l.split(",")]
                res.append((i, float(m)))
        return res
    except Exception:
        return []


def memory_limit_gb():
    """Container (cgroup v2 / v1) memory limit, else physical RAM, in GB."""
    phys = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30
    for f in ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
        try:
            v = open(f).read().strip()
            if v != "max" and int(v) < phys * 2**30:
                return int(v) / 2**30, f
        except (OSError, ValueError):
            pass
    return phys, "physical RAM"


def auto_workers_per_gpu(mib):
    gb = mib / 1024
    if gb >= 160:
        return 12         # B200 / B300 / GB200 class (GNN jobs use only a few GB each)
    if gb >= 70:
        return 2          # H100 / A100 80 GB
    return 1


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gpus", nargs="+", default=None, help="GPU indices, or 'none' for CPU-only workers")
    ap.add_argument("--workers-per-gpu", type=int, default=None,
                    help="default: 12 on >=160 GB GPUs, 2 on >=70 GB, else 1")
    ap.add_argument("--max-loader-workers", type=int, default=8, help="cap on DataLoader workers per job")
    ap.add_argument("--ram-gb", type=float, default=None,
                    help="host RAM the workers may use (default: 70%% of the container memory limit)")
    ap.add_argument("--vram-reserve-gb", type=float, default=10.0, help="VRAM kept free per GPU (driver, context)")
    ap.add_argument("--workers", type=int, default=None, help="number of CPU-only workers (with --gpus none)")
    ap.add_argument("--cpus", type=int, default=os.cpu_count(), help="CPU cores to share among the workers")
    ap.add_argument("--results", default="results")
    ap.add_argument("--kinds", nargs="+", default=None)
    args = ap.parse_args()

    if args.gpus == ["none"]:
        slots = [None] * (args.workers or 1)
    else:
        found = dict(detect_gpus())
        gpus = args.gpus or list(found)
        if not gpus:
            sys.exit("no GPU found; use --gpus none --workers N for CPU-only jobs")
        mib = {g: found.get(g, 40960.0) for g in gpus}
        wpg = {g: args.workers_per_gpu or auto_workers_per_gpu(mib[g]) for g in gpus}
        slots = [g for g in gpus for _ in range(wpg[g])]
    n = len(slots)
    lim, src = memory_limit_gb()
    ram_gb = args.ram_gb or 0.70 * lim
    print(f"host memory limit {lim:.0f} GB ({src}) -> RAM budget {ram_gb:.0f} GB for {n} workers")
    threads = max(1, args.cpus // n)
    loader_workers = max(1, min(threads - 1, args.max_loader_workers))
    os.makedirs(os.path.join(args.results, "workers"), exist_ok=True)
    import glob
    import socket
    for f in glob.glob(os.path.join(args.results, "queue", "vram_gpu*.json")) + \
            [os.path.join(args.results, "queue", f"budget_{socket.gethostname()}.json")]:
        if os.path.exists(f):                              # fresh ledger for this host
            os.remove(f)
    procs = []
    for i, g in enumerate(slots):
        env = dict(os.environ, SYMDIG_THREADS=str(threads), SYMDIG_NUM_WORKERS=str(loader_workers),
                   OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", PYTHONUNBUFFERED="1")
        if n > 1:
            env["SYMDIG_RAM_CAPACITY_GB"] = f"{ram_gb:.1f}"
        env["CUDA_VISIBLE_DEVICES"] = "" if g is None else str(g)
        if g is not None and wpg[g] > 1:       # shared GPU -> VRAM admission control
            env["SYMDIG_GPU_ID"] = str(g)
            env["SYMDIG_GPU_CAPACITY_GB"] = f"{mib[g] / 1024 - args.vram_reserve_gb:.1f}"
            env.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
        cmd = [sys.executable, "run.py", "worker", "--results", args.results]
        if args.kinds:
            cmd += ["--kinds", *args.kinds]
        log = open(os.path.join(args.results, "workers", f"worker{i}_gpu{g}.log"), "a")
        procs.append((subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT), log))
        print(f"worker {i}: GPU {g}, {threads} threads, {loader_workers} sampling workers"
              + (f", VRAM budget {env['SYMDIG_GPU_CAPACITY_GB']} GB shared by {wpg[g]} workers"
                 if g is not None and wpg[g] > 1 else ""))
        time.sleep(2)  # stagger start-up (first jobs read the same files)
    try:
        while any(p.poll() is None for p, _ in procs):
            time.sleep(30)
    except KeyboardInterrupt:
        for p, _ in procs:
            p.terminate()
    for p, log in procs:
        log.close()
    print("all workers finished; `python run.py status` for a summary")


if __name__ == "__main__":
    main()
