"""Numpy-side checks for the host-invariant (HINT) pipeline: split p1H, per-host normalisation,
tabular runs with host-normalised features, planner. (The torch parts: scripts/check_hint.py.)

    python tests/test_hint_numpy.py
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from test_numpy_side import cfg_for_tests  # noqa: E402
from symdig.data import NetFlowData, get_split  # noqa: E402
from symdig.hostnorm import host_recall, host_stats, make_stores  # noqa: E402
from symdig.tabular import run_tabular  # noqa: E402


def main():
    cfg = cfg_for_tests()
    data = NetFlowData(cfg, "ton")
    src_ip, _ = data.ip_arrays()
    y = data.y
    b = get_split(cfg, data, "p1B")
    h = get_split(cfg, data, "p1H")
    assert np.array_equal(np.sort(b.test), np.sort(h.test)), "p1H must reuse the p1B test set"
    assert len(np.intersect1d(h.train, h.val)) == 0 and len(np.intersect1d(h.train, h.test)) == 0
    excl = set(h.meta["val_host_split"]["excluded_classes"]) | set(h.meta.get("excluded_classes", []))
    att = lambda ids: set(src_ip[ids][(y[ids] != 0) & ~np.isin(y[ids], list(excl))].tolist())
    assert not (att(h.train) & att(h.val)), "validation attackers must not appear in training"
    assert not (att(h.train) & att(h.test)), "test attackers must not appear in training"
    print(f"p1H ok: train {len(h.train):,} | val {len(h.val):,} (attacker-disjoint) | test {len(h.test):,} (= p1B)")

    base, _ = make_stores(cfg, data, h, "none")
    m, s, cnt = host_stats(data, base, h.graph_train, k0=0.0)
    st_tr, st_te = make_stores(cfg, data, h, "both", k0=0.0)
    X = st_tr.gather(h.graph_train)
    D = base.dim
    assert X.shape[1] == 2 * D
    hn, srcs = X[:, D:], data.src[h.graph_train]
    big = np.flatnonzero(cnt > 500)[:3]
    for node in big:
        mu = hn[srcs == node].mean(0)
        assert np.abs(mu).max() < 1e-3, f"host-normalised features of host {node} must have mean 0 ({np.abs(mu).max()})"
    print(f"host normalisation ok: dim {D} -> {X.shape[1]}; per-host mean of normalised part = 0 on {len(big)} hosts")

    r = host_recall(np.array([0, 1, 1, 1, 2, 2]), np.array([0, 1, 0, 1, 2, 2]), np.array([5, 7, 7, 7, 9, 9]), min_flows=2)
    assert abs(r["min"] - 2 / 3) < 1e-9 and r["n_hosts"] == 2

    for feat in ("plain", "hostnorm"):
        res, _, _ = run_tabular(cfg, data, h, "xgboost", {"n_estimators": 30, "max_depth": 4}, 0, log=lambda *a: None,
                                features=feat)
        print(f"tabular {feat:9s}: test macro-F1 {res['metrics']['macro_f1']:.3f} | features {len(res['features'])} | "
              f"host recall {res['host_recall']}")

    from symdig.jobs import load_config, job_id
    from symdig.planner import Planner
    from collections import Counter
    c2 = load_config("configs/default.yaml")
    sp = {job_id(s): s for s in Planner(c2, None, None, cfg_hash="test").plan(["HP"])}
    print("planner HP:", dict(Counter(s["kind"] for s in sp.values())))
    print("ALL HINT NUMPY-SIDE TESTS PASSED")


if __name__ == "__main__":
    main()
