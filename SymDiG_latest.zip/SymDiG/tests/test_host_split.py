"""Attacker-disjoint split v3: every splittable class keeps data from >= 1 source host on each side,
also when attacker machines run several attack classes (the case that broke v1); the validation
draw never empties a class's training part (the case that broke v2); token hosts do not count.

    python tests/test_host_split.py
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symdig.data import host_split_v1, host_split_v3  # noqa: E402


def make_shared(seed=0):
    """IDS2018-like layout: a few attacker machines shared by most classes, one class with many
    hosts, one class with a single host, plus benign traffic from many hosts."""
    rng = np.random.default_rng(seed)
    y, src = [], []
    def add(c, ips, n, weights=None):
        w = np.ones(len(ips)) if weights is None else np.asarray(weights, float)
        y.extend([c] * n)
        src.extend(rng.choice(ips, n, p=w / w.sum()).tolist())
    add(0, np.arange(1000, 3000), 200_000)                                  # benign
    add(1, np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), 50_000)               # DDoS, 10 hosts
    add(2, np.array([1, 2, 3, 4]), 20_000)                                  # DoS, 4 shared hosts
    add(3, np.array([5, 6, 7, 8, 9, 10, 11, 12, 13, 14]), 8_000)            # Bot
    add(4, np.array([1, 11]), 6_000, weights=[0.97, 0.03])                  # BruteForce, 2 hosts, one giant
    add(5, np.arange(100, 700), 5_000)                                      # Infiltration, many hosts
    add(6, np.array([20, 1, 2, 3, 4, 12]), 3_000, weights=[0.95, .01, .01, .01, .01, .01])  # Web: 1 giant + 5 small shared
    add(7, np.array([42]), 400)                                             # single-host class
    return np.array(y), np.array(src, np.int64)


def per_class(y, src, train, test):
    out = {}
    for c in np.unique(y):
        if c == 0:
            continue
        m = y == c
        out[int(c)] = (len(np.unique(src[train][y[train] == c])), len(np.unique(src[test][y[test] == c])),
                       int((y[train] == c).sum()), int((y[test] == c).sum()))
    return out


def check(y, src, ts=0.25, seed=42):
    tr, te, meta = host_split_v3(y, src, ts, np.random.default_rng(seed))
    assert len(np.intersect1d(tr, te)) == 0
    assert meta["attack_ip_overlap"] == 0, "a test attacker initiates an attack flow in training"
    pc = per_class(y, src, tr, te)
    for c, (h_tr, h_te, f_tr, f_te) in pc.items():
        if c in meta["excluded_classes"]:
            assert f_te == 0, f"excluded class {c} must not be in test"
            continue
        assert h_tr >= 1 and h_te >= 1 and f_tr > 0 and f_te > 0, f"class {c}: {pc[c]}"
    return tr, te, meta, pc


def ton_like():
    """Validation draw on a training part where (a) Ransomware has a giant host G and a small host
    s, and s is the only host of MITM; (b) Scanning has 3 big and 22 small hosts; (c) a class with
    one real host and three 1-flow token hosts."""
    rng = np.random.default_rng(5)
    y, src = [], []
    def add(c, ips, n, w=None):
        w = np.ones(len(ips)) if w is None else np.asarray(w, float)
        y.extend([c] * n)
        src.extend(rng.choice(ips, n, p=w / w.sum()).tolist())
    add(0, np.arange(1000, 2000), 100_000)
    add(1, np.arange(1, 26), 60_000, [8, 8, 8] + [1] * 22)      # Scanning
    add(2, np.array([30, 31]), 2_000, [0.95, 0.05])            # Ransomware: G=30, s=31
    add(3, np.array([31]), 1_500)                              # MITM: only host 31
    add(4, np.array([40, 41, 42]), 3_000)                      # Password, shares hosts with Scanning? no
    y += [5] * 5000 + [5, 5, 5]
    src += [50] * 5000 + [1, 2, 3]                             # token hosts 1, 2, 3 (one flow each)
    y, src = np.array(y), np.array(src, np.int64)
    tr, va, m = host_split_v3(y, src, 0.1, np.random.default_rng(0), role="val")
    pc = per_class(y, src, tr, va)
    print("validation draw (role=val):", {c: v for c, v in pc.items()}, "| unsatisfied", m["unsatisfied_classes"])
    assert pc[2][2] >= 1_800, "Ransomware must keep its giant host in training"
    assert pc[3][2] == 1_500, "MITM (single host) must keep all its training flows"
    assert 2 in m["unsatisfied_classes"], "Ransomware should simply have no validation host"
    assert 2 <= pc[1][1] <= 6, f"Scanning should give validation a few hosts, got {pc[1][1]}"
    assert 5 in m["excluded_classes"] and pc[5][2] >= 5_000, "token hosts must not make a class splittable"
    tr, te, m = host_split_v3(y, src, 0.25, np.random.default_rng(0), role="test")
    pc = per_class(y, src, tr, te)
    print("test draw (role=test):", {c: v for c, v in pc.items()}, "| excluded", m["excluded_classes"])
    assert pc[1][1] >= 3, f"Scanning should keep several test hosts, got {pc[1][1]}"


def main():
    y, src = make_shared()
    _, _, m1 = host_split_v1(y, src, 0.25, np.random.default_rng(42))
    broken = [c for c, v in m1["per_class"].items() if c != "0" and not v["excluded"]
              and v["test_src_ips"] >= v["src_ips"]]
    print(f"v1: classes with every host in test (no training flow): {broken}")
    assert broken, "the synthetic layout should reproduce the v1 failure"

    tr, te, meta, pc = check(y, src)
    print(f"v3: excluded {meta['excluded_classes']} unsatisfied {meta['unsatisfied_classes']} "
          f"| {meta['n_multi_class_attacker_ips']} of {meta['n_attacker_ips']} attacker IPs run >= 2 classes")
    for c, (h_tr, h_te, f_tr, f_te) in pc.items():
        print(f"  class {c}: hosts train/test {h_tr}/{h_te}, flows train/test {f_tr:,}/{f_te:,} "
              f"(test {100 * f_te / max(f_tr + f_te, 1):.0f}%)")
    assert 7 in meta["excluded_classes"] and pc[7][2] > 0, "single-host class stays in training"
    # BruteForce: the giant host must stay in training (test share ~3%, not ~97%)
    assert pc[4][3] < pc[4][2], "the giant BruteForce host should be a training host"
    # p1H-style second call on the training part (validation hosts)
    tr_loc, va_loc, vm = host_split_v3(y[tr], src[tr], 0.1, np.random.default_rng(1), role="val")
    assert vm["attack_ip_overlap"] == 0
    vpc = per_class(y[tr], src[tr], tr_loc, va_loc)
    for c, (h_tr, h_va, f_tr, f_va) in vpc.items():
        assert f_tr > 0, f"validation split removed every training flow of class {c}"
    # deterministic for a fixed seed
    tr2, te2, _ = host_split_v3(y, src, 0.25, np.random.default_rng(42))
    assert np.array_equal(tr, tr2) and np.array_equal(te, te2)
    # all classes from the same 4 machines (UNSW-like)
    rng = np.random.default_rng(3)
    yu = np.concatenate([np.zeros(50_000, int), rng.integers(1, 10, 20_000)])
    su = np.concatenate([rng.integers(1000, 1500, 50_000), rng.integers(1, 5, 20_000)])
    _, _, mu, pcu = check(yu, su)
    print(f"UNSW-like: test hosts per class {sorted(set(v[1] for v in pcu.values()))}, "
          f"train hosts per class {sorted(set(v[0] for v in pcu.values()))}")
    # many attacker IPs (spoofed sources): search runs on the largest, the rest is random
    ys = np.concatenate([np.zeros(30_000, int), np.ones(60_000, int), np.full(5_000, 2)])
    ss = np.concatenate([rng.integers(0, 3000, 30_000), rng.integers(10_000, 40_000, 60_000), rng.integers(1, 6, 5_000)])
    check(ys, ss)
    ton_like()
    print("\nOK")


if __name__ == "__main__":
    main()
