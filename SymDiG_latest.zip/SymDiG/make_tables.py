"""All result tables (Markdown summary + LaTeX tabular bodies) from results/runs/.

  python make_tables.py [--results results]
  -> results/tables/summary.md and results/tables/E*.tex
Numbers are mean ± std over seeds (macro-F1 in %, full test set unless stated).
"""
import argparse
import os

import numpy as np

from symdig.report import (DS_ORDER, DS_SHORT, MODEL_NAMES, RUNG_NAMES, load_runs, macro, mstat, paired_test,
                           select)


class Out:
    def __init__(self, d):
        self.d, self.md = d, ["# SymDiG results (auto-generated)\n"]

    def table(self, name, title, header, rows, note=None):
        if not rows:
            return
        self.md.append(f"\n## {title}\n")
        self.md.append("| " + " | ".join(header) + " |")
        self.md.append("|" + "---|" * len(header))
        for r in rows:
            self.md.append("| " + " | ".join(str(x) for x in r) + " |")
        if note:
            self.md.append(f"\n{note}\n")
        tex = [" & ".join(header) + r" \\", r"\midrule"]
        tex += [" & ".join(str(x).replace("±", r"$\pm$").replace("%", r"\%") for x in r) + r" \\" for r in rows]
        with open(os.path.join(self.d, f"{name}.tex"), "w") as fh:
            fh.write("\n".join(tex) + "\n")

    def save(self):
        with open(os.path.join(self.d, "summary.md"), "w") as fh:
            fh.write("\n".join(self.md) + "\n")


def present_ds(runs):
    s = {r["spec"]["dataset"] for r in runs}
    return [d for d in DS_ORDER if d in s]


def e1(R, O):
    rows = []
    for r in sorted(select(R, kind="coverage"), key=lambda r: (DS_ORDER.index(r["spec"]["dataset"])
                                                               if r["spec"]["dataset"] in DS_ORDER else 9,
                                                               r["spec"]["fanout"][0])):
        x = r["result"]
        rows.append([DS_SHORT.get(r["spec"]["dataset"], r["spec"]["dataset"]), str(r["spec"]["fanout"]),
                     f"{100 * x['multignn']['seed_coverage']:.1f}", f"{100 * x['multignn']['twin_coverage']:.1f}",
                     f"{100 * x['asym_forced']['twin_coverage']:.1f}", f"{x['multignn']['edges_per_batch']:.0f}",
                     f"{x['coupled_forced']['edges_per_batch']:.0f}"])
    O.table("E1_coverage", "E1 — Sampler diagnosis on the training graph (no training)",
            ["Dataset", "Fan-out", "Seed coverage, Multi-GNN (%)", "Twin coverage, Multi-GNN (%)",
             "Twin coverage, forced (%)", "Edges/batch Multi-GNN", "Edges/batch coupled"], rows,
            "Seed coverage = share of training targets that enter the computation graph and receive a loss. "
            "Twin coverage = share of sampled forward edges whose reverse twin is also sampled.")
    rows = []
    for d in present_ds(select(R, kind="gnn", preset="multignn_paper")):
        rs = select(R, kind="gnn", preset="multignn_paper", dataset=d)
        rows.append([DS_SHORT.get(d, d), mstat(macro(rs, "metrics_covered"))[2], mstat(macro(rs))[2],
                     mstat([r["result"].get("train_seed_coverage") for r in rs])[2],
                     mstat([r["result"].get("test_seed_coverage") for r in rs])[2], len(rs)])
    O.table("E1_multignn", "E1 — Multi-GNN with its released hyper-parameters (fan-out 100)",
            ["Dataset", "Macro-F1 on sampled test targets (as the original code reports)",
             "Macro-F1 on 100% of test targets", "Train seed coverage (%)", "Test seed coverage (%)", "Seeds"], rows)


def e2(R, O, exp_datasets=None):
    G = select(R, kind="gnn", split="p1A", task="multi")
    lad = [r for r in G if str(r["spec"].get("model", "")).startswith("ladder") and not r["spec"].get("preset")
           and not r["spec"]["dataset"].startswith("motif")]
    dss = present_ds(lad)
    if not lad:
        return
    rows, by = [], {}
    for k in range(5):
        row = [RUNG_NAMES[k]]
        for d in dss:
            rs = [r for r in lad if r["spec"]["dataset"] == d and r["spec"]["model"] == f"ladder{k}"]
            by[(k, d)] = rs
            row.append(mstat(macro(rs))[2])
        rows.append(row)
    for k in range(1, 5):
        row = [f"Δ ({k}) vs ({k - 1}) [p]"]
        for d in dss:
            m, p, n = paired_test(by.get((k - 1, d), []), by.get((k, d), []))
            row.append("--" if m is None else f"{m:+.2f} [{p:.3f}]")
        rows.append(row)
    rows.append(["(0) on sampled targets only"] + [mstat(macro(by.get((0, d), []), "metrics_covered"))[2] for d in dss])
    rows.append(["(0) test seed coverage (%)"] + [mstat([r["result"].get("test_seed_coverage") for r in by.get((0, d), [])])[2]
                                                  for d in dss])
    rows.append(["val macro-F1 of (4)"] + [mstat([((r["result"].get("val_metrics") or {}).get("macro_f1")
                                                    if r["result"].get("val_metrics") else r["result"].get("val_best_macro_f1"))
                                                   for r in by.get((4, d), [])])[2] for d in dss])
    reev = all(r["result"].get("reevaluated") for k in range(5) for d in dss for r in by.get((k, d), []))
    O.table("E2_ladder", "E2 — Ablation ladder (macro-F1 %, full test set, mean ± std over seeds)" +
            ("" if reev else " — NOTE: some runs not re-evaluated (run `plan R1`)"),
            ["Rung"] + [DS_SHORT[d] for d in dss], rows,
            "Each rung changes one factor with respect to the previous one; same backbone and hyper-parameters. "
            "p = two-sided sign-flip permutation test over paired seeds (minimum attainable p = 2/2^n).")
    # per-class, ToN-like
    for d in dss:
        r2, r4 = by.get((2, d), []), by.get((4, d), [])
        if not r2 or not r4:
            continue
        classes = r4[0]["result"]["classes"]
        rows = []
        for c in classes:
            sup = r4[0]["result"]["metrics"]["per_class"][c]["support"]
            f = lambda rs: mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2]
            rows.append([c, f"{sup:,}", f(by.get((0, d), [])), f(r2), f(r4)])
        O.table(f"E2_perclass_{d}", f"E2 — Per-class F1 on {DS_SHORT[d]} (rungs 0, 2, 4)",
                ["Class", "Test support", "(0) Multi-GNN pipeline", "(2) coupled, per-layer mean", "(4) SymDiG"], rows)


def e3(R, O):
    S = sorted(select(R, kind="survival"), key=lambda r: r["result"].get("multiplicity") or 0)
    rows = [[r["result"]["multiplicity"], f"{r['result']['asym_strict']:.3f} / {r['result']['pred_asym_strict']:.3f}",
             f"{r['result']['asym_fwd']:.3f} / {r['result']['pred_asym_fwd']:.3f}",
             f"{r['result']['coupled']:.3f} / {r['result']['pred_coupled']:.3f}", r["result"]["n"]] for r in S]
    O.table("E3_survival", "E3 — Probability that a planted cycle survives sampling (empirical / predicted)",
            ["Multiplicity M", "Asymmetric, both relations", "Asymmetric, forward only", "Coupled", "Instances"], rows)
    G = [r for r in select(R, kind="gnn") if r["spec"]["dataset"].startswith("motif")]
    Ms = sorted({int(r["spec"]["dataset"].split("_m")[1]) for r in G})
    if not G:
        return
    rows = []
    for k in range(5):
        row = [RUNG_NAMES[k]]
        for M in Ms:
            rs = [r for r in G if r["spec"]["dataset"] == f"motif_m{M}" and r["spec"]["model"] == f"ladder{k}"]
            row.append(mstat(macro(rs))[2])
        rows.append(row)
    O.table("E3_ladder", "E3 — Macro-F1 (%) on structure-only motif labels vs multiplicity",
            ["Rung"] + [f"M={M}" for M in Ms], rows)
    classes = ["FanIn", "FanOut", "Cycle", "ScatterGather"]
    rows = []
    for M in Ms:
        for k in (2, 3, 4):
            rs = [r for r in G if r["spec"]["dataset"] == f"motif_m{M}" and r["spec"]["model"] == f"ladder{k}"]
            if rs:
                rows.append([M, RUNG_NAMES[k]] + [mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2]
                                                  for c in classes])
    O.table("E3_perclass", "E3 — Per-motif F1 (%): does late fusion lose mixed-direction motifs?",
            ["M", "Rung"] + classes, rows)


def model_rows(R, split, models, dss, ports=True):
    rows = []
    for m in models:
        row = [MODEL_NAMES.get(m, m)]
        any_ = False
        for d in dss:
            rs = select(R, split=split, model=m, dataset=d, task="multi")
            rs = [r for r in rs if r["spec"]["kind"] in ("gnn", "tabular", "fecograph") and
                  (r["spec"]["kind"] == "fecograph" or (r.get("cfg") or {}).get("data", {}).get("ports", True) == ports)]
            any_ |= bool(rs)
            row.append(mstat(macro(rs))[2])
        if any_:
            rows.append(row)
    return rows


def b0(R, O):
    rows = []
    B = [r for r in R if r["spec"]["kind"] == "tabular" and "B0" in r["spec"].get("exps", [r["spec"].get("exp")])
         and not r["spec"].get("tuned")]
    dss = present_ds(B)
    for m in ("xgboost", "mlp"):
        rows.append([MODEL_NAMES[m] + " (untuned)"] +
                    [mstat(macro([r for r in B if r["spec"]["model"] == m and r["spec"]["dataset"] == d]))[2] for d in dss])
    lad = [r for r in select(R, kind="gnn", split="p1A", model="ladder4") if not r["spec"].get("preset")]
    rows.append(["SymDiG, rung 4 (untuned, E2)"] + [mstat(macro([r for r in lad if r["spec"]["dataset"] == d]))[2] for d in dss])
    O.table("B0_quick", "B0 — Untuned per-flow baselines vs the E2 GNN (split p1A, macro-F1 %)",
            ["Model"] + [DS_SHORT[d] for d in dss], rows if dss else [])
    # per-class on ToN-like datasets
    for d in dss:
        xs = [r for r in B if r["spec"]["model"] == "xgboost" and r["spec"]["dataset"] == d]
        ms = [r for r in B if r["spec"]["model"] == "mlp" and r["spec"]["dataset"] == d]
        gs = [r for r in lad if r["spec"]["dataset"] == d]
        if not xs or not gs:
            continue
        rows = []
        for c in xs[0]["result"]["classes"]:
            f = lambda rs: mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2] if rs else "--"
            rows.append([c, f(xs), f(ms), f(gs)])
        O.table(f"B0_perclass_{d}", f"B0 — Per-class F1 on {DS_SHORT[d]}", ["Class", "XGBoost", "MLP", "SymDiG rung 4"], rows)


def e4(R, O, cfg_models):
    dss = present_ds(select(R, split="p1A"))
    O.table("E4_main", "E4 — All models in one frame (split p1A, tuned, macro-F1 %)",
            ["Model"] + [DS_SHORT[d] for d in dss], model_rows(R, "p1A", cfg_models, dss))
    O.table("E4_noports", "E4 — Without port features",
            ["Model"] + [DS_SHORT[d] for d in dss], model_rows(R, "p1A", ["xgboost", "symdig"], dss, ports=False))
    d2 = present_ds(select(R, split="p2"))
    O.table("E4_p2", "E4 — FeCoGraph protocol p2 (2% subsample, 30% labeled), same split for all",
            ["Model"] + [DS_SHORT[d] for d in d2],
            model_rows(R, "p2", ["xgboost", "rf", "egsage", "symdig", "fecograph"], d2))
    for d in dss:
        a = select(R, split="p1A", model="symdig", dataset=d, task="multi", ports=True)
        b = select(R, split="p1A", model="xgboost", dataset=d, task="multi", ports=True)
        c0 = select(R, split="p1A", model="multignn", dataset=d, task="multi", ports=True)
        if not a or not b:
            continue
        rows = []
        for c in a[0]["result"]["classes"]:
            f = lambda rs: mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2] if rs else "--"
            rows.append([c, f"{a[0]['result']['metrics']['per_class'][c]['support']:,}", f(b), f(c0), f(a)])
        O.table(f"E4_perclass_{d}", f"E4 — Per-class F1 on {DS_SHORT[d]}: where does the graph help?",
                ["Class", "Test support", "XGBoost", "Multi-GNN", "SymDiG"], rows)


def e5(R, O):
    dss = present_ds(select(R, split="p1B"))
    rows = []
    for m in ("symdig", "multignn", "xgboost", "mlp"):
        for d in dss:
            a = select(R, split="p1A", model=m, dataset=d, task="multi", ports=True)
            b = select(R, split="p1B", model=m, dataset=d, task="multi", ports=True)
            b = [r for r in b if r["spec"]["kind"] in ("gnn", "tabular")]
            if not b:
                continue
            ma, mb = mstat(macro(a)), mstat(macro(b))
            excl = b[0]["result"].get("split_meta", {}).get("excluded_classes")
            rows.append([MODEL_NAMES.get(m, m), DS_SHORT[d], ma[2], mb[2],
                         "--" if ma[0] is None or mb[0] is None else f"{mb[0] - ma[0]:+.2f}", excl if excl else "-"])
    O.table("E5_host", "E5 — Random split (p1A) vs attacker-disjoint split (p1B), macro-F1 %",
            ["Model", "Dataset", "p1A", "p1B", "Δ", "Classes excluded in p1B"], rows,
            "p1B macro-F1 is computed over the classes that could be split by attacker source IP.")
    T = select(R, kind="transfer")
    if T:
        rows = []
        for m in sorted({r["spec"]["model"] for r in T}):
            for src in DS_ORDER:
                row = [MODEL_NAMES.get(m, m), DS_SHORT[src]]
                ok = False
                for tgt in DS_ORDER:
                    rs = [r for r in T if r["spec"]["model"] == m and r["spec"]["source"] == src and r["spec"]["dataset"] == tgt]
                    ok |= bool(rs)
                    row.append("—" if src == tgt else mstat(macro(rs))[2])
                if ok:
                    rows.append(row)
        O.table("E5_transfer", "E5 — Cross-dataset binary transfer (train on row, test on column), macro-F1 %",
                ["Model", "Train on"] + [DS_SHORT[d] for d in DS_ORDER], rows)


def e6(R, O):
    rows = []
    for r in select(R, kind="sizes"):
        for f, x in sorted(r["result"].items(), key=lambda kv: float(kv[0])):
            rows.append([DS_SHORT.get(r["spec"]["dataset"], r["spec"]["dataset"]), f"{float(f) * 100:g}%", f"{x['flows']:,}",
                         f"{x['ip_nodes']:,}", f"{x['ipport_nodes']:,}", f"{x['line_graph_edges_ipport']:.3g}"])
    O.table("E6_sizes", "E6 — Graph sizes on the same flows",
            ["Dataset", "Share of flows", "Flows (= edges)", "Nodes, IP-centric", "Nodes, IP:PORT",
             "Line-graph edges (IP:PORT hosts)"], rows)
    rows = []
    for r in sorted(select(R, kind="deploy"), key=lambda r: (r["spec"]["dataset"], r["spec"]["model"],
                                                             r["spec"].get("frac", 1), str(r["spec"].get("mem_cap_gb")))):
        x = r["result"]
        if x.get("status") != "ok":
            rows.append([DS_SHORT.get(r["spec"]["dataset"]), MODEL_NAMES.get(r["spec"]["model"]), x.get("frac"),
                         x.get("mem_cap_gb") or "40", x.get("status"), "", "", "", ""])
            continue
        tr = x["train"]
        inf = x.get(f"infer_bs{8192}") or next((v for k, v in x.items() if k.startswith("infer_bs")), {})
        rows.append([DS_SHORT.get(r["spec"]["dataset"]), MODEL_NAMES.get(r["spec"]["model"]), x.get("frac"),
                     x.get("mem_cap_gb") or "40", "ok", f"{tr.get('peak_vram_gb') or 0:.2f}",
                     f"{tr.get('targets_per_sec') or 0:,.0f}", f"{inf.get('flows_per_sec_end_to_end', 0):,.0f}",
                     f"{inf.get('gpu_ms_p95', 0):.1f}"])
    O.table("E6_deploy", "E6 — Training and inference cost on one A100",
            ["Dataset", "Model", "Share of flows", "Memory cap (GB)", "Status", "Train peak VRAM (GB)",
             "Train targets/s", "Inference flows/s (end-to-end)", "Inference p95 GPU ms/batch"], rows)


def e7(R, O):
    E = select(R, kind="evasion")
    if not E:
        return
    rows = []
    for m in sorted({r["spec"]["model"] for r in E}):
        rs = [r for r in E if r["spec"]["model"] == m]
        strats = rs[0]["result"]["results"].keys()
        for s in strats:
            ks = sorted(rs[0]["result"]["results"][s].keys(), key=int)
            rows.append([MODEL_NAMES.get(m, m), s] + [mstat([r["result"]["results"][s][k]["mean_f1"] for r in rs])[2] for k in ks])
    ks = sorted(E[0]["result"]["results"][next(iter(E[0]["result"]["results"]))].keys(), key=int)
    O.table("E7_evasion", f"E7 — Mean F1 (%) of the attacked classes {E[0]['result']['attacked']} under injection",
            ["Model", "Strategy"] + [f"K={k}" for k in ks], rows,
            "XGBoost and the MLP score each flow independently, so injected chaff cannot change their predictions "
            "on the attack flows; compare with their clean per-class F1 in E4.")


def e8(R, O):
    H = select(R, kind="hybrid")
    if not H:
        return
    names = ["xgb_full", "xgb", "xgb+stats", "xgb+prob", "xgb+hid", "xgb+prob+hid", "xgb+stats+prob+hid"]
    label = {"xgb_full": "XGBoost, full train (reference)", "xgb": "XGBoost, half B (control)",
             "xgb+stats": "+ graph statistics", "xgb+prob": "+ GNN probabilities", "xgb+hid": "+ GNN hidden layer",
             "xgb+prob+hid": "+ GNN prob. + hidden", "xgb+stats+prob+hid": "+ statistics + GNN prob. + hidden"}
    for split in ("p1A", "p1B"):
        Hs = [r for r in H if r["spec"]["split"] == split]
        dss = present_ds(Hs)
        if not dss:
            continue
        rows = []
        for n in names:
            rows.append([label[n]] + [mstat([r["result"]["variants"][n]["metrics"]["macro_f1"]
                                             for r in Hs if r["spec"]["dataset"] == d])[2] for d in dss])
        rows.append(["GNN alone (half A)"] + [mstat([r["result"]["gnn_half_a"]["metrics"]["macro_f1"]
                                                     for r in Hs if r["spec"]["dataset"] == d])[2] for d in dss])
        rows.append(["Δ (+ GNN prob. + hidden) vs control [p]"] +
                    [_pair(Hs, d, "xgb", "xgb+prob+hid") for d in dss])
        rows.append(["Δ (+ graph statistics) vs control [p]"] + [_pair(Hs, d, "xgb", "xgb+stats") for d in dss])
        O.table(f"E8_{split}", f"E8 — Graph context as XGBoost features, split {split} (macro-F1 %)",
                ["Variant"] + [DS_SHORT[d] for d in dss], rows,
                "All variants except the reference are trained on the same half B of the training targets; "
                "GNN features come from a GNN trained on the disjoint half A (out-of-sample).")
        for d in dss:
            rs = [r for r in Hs if r["spec"]["dataset"] == d]
            classes = rs[0]["result"]["classes"]
            f = lambda n, c: mstat([r["result"]["variants"][n]["metrics"]["per_class"][c]["f1"] for r in rs])[2]
            rows = [[c, f("xgb", c), f("xgb+stats", c), f("xgb+prob+hid", c), f("xgb+stats+prob+hid", c)] for c in classes]
            O.table(f"E8_perclass_{d}_{split}", f"E8 — Per-class F1 on {DS_SHORT[d]}, split {split}",
                    ["Class", "XGBoost (B)", "+ statistics", "+ GNN prob. + hidden", "+ all"], rows)


def t1(R, O):
    T = [r for r in select(R, exp="T1", kind="gnn") if r.get("result")]
    if not T:
        return
    be = lambda r: ((r["spec"].get("overrides") or {}).get("sampler.backend"))
    base = [r for r in select(R, exp="E2", kind="gnn", model="ladder1") if r.get("result")]
    dss = present_ds(T)
    groups = [("(1) native sampler (E2, re-evaluated)", base), ("(1) TargetEdgeLoader as written", [r for r in T if be(r) == "tel_orig"]),
              ("(1) TargetEdgeLoader + CSC-permutation fix", [r for r in T if be(r) == "tel_fixed"])]
    rows = [[n] + [mstat(macro([r for r in g if r["spec"]["dataset"] == d]))[2] for d in dss] for n, g in groups]
    for n, g in groups[1:]:
        cells = []
        for d in dss:
            m, p, k = paired_test([r for r in base if r["spec"]["dataset"] == d], [r for r in g if r["spec"]["dataset"] == d])
            cells.append("--" if m is None else f"{m:+.2f} [{p:.2f}, n={k}]")
        rows.append([f"Δ {n[4:]} vs native [p]"] + cells)
    O.table("T1", "T1 — The TargetEdgeLoader as the sampler of rung 1 (macro-F1 %, full test set)",
            ["Sampler"] + [DS_SHORT[d] for d in dss], rows,
            "Same features, split, batch size, model (hetero, to_hetero-style mean), loss and evaluation as E2; "
            "only the subgraph sampler differs. All targets are present in every batch for all three samplers.")
    C = [r for r in select(R, exp="T1", kind="coverage") if r.get("result")]
    rows = []
    for r in sorted(C, key=lambda r: (DS_ORDER.index(r["spec"]["dataset"]) if r["spec"]["dataset"] in DS_ORDER else 99, be(r))):
        x = r["result"][be(r)]
        rows.append([DS_SHORT.get(r["spec"]["dataset"], r["spec"]["dataset"]), be(r), f"{100 * x['seed_coverage']:.1f}",
                     f"{100 * x['twin_coverage']:.1f}", f"{100 * x.get('tel_consistency', float('nan')):.1f}",
                     f"{x['edges_per_batch']:,.0f}"])
    O.table("T1_sampler", "T1 — Sampler diagnostics (training graph, p1A)",
            ["Dataset", "Backend", "Target coverage %", "Twin coverage %", "Edge consistency %", "Edges / batch"], rows,
            "Edge consistency = share of sampled edges whose two endpoints are both sampled nodes "
            "(100 % for a correct neighbour sampler).")


def variant_shift_classes(results, min_unseen=0.5):
    """dataset -> classes whose test flows are mostly an unseen sub-attack (scripts/host_variant_report.py)."""
    import glob as _glob
    import json as _json
    out = {}
    for f in _glob.glob(os.path.join(results, "variants", "*.json")):
        z = _json.load(open(f))
        out[os.path.basename(f)[:-5]] = {c for c, v in z["classes"].items()
                                          if v.get("unseen_frac") is not None and v["unseen_frac"] >= min_unseen}
    return out


def h(R, O):
    """Host-invariant NIDS (experiments H / HP)."""
    H = [r for r in R if r["spec"].get("exp") == "H" and r.get("result")]
    if not H:
        return
    def runs(kind, split="p1H", **kw):
        out = []
        for r in H:
            sp = r["spec"]
            if sp["kind"] != kind or sp.get("split") != split:
                continue
            if all(sp.get(k) == v for k, v in kw.items()):
                out.append(r)
        return out
    rows_def = [("XGBoost", ("tabular", {"model": "xgboost", "features": "plain"})),
                ("XGBoost + host norm.", ("tabular", {"model": "xgboost", "features": "hostnorm"})),
                ("MLP", ("tabular", {"model": "mlp", "features": "plain"})),
                ("MLP + host norm.", ("tabular", {"model": "mlp", "features": "hostnorm"})),
                ("GNN, sampler fix (no HINT)", ("hint", {"model": "gnn_plain"})),
                ("Flow net (no HINT)", ("hint", {"model": "flow_plain"})),
                ("HINT-flow (MLP)", ("hint", {"model": "hint_flow"})),
                ("HINT-flow (FT-Transformer)", ("hint", {"model": "hint_flow_ftt"})),
                ("HINT-flow, host-relative only, no DRO", ("hint", {"model": "hint_flow_rel"})),
                ("HINT-GNN", ("hint", {"model": "hint_gnn"})),
                ("HINT-GNN − GroupDRO", ("hint", {"model": "hint_gnn_nodro"})),
                ("HINT-GNN, host-relative only, no DRO", ("hint", {"model": "hint_gnn_rel"}))]
    dss = present_ds(runs("hint") + runs("tabular"))
    f1 = lambda rs: mstat([r["result"]["metrics"]["macro_f1"] for r in rs])
    by = {name: {d: runs(k, **dict(kw, dataset=d)) for d in dss} for name, (k, kw) in rows_def}
    rows = [[name] + [f1(by[name][d])[2] for d in dss] for name, _ in rows_def if any(by[name][d] for d in dss)]
    def delta(a_name, b_name, d):
        m, p, n = paired_test(by[a_name][d], by[b_name][d])
        return "--" if m is None else f"{m:+.2f} [{p:.2f}]"
    base_names = ["XGBoost", "XGBoost + host norm.", "MLP", "MLP + host norm.", "GNN, sampler fix (no HINT)"]
    best_cells = []
    for d in dss:
        cand = [(f1(by[b][d])[0], b) for b in base_names if by[b][d]]
        if cand and by["HINT-GNN"][d]:
            best = max(cand)[1]
            best_cells.append(f"{delta(best, 'HINT-GNN', d)} vs {best}")
        else:
            best_cells.append("--")
    rows.append(["Δ HINT-GNN vs best baseline [p]"] + best_cells)
    hint_names = [n for n in ("HINT-flow (MLP)", "HINT-flow (FT-Transformer)", "HINT-flow, host-relative only, no DRO",
                              "HINT-GNN", "HINT-GNN − GroupDRO", "HINT-GNN, host-relative only, no DRO")
                  if any(by[n][d] for d in dss)]
    cells = []
    for d in dss:
        cand = [(f1(by[b][d])[0], b) for b in base_names if by[b][d]]
        hc = [(f1(by[n][d])[0], n) for n in hint_names if by[n][d]]
        cells.append("--" if not (cand and hc) else f"{delta(max(cand)[1], max(hc)[1], d)} ({max(hc)[1]} vs {max(cand)[1]})")
    rows.append(["Δ best HINT variant vs best baseline [p]"] + cells)
    rows.append(["Δ HINT-GNN vs XGBoost + host norm. [p] (H3)"] + [delta("XGBoost + host norm.", "HINT-GNN", d) for d in dss])
    O.table("H_main", "H — Generalisation to unseen attackers (split p1H, macro-F1 %)", ["Model"] + [DS_SHORT[d] for d in dss],
            rows, "p1H = the p1B test set (attacker source IPs disjoint from training) with an attacker-disjoint "
                  "validation set used for tuning and model selection.")

    # same, without the classes whose test flows are mostly a sub-attack never seen in training
    # (written by scripts/host_variant_report.py): host shift only, no variant shift
    vshift = variant_shift_classes(os.path.dirname(O.d))
    if any(vshift.get(d) for d in dss):
        def mf1_sub(r, drop):
            pc = r["result"]["metrics"]["per_class"]
            v = [x["f1"] for c, x in pc.items() if x.get("support", 0) > 0 and c not in drop]
            return float(np.mean(v)) if v else None
        f1s = lambda rs, d: mstat([mf1_sub(r, vshift.get(d, set())) for r in rs])
        rows = [[name] + [f1s(by[name][d], d)[2] for d in dss] for name, _ in rows_def if any(by[name][d] for d in dss)]
        cells = []
        for d in dss:
            cand = [(f1s(by[b][d], d)[0], b) for b in base_names if by[b][d]]
            hc = [(f1s(by[n][d], d)[0], n) for n in hint_names if by[n][d]]
            if not (cand and hc):
                cells.append("--")
                continue
            bb, hh = max(cand)[1], max(hc)[1]
            cells.append(f"{max(hc)[0] - max(cand)[0]:+.2f} ({hh} vs {bb})")
        rows.append(["Δ best HINT variant vs best baseline"] + cells)
        O.table("H_main_hostshift", "H — Host shift only: macro-F1 % without variant-shift classes (split p1H)",
                ["Model"] + [DS_SHORT[d] for d in dss], rows,
                "Left out: " + "; ".join(f"{DS_SHORT[d]}: {', '.join(sorted(vshift[d]))}" for d in dss if vshift.get(d))
                + " (test flows are mostly a sub-attack that never occurs in training).")

    abl = [("HINT-GNN (full)", "hint_gnn"), ("− host normalisation", "hint_gnn_nohn"), ("− host adversary", "hint_gnn_noadv"),
           ("− GroupDRO", "hint_gnn_nodro"), ("host-relative only, − GroupDRO", "hint_gnn_rel"), ("− graph (HINT-flow)", "hint_flow"), ("all off (GNN, sampler fix)", "gnn_plain")]
    A = {lab: {d: runs("hint", model=v, dataset=d) for d in dss} for lab, v in abl}
    rows = [[lab] + [f1(A[lab][d])[2] for d in dss] for lab, _ in abl if any(A[lab][d] for d in dss)]
    for lab, _ in abl[1:]:
        cells = []
        for d in dss:
            m, p, n = paired_test(A["HINT-GNN (full)"][d], A[lab][d])
            cells.append("--" if m is None else f"{m:+.2f} [{p:.2f}]")
        rows.append([f"Δ {lab} [p]"] + cells)
    O.table("H_ablation", "H — Ablation of HINT-GNN (split p1H, macro-F1 %)", ["Variant"] + [DS_SHORT[d] for d in dss], rows)

    pc_cols = [n for n in ("XGBoost", "MLP + host norm.", "GNN, sampler fix (no HINT)", "HINT-flow (MLP)",
                           "HINT-GNN", "HINT-GNN − GroupDRO")
               if any(by[n][d] for d in dss)]
    for d in dss:
        any_r = next((by[n][d][0] for n in pc_cols if by[n][d]), None)
        if any_r is None:
            continue
        tr_counts = (any_r["result"].get("split_meta") or {}).get("train_class_counts")
        rows = []
        for i, c in enumerate(any_r["result"]["metrics"]["per_class"]):
            cell = lambda rs: mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2] if rs else "--"
            rows.append([c, f"{tr_counts[i]:,}" if tr_counts else "--"] + [cell(by[n][d]) for n in pc_cols])
        O.table(f"H_perclass_{d}", f"H — Per-class F1 on {DS_SHORT[d]}, split p1H (%)",
                ["Class", "Train flows"] + pc_cols, rows)

    def probe(rs, key):
        return mstat([((r["result"].get(key) or {}).get("acc")) for r in rs])[2]
    prow = [("Input: global features", "gnn_plain", "probe_input"), ("Input: global + host-normalised", "hint_gnn", "probe_input"),
            ("Representation: GNN (no HINT)", "gnn_plain", "probe_hid"), ("Representation: HINT-GNN", "hint_gnn", "probe_hid"),
            ("Representation: flow net (no HINT)", "flow_plain", "probe_hid"), ("Representation: HINT-flow", "hint_flow", "probe_hid")]
    rows = [[lab] + [probe(runs("hint", model=v, dataset=d), key) for d in dss] for lab, v, key in prow]
    rows.append(["Majority host (chance level)"] + [mstat([((r["result"].get("probe_hid") or {}).get("majority"))
                                                           for r in runs("hint", model="gnn_plain", dataset=d)])[2] for d in dss])
    O.table("H_probe", "H — How well can the source host be read off? (linear probe accuracy %, held-out flows)",
            ["Probe on"] + [DS_SHORT[d] for d in dss], rows,
            "Lower is better for invariance. Hosts = the K source hosts with most training flows.")

    hr = [("XGBoost", "tabular", {"model": "xgboost", "features": "plain"}), ("XGBoost + host norm.", "tabular", {"model": "xgboost", "features": "hostnorm"}),
          ("GNN, sampler fix (no HINT)", "hint", {"model": "gnn_plain"}), ("HINT-flow (MLP)", "hint", {"model": "hint_flow"}),
          ("HINT-GNN", "hint", {"model": "hint_gnn"})]
    q = lambda rs, k: mstat([((r["result"].get("host_recall") or {}).get(k)) for r in rs])[2]
    rows = [[lab] + [f"{q(runs(k, **dict(kw, dataset=d)), 'p10')} / {q(runs(k, **dict(kw, dataset=d)), 'median')}" for d in dss]
            for lab, k, kw in hr]
    O.table("H_hosts", "H — Recall on the attack flows of individual unseen attackers (p10 / median over hosts, %)",
            ["Model"] + [DS_SHORT[d] for d in dss], rows, "Attacking source hosts with at least 50 test attack flows.")

    rows = []
    for lab, v in (("GNN, sampler fix (no HINT)", "gnn_plain"), ("HINT-GNN", "hint_gnn")):
        rows.append([lab] + [f1(runs("hint", split="p1A", model=v, dataset=d))[2] for d in dss])
    cells = []
    for d in dss:
        m, p, n = paired_test(runs("hint", split="p1A", model="gnn_plain", dataset=d), runs("hint", split="p1A", model="hint_gnn", dataset=d))
        cells.append("--" if m is None else f"{m:+.2f} [{p:.2f}]")
    rows.append(["Δ HINT-GNN vs GNN [p]"] + cells)
    O.table("H_p1A", "H — Cost on the random split (p1A, macro-F1 %)", ["Model"] + [DS_SHORT[d] for d in dss], rows)

    L = runs("hint", model="hint_gnn_lambda")
    if L:
        rows = []
        for lam in sorted({r["spec"]["sweep_lambda"] for r in L}):
            rs = [r for r in L if r["spec"]["sweep_lambda"] == lam]
            rows.append([f"{lam:g}", f1(rs)[2], probe(rs, "probe_hid")])
        O.table("H_lambda", f"H — Adversary strength on {DS_SHORT.get(L[0]['spec']['dataset'], '')} (split p1H)",
                ["λ", "macro-F1 %", "host probe acc. %"], rows)


def _pair(rs, d, a, b):
    import numpy as _np
    xs = {r["spec"]["seed"]: r["result"]["variants"] for r in rs if r["spec"]["dataset"] == d}
    diffs = [100 * (v[b]["metrics"]["macro_f1"] - v[a]["metrics"]["macro_f1"]) for v in xs.values()]
    if not diffs:
        return "--"
    n = len(diffs)
    signs = _np.array([[1 if (i >> j) & 1 else -1 for j in range(n)] for i in range(2 ** n)])
    p = float((_np.abs((signs * _np.array(diffs)).mean(1)) >= abs(_np.mean(diffs)) - 1e-12).mean())
    return f"{_np.mean(diffs):+.2f} [{p:.2f}]"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    a = ap.parse_args()
    R = load_runs(a.results)
    d = os.path.join(a.results, "tables")
    os.makedirs(d, exist_ok=True)
    O = Out(d)
    models = ["xgboost", "rf", "mlp", "egsage", "dirgnn", "multignn", "multignn_fixed", "symdig"]
    for f in (e1, e2, b0, e3, lambda R, O: e4(R, O, models), e5, e6, e7, e8, t1, h):
        try:
            f(R, O)
        except Exception as ex:  # partial results are normal while experiments are running
            O.md.append(f"\n(skipped a table: {type(ex).__name__}: {ex})\n")
    O.save()
    print("\n".join(O.md))
    print(f"\nwrote {d}/summary.md and {d}/*.tex")


if __name__ == "__main__":
    main()
