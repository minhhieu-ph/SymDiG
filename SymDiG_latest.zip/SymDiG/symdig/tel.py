"""T1: run the user's TargetEdgeLoader (symdig/target_edge_loader.py, unmodified) inside the SymDiG
pipeline. Everything else -- edge features, splits, batch size, model, loss, evaluation -- is the
pipeline used for E2, so the only thing that changes w.r.t. ladder rung 1 is the sampler.

Two backends (cfg["sampler"]["backend"]):
  tel_orig   the loader exactly as written
  tel_fixed  the same loader, with ONE correction: PyG's NeighborSampler converts the graph to CSC
             and returns `out.edge` as positions in that CSC order; PyG's own loaders map them back
             with `perm = sampler.edge_permutation` (torch_geometric/loader/utils.py, filter_data).
             TargetEdgeLoader uses `out.edge` directly as edge ids, so the sampled "neighbour"
             edges are, in general, unrelated edges of the graph. tel_fixed applies out.edge =
             perm[out.edge] before the loader sees it; nothing else differs.

Diagnostic per batch: `tel_consistency` = fraction of sampled edges whose two endpoints are both
among the sampled nodes. A correct neighbour sampler gives exactly 1.0.

Mapping to the SymDiG batch format (see sampler.build_batch):
  relation 'to'     -> ei_f / ef_ids  (global edge ids carried in edge_attr)
  relation 'rev_to' -> ei_r / er_ids  (message v -> u for every edge in er_ids), shared=False
  target_edge_local_idx -> tpos; every target is present (the loader forces them)
"""
from collections import OrderedDict

import numpy as np
import torch

_CACHE = OrderedDict()
_MAX_CACHED = 4


class _SamplerProxy:
    """Wraps the PyG NeighborSampler held by TargetEdgeLoader: optional perm fix + diagnostic."""

    def __init__(self, sampler, sample_edge_index, fix):
        self.s, self.sei, self.fix = sampler, sample_edge_index, fix
        self.perm = getattr(sampler, "perm", None)
        self.last = {}
        self.calls = 0

    def sample_from_nodes(self, inputs):
        self.calls += 1
        self.last = {}
        out = self.s.sample_from_nodes(inputs)
        e = out.edge
        if e is None:
            raise RuntimeError("PyG NeighborSampler returned no edge ids (out.edge is None)")
        if self.fix and self.perm is not None:
            e = self.perm[e]
        if len(e):
            ok = torch.isin(self.sei[0, e], out.node) & torch.isin(self.sei[1, e], out.node)
            cons = float(ok.float().mean())
        else:
            cons = 1.0
        self.last = {"tel_consistency": cons, "tel_sampled_edges": int(len(e)),
                     "tel_perm_is_identity": self.perm is None}
        out.edge = e
        return out


def _key(graph, backend, fanout):
    e = graph.eids
    n = len(e)
    return (backend, tuple(int(f) for f in fanout), int(graph.num_nodes), n,
            int(e[0]) if n else -1, int(e[n // 2]) if n else -1, int(e[-1]) if n else -1)


def get(graph, backend, fanout):
    """TargetEdgeLoader over `graph` (built once per graph; call in the main process so that
    DataLoader workers inherit it through fork)."""
    k = _key(graph, backend, fanout)
    if k in _CACHE:
        _CACHE.move_to_end(k)
        return _CACHE[k]
    from torch_geometric.data import HeteroData
    from .target_edge_loader import TO, TargetEdgeLoader
    eids = np.ascontiguousarray(np.asarray(graph.eids, np.int64))
    hd = HeteroData()
    hd["node"].num_nodes = int(graph.num_nodes)
    hd[TO].edge_index = torch.from_numpy(np.stack([np.asarray(graph.src[eids], np.int64),
                                                   np.asarray(graph.dst[eids], np.int64)]))
    hd[TO].edge_attr = torch.from_numpy(eids.copy())      # carries the global edge id
    tel = TargetEdgeLoader(hd, torch.zeros(0, dtype=torch.long), num_neighbors=[int(f) for f in fanout],
                           sample_mode="both-edges", batch_size=1, shuffle=False, num_workers=0)
    tel.sampler = _SamplerProxy(tel.sampler, tel._sample_edge_index, fix=(backend == "tel_fixed"))
    entry = {"tel": tel, "eids": eids}
    _CACHE[k] = entry
    while len(_CACHE) > _MAX_CACHED:
        _CACHE.popitem(last=False)
    return entry


def build_batch_tel(graph, targets, mode, cfg_s, rng):
    from .target_edge_loader import REV, TO
    backend = cfg_s["backend"]
    if backend not in ("tel_orig", "tel_fixed"):
        raise ValueError(f"unknown sampler backend {backend}")
    entry = get(graph, backend, cfg_s["fanout"])
    tel, eids = entry["tel"], entry["eids"]
    targets = np.unique(np.asarray(targets, np.int64))
    pos = np.searchsorted(eids, targets)
    if len(targets) and (pos.max() >= len(eids) or not np.array_equal(eids[pos], targets)):
        raise ValueError("targets are not edges of the message-passing graph")
    torch.manual_seed(int(rng.integers(2 ** 62)))
    proxy = tel.sampler
    if not isinstance(proxy, _SamplerProxy):
        raise RuntimeError(f"TargetEdgeLoader.sampler is {type(proxy).__name__}, expected the SymDiG proxy")
    calls0 = proxy.calls
    hb = tel._build_batch(torch.from_numpy(pos))
    if proxy.calls == calls0 or not proxy.last:
        raise RuntimeError(
            "TargetEdgeLoader did not sample through tel.sampler.sample_from_nodes "
            f"(proxy calls {calls0}->{proxy.calls}, stats {proxy.last}); the perm fix and the edge-consistency "
            "diagnostic would be silently skipped. Send this message and `pip show torch_geometric pyg_lib`.")
    nodes = hb["node"].n_id.numpy()
    ei_f = hb[TO].edge_index.numpy()
    ef = hb[TO].edge_attr.numpy()
    ei_r = hb[REV].edge_index.numpy()
    er = hb[REV].edge_attr.numpy()
    tpos = hb[TO].target_edge_local_idx.numpy()
    assert np.array_equal(ef[tpos], targets), "target bookkeeping mismatch"
    return {"nodes": nodes, "ei_f": ei_f, "ef_ids": ef, "ei_r": ei_r, "er_ids": er, "shared": False,
            "targets": targets, "present": np.ones(len(targets), bool), "tpos": tpos,
            "ego": np.unique(ei_f[:, tpos].ravel()), **tel.sampler.last}
