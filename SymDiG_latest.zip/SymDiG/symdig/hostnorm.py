"""Per-host feature normalisation (the NIDS analogue of per-speaker CMVN in speech recognition).

Every flow feature is re-expressed relative to the other flows of the same SOURCE host:
    hn(f) = (x_f - mean_host(src(f))) / std_host(src(f))
on top of the global standardisation. Host statistics use no labels, so they are computed on
the message-passing graph of each phase: training flows over split.graph_train, test flows over
split.graph_test (training + test flows, as for the GNNs). Hosts with few flows are shrunk
towards the global statistics (prior of `k0` pseudo-flows with mean 0 and variance 1).

mode: "none"  -> the global standardisation only (the usual features)
      "only"  -> host-normalised features only
      "both"  -> [global, host-normalised]: keeps the absolute signal for hosts that only attack
"""
import numpy as np
import scipy.sparse as sp

from .data import FeatureStore


def host_stats(data, store, eids, k0=20.0, chunk=2_000_000):
    """Shrunk per-source-host mean/std of the globally standardised features over `eids`."""
    eids = np.asarray(eids, np.int64)
    n, D = data.num_nodes, store.dim
    s1 = np.zeros((n, D), np.float64)
    s2 = np.zeros((n, D), np.float64)
    cnt = np.zeros(n, np.float64)
    for i in range(0, len(eids), chunk):
        ids = eids[i:i + chunk]
        F = store.gather(ids).astype(np.float64)
        src = data.src[ids]
        inc = sp.csr_matrix((np.ones(len(ids)), (src, np.arange(len(ids)))), shape=(n, len(ids)))
        s1 += inc @ F
        s2 += inc @ (F * F)
        cnt += np.bincount(src, minlength=n)
    mean = s1 / (cnt[:, None] + k0)
    var = (s2 + k0) / (cnt[:, None] + k0) - mean ** 2
    std = np.sqrt(np.maximum(var, 1e-4))
    return mean.astype(np.float32), std.astype(np.float32), cnt


class HostNormStore:
    """Drop-in replacement for FeatureStore.gather() with host-normalised features."""

    def __init__(self, base, src, mean, std, mode="both"):
        assert mode in ("only", "both")
        self.base, self.src, self.mean, self.std, self.mode = base, src, mean, std, mode
        self.ports = base.ports
        self.dim = base.dim * (2 if mode == "both" else 1)

    def gather(self, ids):
        ids = np.asarray(ids, np.int64)
        g = self.base.gather(ids)
        s = self.src[ids]
        hn = (g - self.mean[s]) / self.std[s]
        return np.concatenate([g, hn], 1) if self.mode == "both" else hn.astype(np.float32, copy=False)

    def state(self):
        return dict(self.base.state(), hostnorm=self.mode)


def make_stores(cfg, data, split, mode="none", k0=20.0):
    """(store for training/validation flows, store for test flows)."""
    base = data.make_store(split.graph_train, cfg["data"].get("ports", True), seed=0)
    if mode in (None, "none", "plain"):
        return base, base
    m_tr, s_tr, _ = host_stats(data, base, split.graph_train, k0)
    m_te, s_te, _ = host_stats(data, base, split.graph_test, k0)
    return HostNormStore(base, data.src, m_tr, s_tr, mode), HostNormStore(base, data.src, m_te, s_te, mode)


def host_recall(y, pred, src, min_flows=50):
    """Recall on the attack flows of each attacking source host (hosts with >= min_flows attack
    flows): the 'worst-host' view of generalisation to individual attackers."""
    m = y != 0
    if not m.any():
        return None
    s, ok = src[m], (pred[m] == y[m]).astype(np.float64)
    hosts, inv, cnt = np.unique(s, return_inverse=True, return_counts=True)
    rec = np.bincount(inv, weights=ok) / cnt
    keep = cnt >= min_flows
    if not keep.any():
        return None
    r = rec[keep]
    return {"n_hosts": int(keep.sum()), "min": float(r.min()), "p10": float(np.quantile(r, 0.1)),
            "median": float(np.median(r)), "mean": float(r.mean())}


__all__ = ["host_stats", "HostNormStore", "make_stores", "host_recall", "FeatureStore"]
