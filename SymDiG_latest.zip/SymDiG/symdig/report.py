"""Loading and aggregating run outputs (shared by make_tables.py and make_figures.py)."""
import glob
import json
import os

import numpy as np

DS_ORDER = ["ton", "unsw", "ids2018", "bot"]
DS_SHORT = {"ton": "ToN", "unsw": "UNSW", "ids2018": "IDS2018", "bot": "BoT"}
MODEL_NAMES = {"symdig": "SymDiG (ours)", "multignn": "Multi-GNN", "multignn_fixed": "Multi-GNN + sampler fix",
               "dirgnn": "Dir-GNN", "egsage": "E-GraphSAGE", "xgboost": "XGBoost", "rf": "Random Forest",
               "mlp": "MLP", "fecograph": "FeCoGraph"}
RUNG_NAMES = {0: "(0) Multi-GNN pipeline", 1: "(1) + targets always sampled", 2: "(2) + coupled fwd/rev edges",
              3: "(3) + decoupled streams, concat", 4: "(4) + attentive fusion (SymDiG)"}


def load_runs(root, corrected=True):
    """All run records. With corrected=True, a training run that has a `reeval` record gets its
    test metrics replaced by the re-evaluated ones (randomly ordered evaluation batches)."""
    out = []
    for f in glob.glob(os.path.join(root, "runs", "*.json")):
        try:
            out.append(json.load(open(f)))
        except json.JSONDecodeError:
            continue
    if corrected:
        re = {r["result"]["source_job"]: r["result"] for r in out if r["spec"]["kind"] == "reeval" and r.get("result")}
        for r in out:
            x = re.get(r["id"])
            if x and r.get("result"):
                r["result"] = dict(r["result"], metrics=x["metrics"], val_metrics=x.get("val_metrics"),
                                   reevaluated=True, sorted_order_test_macro_f1=x.get("sorted_order_test_macro_f1"))
                for k in ("metrics_covered", "test_seed_coverage", "test_twin_coverage"):
                    if k in x:
                        r["result"][k] = x[k]
    return drop_superseded(drop_stale_host_split(out))


def drop_stale_host_split(runs):
    """Runs on p1B / p1H made with an older attacker-disjoint split (no `split_v` or a smaller one)
    are left out of every table: split v1 could leave whole classes without a training flow.
    Set SYMDIG_KEEP_OLD_SPLIT=1 to keep them (e.g. to compare old and new numbers)."""
    if os.environ.get("SYMDIG_KEEP_OLD_SPLIT"):
        return runs
    from .data import HOST_SPLIT_VERSION, HOST_SPLITS
    keep = [r for r in runs if r["spec"].get("split") not in HOST_SPLITS
            or int(r["spec"].get("split_v", 1)) >= HOST_SPLIT_VERSION]
    if len(keep) < len(runs):
        print(f"[report] left out {len(runs) - len(keep)} p1B/p1H runs made with host split < v{HOST_SPLIT_VERSION}")
    return keep


def _tuned_matches(spec):
    """True when a p1B / p2 run used hyper-parameters tuned on that same protocol (or none)."""
    split = spec.get("split")
    keys = [k for k in (spec.get("tuned"), spec.get("xgb_tuned")) if k]
    return all(k.endswith(f"__{split}") for k in keys)


def drop_superseded(runs):
    """p1B / p2 runs planned before experiments.tune_on_eval_split used p1A-tuned hyper-parameters.
    When the same run exists with protocol-matched tuning, keep only that one (the older one is
    kept in r['superseded'] of the survivor for reference)."""
    import json as _json
    groups = {}
    for r in runs:
        s = r["spec"]
        if s.get("split") in ("p1B", "p2") and s["kind"] in ("gnn", "tabular", "hybrid") and r.get("result"):
            k = (s.get("exp"), s["kind"], s.get("model"), s["dataset"], s["split"], s.get("seed"), s.get("task"),
                 _json.dumps(s.get("overrides") or {}, sort_keys=True), s.get("preset"))
            groups.setdefault(k, []).append(r)
    drop = set()
    for g in groups.values():
        good = [r for r in g if _tuned_matches(r["spec"])]
        if good:
            for r in g:
                if r not in good:
                    drop.add(id(r))
                    good[0].setdefault("superseded", []).append(r["id"])
    return [r for r in runs if id(r) not in drop]


def ports_of(r):
    cfg = r.get("cfg") or {}
    return bool((cfg.get("data") or {}).get("ports", True))


def mstat(vals, scale=100.0, nd=2):
    v = np.array([x for x in vals if x is not None], float) * scale
    if len(v) == 0:
        return None, None, "--"
    if len(v) == 1:
        return v.mean(), 0.0, f"{v.mean():.{nd}f}"
    return v.mean(), v.std(ddof=1), f"{v.mean():.{nd}f} ± {v.std(ddof=1):.{nd}f}"


def select(runs, **kw):
    out = []
    for r in runs:
        s = r["spec"]
        ok = True
        for k, v in kw.items():
            if k == "ports":
                ok &= ports_of(r) == v
            elif k == "preset":
                ok &= s.get("preset") == v
            else:
                ok &= s.get(k) == v
        if ok:
            out.append(r)
    return out


def macro(rs, key="metrics"):
    return [((r["result"] or {}).get(key) or {}).get("macro_f1") for r in rs]


def paired_test(a, b):
    """Paired differences over common seeds: mean diff and two-sided sign-flip permutation p-value."""
    da = {r["spec"]["seed"]: r["result"]["metrics"]["macro_f1"] for r in a if r["result"].get("metrics")}
    db = {r["spec"]["seed"]: r["result"]["metrics"]["macro_f1"] for r in b if r["result"].get("metrics")}
    common = sorted(set(da) & set(db))
    if len(common) < 2:
        return None, None, len(common)
    d = np.array([db[s] - da[s] for s in common]) * 100
    obs = abs(d.mean())
    n = len(d)
    signs = np.array([[1 if (i >> j) & 1 else -1 for j in range(n)] for i in range(2 ** n)])
    p = float((np.abs((signs * d).mean(1)) >= obs - 1e-12).mean())
    return float(d.mean()), p, n
