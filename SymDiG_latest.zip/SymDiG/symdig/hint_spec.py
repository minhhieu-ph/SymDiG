"""HINT variants and defaults (torch-free, so the planner can import them)."""
import json
import os

DEFAULTS = dict(graph=True, hostnorm="both", adv_lambda=0.3, dro=True, dro_eta=0.01, K=256,
                encoder="mlp", hidden=128, layers=2, dropout=0.2, lr=1e-3, weight_decay=1e-5,
                epochs=30, steps=400, batch=4096, patience=6, d_token=32, blocks=2, heads=4,
                loss_power=0.5, probe_n=60000)

# variant -> (hyper-parameter group it is tuned in, base overrides, forced switches)
VARIANTS = {
    "gnn_plain":      ("gnn_plain", {}, {"hostnorm": "none", "adv_lambda": 0.0, "dro": False}),
    "hint_gnn":       ("hint_gnn", {}, {}),
    "hint_gnn_nohn":  ("hint_gnn", {}, {"hostnorm": "none"}),
    "hint_gnn_noadv": ("hint_gnn", {}, {"adv_lambda": 0.0}),
    "hint_gnn_nodro": ("hint_gnn", {}, {"dro": False}),
    # host-relative features only, no GroupDRO. Not in the default pilot: a source host that sends
    # only attack traffic has its attack signature absorbed into its own mean, so these features
    # cannot tell its flows from benign ones (kept for completeness / a negative control).
    "hint_gnn_rel":   ("hint_gnn", {}, {"hostnorm": "only", "dro": False}),
    "hint_flow":      ("hint_flow", {"graph": False}, {"graph": False}),
    "hint_flow_ftt":  ("hint_flow", {"graph": False}, {"graph": False, "encoder": "ftt"}),
    "hint_flow_rel":  ("hint_flow", {"graph": False}, {"graph": False, "hostnorm": "only", "dro": False}),
    "flow_plain":     ("flow_plain", {"graph": False}, {"graph": False, "hostnorm": "none", "adv_lambda": 0.0,
                                                         "dro": False}),
}


def variant_spec(name):
    group, base, force = VARIANTS[name]
    return group, {"base": dict(base), "force": dict(force)}


def resolve_hp(spec, root):
    hp = dict(DEFAULTS)
    h = spec.get("hint") or {}
    hp.update(h.get("base") or {})
    if spec.get("hint_tuned"):
        f = os.path.join(root, "tuned", f"{spec['hint_tuned']}.json")
        if not os.path.exists(f):
            raise FileNotFoundError(f"tuned parameters {f} missing (run the hint_tune jobs first)")
        hp.update(json.load(open(f))["best_params"])
    hp.update(h.get("force") or {})
    return hp
