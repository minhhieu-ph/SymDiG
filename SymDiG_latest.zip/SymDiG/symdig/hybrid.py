"""E8: does graph context add information to a strong per-flow model (XGBoost)?

Design (no label leakage into the stacked features):
  * the labeled training targets are split 50/50 (stratified) into halves A and B
  * the GNN (tuned 'multignn_fixed' = ladder rung 2) is trained on half A only
  * every XGBoost variant is trained on half B; GNN features for half B, val and test are
    produced by the half-A GNN, i.e. always out-of-sample
  * controls: XGBoost on half B with flow features only (matched data budget), and
    XGBoost on the full training set (reference)

Feature sets (all on top of the same flow features):
  stats   label-free graph statistics of the multigraph used for message passing:
          per endpoint log multigraph in/out degree, log distinct in/out neighbours, mean of the
          (standardised) features of its incident flows; plus log multiplicity of the pair
  prob    GNN class probabilities for the flow
  hid     GNN readout hidden layer for the flow (D/2 dims)
"""
import time

import numpy as np
import scipy.sparse as sp

from .data import Split, _strat, graph_for
from .metrics import classification_metrics


def node_context(data, store, graph, chunk=2_000_000):
    """Per-node statistics of `graph` (label-free). Returns [num_nodes, 4 + d] float32."""
    eids = np.asarray(graph.eids)
    s, t = data.src[eids], data.dst[eids]
    n = data.num_nodes
    E = len(eids)
    sums = np.zeros((n, store.dim), np.float64)
    for i in range(0, E, chunk):
        j = min(E, i + chunk)
        F = store.gather(eids[i:j]).astype(np.float32)
        k = j - i
        inc = sp.csr_matrix((np.ones(2 * k, np.float32), (np.concatenate([s[i:j], t[i:j]]),
                                                          np.concatenate([np.arange(k), np.arange(k)]))), shape=(n, k))
        sums += inc @ F
    deg = np.bincount(s, minlength=n) + np.bincount(t, minlength=n)
    mean = (sums / np.maximum(deg, 1)[:, None]).astype(np.float32)
    pair = np.unique(s * np.int64(n) + t)
    ps, pt = pair // n, pair % n
    din = np.bincount(pt, minlength=n)
    dout = np.bincount(ps, minlength=n)
    stats = np.stack([np.log1p(np.asarray(graph.in_deg)), np.log1p(np.asarray(graph.out_deg)),
                      np.log1p(din), np.log1p(dout)], 1).astype(np.float32)
    return np.concatenate([stats, mean], 1)


def flow_context(data, graph, node_ctx, targets):
    u, v = data.src[targets], data.dst[targets]
    m = np.log1p(np.asarray(graph.mult)[targets]).astype(np.float32)[:, None]
    return np.concatenate([node_ctx[u], node_ctx[v], m], 1)


def _stage_load(d):
    import json as _json
    import os as _os
    f = _os.path.join(d, "gnn.json")
    if not d or not _os.path.exists(f):
        return None
    S = {k: np.load(_os.path.join(d, f"S_{k}.npy"), mmap_mode="r") for k in ("B", "val", "test")}
    G = {k: (np.load(_os.path.join(d, f"P_{k}.npy")), np.load(_os.path.join(d, f"H_{k}.npy"), mmap_mode="r"))
         for k in ("B", "val", "test")}
    return S, G, _json.load(open(f))


def _stage_save(d, S, G, meta):
    import json as _json
    import os as _os
    _os.makedirs(d, exist_ok=True)
    for k in ("B", "val", "test"):
        np.save(_os.path.join(d, f"S_{k}.npy"), S[k])
        np.save(_os.path.join(d, f"P_{k}.npy"), G[k][0])
        np.save(_os.path.join(d, f"H_{k}.npy"), G[k][1])
    tmp = _os.path.join(d, "gnn.json.tmp")
    _json.dump(meta, open(tmp, "w"))
    _os.replace(tmp, _os.path.join(d, "gnn.json"))       # written last: marks the stage complete


def run_hybrid(c, data, split, seed, xgb_params, threads, log=print, stage_dir=None):
    """stage_dir: graph statistics + GNN outputs are saved there after the (slow) GNN stage, so a job
    killed during the XGBoost stage resumes from it instead of retraining and re-predicting."""
    from .tabular import fit_predict
    from .trainer import predict, train_and_evaluate
    t0 = time.time()
    rng = np.random.default_rng(seed)
    half_a = _strat(data.y, np.sort(split.train), 0.5, rng, min_keep=1)
    half_b = np.setdiff1d(split.train, half_a)
    va, te = np.sort(split.val), np.sort(split.test)
    store = data.make_store(split.graph_train, c["data"].get("ports", True), seed=0)
    X = {"full": store.gather(np.sort(split.train)), "B": store.gather(half_b), "val": store.gather(va), "test": store.gather(te)}
    y = {"full": data.y[np.sort(split.train)], "B": data.y[half_b], "val": data.y[va], "test": data.y[te]}
    log(f"  halves: A {len(half_a):,} (GNN) | B {len(half_b):,} (XGBoost) | val {len(va):,} | test {len(te):,}")

    staged = _stage_load(stage_dir)
    if staged is not None:
        S, G, gmeta = staged
        gnn_test, gres = gmeta["gnn_test"], {"val_best_macro_f1": gmeta["val_best_macro_f1"]}
        log(f"  resumed graph statistics + GNN outputs from {stage_dir} (GNN test macro-F1 {gnn_test['macro_f1']:.4f})")
    else:
        # 1. label-free graph statistics
        g_tr, g_te = graph_for(data, split, "train"), graph_for(data, split, "test")
        nc_tr, nc_te = node_context(data, store, g_tr), node_context(data, store, g_te)
        S = {"B": flow_context(data, g_tr, nc_tr, half_b), "val": flow_context(data, g_tr, nc_tr, va),
             "test": flow_context(data, g_te, nc_te, te)}
        del nc_tr, nc_te
        log(f"  graph statistics: {S['B'].shape[1]} features | {time.time() - t0:.0f}s")

        # 2. GNN on half A (validation on the usual validation targets)
        sa = Split(split.name, half_a, split.val, split.test, split.graph_train, split.graph_test, split.meta)
        gres, model, gstore = train_and_evaluate(c, data, sa, seed, log=log, evaluate_test=False)
        mode = {"coupled": bool(c["model"]["coupled"]), "force": True}
        G = {}
        for k, ids, g in (("B", half_b, g_tr), ("val", va, g_tr), ("test", te, g_te)):
            p, _, _, h = predict(model, g, gstore, data.y, ids, mode, c, seed, return_hid=True)
            G[k] = (p, h)
        gnn_test = classification_metrics(y["test"], G["test"][0], data.classes)
        log(f"  GNN (half A) test macro-F1 {gnn_test['macro_f1']:.4f} | {time.time() - t0:.0f}s")
        del model, gstore                     # free GPU / host memory before the XGBoost stage
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except ImportError:
            pass
        if stage_dir:
            _stage_save(stage_dir, S, G, {"gnn_test": gnn_test, "val_best_macro_f1": gres["val_best_macro_f1"]})
            S, G, _ = _stage_load(stage_dir)  # memory-mapped from here on: less resident RAM

    variants = {
        "xgb_full": None,
        "xgb": [],
        "xgb+stats": ["stats"],
        "xgb+prob": ["prob"],
        "xgb+hid": ["hid"],
        "xgb+prob+hid": ["prob", "hid"],
        "xgb+stats+prob+hid": ["stats", "prob", "hid"],
    }
    out = {"gnn_half_a": {"metrics": gnn_test, "val_best_macro_f1": gres["val_best_macro_f1"]},
           "n": {"A": int(len(half_a)), "B": int(len(half_b)), "val": int(len(va)), "test": int(len(te))},
           "classes": data.classes, "variants": {}}

    def feats(part, extra):
        cols = [X[part]]
        for e in extra:
            cols.append(S[part] if e == "stats" else (G[part][0] if e == "prob" else G[part][1]))
        # one float32 matrix, no second copy (astype(copy=False)); built per variant and freed after it
        return np.concatenate([np.asarray(c, np.float32) for c in cols], 1).astype(np.float32, copy=False)

    for name, extra in variants.items():
        t1 = time.time()
        if extra is None:
            Xtr, ytr, Xva, Xte = X["full"], y["full"], X["val"], X["test"]
        else:
            Xtr, ytr, Xva, Xte = feats("B", extra), y["B"], feats("val", extra), feats("test", extra)
        pte, pva, _, info = fit_predict("xgboost", xgb_params, Xtr, ytr, Xva, y["val"], Xte, data.n_classes, seed,
                                        threads, log)
        m = classification_metrics(y["test"], pte, data.classes)
        out["variants"][name] = {"metrics": m, "val_macro_f1": classification_metrics(y["val"], pva, data.classes)["macro_f1"],
                                 "n_features": int(Xtr.shape[1]), "fit_sec": time.time() - t1, "info": info}
        log(f"  {name:20s} test macro-F1 {m['macro_f1']:.4f} ({Xtr.shape[1]} features, {time.time() - t1:.0f}s)")
        del Xtr, Xva, Xte, pte, pva
        if name == "xgb_full":             # the full training matrix is not needed after the reference
            X.pop("full", None)
            y.pop("full", None)
        import gc
        gc.collect()
    out["sec"] = time.time() - t0
    return out
