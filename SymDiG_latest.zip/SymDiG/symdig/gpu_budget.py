"""VRAM and host-RAM budget for several workers on one machine (e.g. 1 x B300, 275 GB VRAM,
container memory limit 450 GiB).

Each worker claims a job only if the job's estimated VRAM fits into what the other workers on the
same GPU have reserved. Claiming and reserving happen under one file lock, so two workers cannot
over-commit the GPU at the same time. Reservations of dead workers are dropped automatically.

Estimates are deliberately conservative (GB). Override any of them without touching the hashed
configuration, e.g. in configs/default.yaml -> runtime.vram_gb, or scale all of them with the
environment variable SYMDIG_VRAM_SCALE.
Jobs that measure time / power (E6 "deploy") reserve the whole GPU so that they run alone.

Host RAM is budgeted the same way (estimates below, override with runtime.ram_gb, scale with
SYMDIG_RAM_SCALE): containers kill the whole process tree when the memory limit is reached.
"""
import fcntl
import json
import os
import socket
import time

HOST = socket.gethostname()

DEFAULT_VRAM_GB = {
    # calibrated on 1 x B300: six E8 jobs together used ~15.6 GB in practice (GNN runs ~2-3 GB)
    "cpu": 0,                        # prepare, coverage, survival, sizes
    "gnn": {"default": 4, "ids2018": 8, "bot": 8},
    "gnn_paper": 12,                 # Multi-GNN released hyper-parameters (fan-out 100, batch 8192)
    "tabular_xgb": {"default": 8, "unsw": 4, "ton": 12, "ids2018": 12, "bot": 24},
    "tabular_mlp": 4,
    "hybrid": {"default": 12, "unsw": 6, "bot": 24},
    "fecograph": 12,
    "exclusive": -1,                 # whole GPU
}
CPU_KINDS = {"prepare", "coverage", "survival", "sizes"}
EXCLUSIVE_KINDS = {"deploy"}


def _by_ds(v, ds):
    if isinstance(v, dict):
        return v.get(ds, v.get("default", 0))
    return v


def estimate_gb(spec, cfg, capacity):
    table = dict(DEFAULT_VRAM_GB)
    table.update((cfg.get("runtime") or {}).get("vram_gb") or {})
    kind, ds, model = spec["kind"], spec.get("dataset", ""), spec.get("model") or ""
    tabular = model in ("xgboost", "rf", "mlp")
    if kind in CPU_KINDS:
        need = table["cpu"]
    elif kind in EXCLUSIVE_KINDS:
        need = capacity
    elif kind in ("tabular",) or (kind == "tune" and tabular):
        need = _by_ds(table["tabular_mlp"] if model == "mlp" else table["tabular_xgb"], ds)
    elif kind == "hybrid":
        need = _by_ds(table["hybrid"], ds)
    elif kind == "fecograph":
        need = _by_ds(table["fecograph"], ds)
    elif spec.get("preset") == "multignn_paper":
        need = _by_ds(table["gnn_paper"], ds)
    else:                                      # gnn, tune (gnn), reeval, transfer, evasion
        need = _by_ds(table["gnn"], ds)
        if (spec.get("overrides") or {}).get("sampler.backend"):   # T1: uncapped PyG sampler
            need *= 2
    need = float(need) * float(os.environ.get("SYMDIG_VRAM_SCALE", 1.0))
    return min(need, capacity)


# ----------------------------------------------------------------------------- host RAM
# Estimates are computed from the size of the dataset (flows N, feature dim D, classes C, read from the
# cache's meta.json), i.e. from the arrays each job actually materialises. After a job has run once,
# its MEASURED peak (PSS of the worker and its loader processes, recorded by run.py) replaces the
# formula for that kind of job (x 1.15 margin). Scale everything with SYMDIG_RAM_SCALE.
GB = 2 ** 30
_SIZES = {}


def _ds_size(cfg, ds):
    if ds in _SIZES:
        return _SIZES[ds]
    try:
        from .data import cache_dir
        m = json.load(open(os.path.join(cache_dir(cfg, ds), "meta.json")))
        ports = 8 if (cfg.get("data") or {}).get("ports", True) else 0
        v = (int(m["n_edges"]), len(m["feature_names"]) + ports, len(m["classes"]))
    except Exception:
        v = None
    _SIZES[ds] = v
    return v


def ram_key(spec):
    ov = spec.get("overrides") or {}
    return "|".join(str(x) for x in (spec["kind"], spec.get("model") or "", spec.get("dataset", ""),
                                     spec.get("preset") or "", ov.get("sampler.backend") or "",
                                     spec.get("split") or ""))


def _formula_gb(spec, cfg):
    kind, ds, model = spec["kind"], spec.get("dataset", ""), spec.get("model") or ""
    size = _ds_size(cfg, ds)
    if size is None:                       # cache not built yet (prepare pending): generous default
        return 16.0 if kind != "hybrid" else 48.0
    N, D, C = size
    L = int(os.environ.get("SYMDIG_NUM_WORKERS", 8))
    nd4 = N * D * 4                        # bytes of all flows' features in float32
    tabular = model in ("xgboost", "rf", "mlp")
    gnn = 6 * GB + 0.6 * GB * L + 24 * N   # torch + CUDA context, loader workers, labels/targets/probs
    if spec.get("preset") == "multignn_paper":
        gnn += 4 * GB
    if (spec.get("overrides") or {}).get("sampler.backend"):        # T1: PyG sampler structures
        gnn += 72 * 1.75 * N + L * 6 * N
    if kind == "prepare":
        b = 6 * GB + 60 * N
    elif kind in ("coverage", "sizes"):
        b = 4 * GB + 64 * N
    elif kind == "survival":
        b = 4 * GB
    elif kind == "fecograph":
        b = 16 * GB
    elif kind in ("tabular", "tune", "transfer") and tabular:
        b = (4 * GB + 1.5 * nd4) if model == "mlp" else (4 * GB + 2.5 * nd4)
        if kind == "transfer":
            b *= 1.3
    elif kind == "hybrid":
        side = 0.6625 * N * 4              # half B + val + test rows, float32
        b = (8 * GB + 1.3375 * nd4 + side * (2 * (4 + D) + 1 + C + 64)
             + 1.5 * side * (D + 2 * (4 + D) + 1 + C + 64))
    elif kind in ("deploy", "evasion"):
        b = gnn + 4 * GB
    else:                                  # gnn, tune (gnn), reeval, transfer (gnn)
        b = gnn
    return b / GB


def _observed(results):
    try:
        return json.load(open(os.path.join(results, "queue", "ram_observed.json")))
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def estimate_ram_gb(spec, cfg, results=None):
    obs = _observed(results) if results else {}
    k = ram_key(spec)
    need = 1.15 * obs[k] if k in obs else _formula_gb(spec, cfg)
    return float(need) * float(os.environ.get("SYMDIG_RAM_SCALE", 1.0))


def record_observed(results, spec, peak_gb):
    """Keep the largest measured peak per kind of job (used by estimate_ram_gb from then on)."""
    f = os.path.join(results, "queue", "ram_observed.json")
    with open(f + ".lock", "a") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        try:
            obs = _observed(results)
            k = ram_key(spec)
            obs[k] = max(float(peak_gb), float(obs.get(k, 0.0)))
            tmp = f"{f}.tmp{os.getpid()}"
            with open(tmp, "w") as fh:
                json.dump(obs, fh, indent=1, sort_keys=True)
            os.replace(tmp, f)
        finally:
            fcntl.flock(lk, fcntl.LOCK_UN)


class PeakRam:
    """Samples the proportional set size (PSS) of this process and all its descendants
    (DataLoader workers) every few seconds; PSS splits shared pages, so sums over workers are fair."""

    def __init__(self, interval=3.0):
        import threading
        self.interval, self.peak, self._stop = interval, 0.0, threading.Event()
        self._t = threading.Thread(target=self._run, daemon=True)

    @staticmethod
    def _tree(root):
        kids = {}
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    st = open(f"/proc/{d}/stat").read()
                    ppid = int(st[st.rindex(")") + 2:].split()[1])
                    kids.setdefault(ppid, []).append(int(d))
                except (OSError, ValueError, IndexError):
                    pass
        out, stack = [], [root]
        while stack:
            p = stack.pop()
            out.append(p)
            stack.extend(kids.get(p, []))
        return out

    @staticmethod
    def _pss_kb(pid):
        for f, key in ((f"/proc/{pid}/smaps_rollup", "Pss:"), (f"/proc/{pid}/status", "VmRSS:")):
            try:
                for line in open(f):
                    if line.startswith(key):
                        return int(line.split()[1])
            except OSError:
                continue
        return 0

    def _run(self):
        me = os.getpid()
        while not self._stop.is_set():
            try:
                tot = sum(self._pss_kb(p) for p in self._tree(me)) / 2 ** 20
                self.peak = max(self.peak, tot)
            except Exception:
                pass
            self._stop.wait(self.interval)

    def __enter__(self):
        self._t.start()
        return self

    def __exit__(self, *a):
        self._stop.set()
        self._t.join(timeout=5)


class GpuBudget:
    """Host-wide ledger: VRAM is summed per GPU, RAM over the whole host."""

    def __init__(self, results, gpu_id, capacity_gb, ram_capacity_gb=None):
        d = os.path.join(results, "queue")
        os.makedirs(d, exist_ok=True)
        self.ledger = os.path.join(d, f"budget_{HOST}.json")
        self.lockf = self.ledger + ".lock"
        self.gpu = str(gpu_id)
        self.capacity = float(capacity_gb) if capacity_gb else float("inf")
        self.ram_capacity = float(ram_capacity_gb) if ram_capacity_gb else float("inf")

    def _load(self):
        try:
            led = json.load(open(self.ledger))
        except (FileNotFoundError, json.JSONDecodeError):
            led = {}
        alive = {}
        for jid, r in led.items():
            if r.get("host") != HOST:
                continue
            try:
                os.kill(int(r["pid"]), 0)
                alive[jid] = r
            except (OSError, ValueError):
                pass
        return alive

    def _save(self, led):
        tmp = f"{self.ledger}.tmp{os.getpid()}"
        with open(tmp, "w") as fh:
            json.dump(led, fh, indent=1)
        os.replace(tmp, self.ledger)

    def _sums(self, led):
        vram = sum(r["gb"] for r in led.values() if r.get("gpu") == self.gpu)
        ram = sum(r.get("ram", 0.0) for r in led.values())
        return vram, ram

    def reserved(self):
        return self._sums(self._load())

    def claim(self, q, accept, need_fn, ram_fn):
        """Claim the next runnable job whose VRAM and RAM both fit. Returns (spec, gb, ram) or (None, 0, 0)."""
        with open(self.lockf, "a") as lk:
            fcntl.flock(lk, fcntl.LOCK_EX)
            try:
                led = self._load()
                vram, ram = self._sums(led)
                free_v, free_r = self.capacity - vram, self.ram_capacity - ram
                # a job larger than the whole budget may still run alone
                fit = lambda s: ((accept is None or accept(s))
                                 and need_fn(s) <= free_v + 1e-9
                                 and (ram_fn(s) <= free_r + 1e-9 or not led))
                spec, _ = q.claim(fit)
                if spec is None:
                    return None, 0.0, 0.0
                gb, rg = need_fn(spec), ram_fn(spec)
                led[spec["id"]] = {"pid": os.getpid(), "host": HOST, "gpu": self.gpu, "gb": gb, "ram": rg,
                                   "kind": spec["kind"], "dataset": spec.get("dataset"), "since": time.time()}
                self._save(led)
                return spec, gb, rg
            finally:
                fcntl.flock(lk, fcntl.LOCK_UN)

    def release(self, jid):
        with open(self.lockf, "a") as lk:
            fcntl.flock(lk, fcntl.LOCK_EX)
            try:
                led = self._load()
                led.pop(jid, None)
                self._save(led)
            finally:
                fcntl.flock(lk, fcntl.LOCK_UN)
