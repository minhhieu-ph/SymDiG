"""Per-class view of the attacker-disjoint splits, old (v1) vs new (v2). CPU only, a few minutes.

    python scripts/split_report.py                 # datasets ton unsw ids2018 bot (those in the cache)
    python scripts/split_report.py --datasets ton ids2018

Builds (and caches) the v2 splits p1B / p1H exactly as the experiment jobs will, and reads the
v1 numbers from the old cached split files when they exist (recomputes them in memory if not).
Prints only counts: hosts and flows per class. "!!" = a class the split leaves with no training
flow (cannot be learned) or, if not excluded, with no test flow; "ex" = excluded by design
(fewer than 2 source hosts): kept in training, not evaluated.
"""
import argparse
import json
import os
import sys

import numpy as np
import yaml

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symdig.data import NetFlowData, get_split, host_split_v1, is_ready  # noqa: E402
from symdig.jobs import load_config  # noqa: E402


def old_meta(cfg, data, name):
    seed = int(cfg["data"].get("split_seed", 42))
    f = os.path.join(data.dir, "splits", f"{name}_s{seed}.json")
    if os.path.exists(f):
        return json.load(open(f)), "cached"
    if name != "p1B":
        return None, "missing"
    src_ip, _ = data.ip_arrays()
    y = data.y_multi
    tr, te, meta = host_split_v1(y, src_ip, float(cfg["data"].get("test_size", 0.25)), np.random.default_rng(seed))
    meta["train_class_counts"] = np.bincount(y[tr], minlength=len(data.classes)).tolist()
    meta["test_class_counts"] = np.bincount(y[te], minlength=len(data.classes)).tolist()
    return meta, "recomputed"


def flag(train_flows, test_flows, excluded):
    """!! = the class cannot be learned (no training flow) or, if not excluded, cannot be evaluated
    (no test flow); ex = excluded by design (too few hosts): training only, not in test."""
    if train_flows == 0:
        return "!!"
    if excluded:
        return "ex"
    return "!!" if test_flows == 0 else "  "


def fmt(n):
    return f"{n:,}" if n is not None else "-"


def report(cfg, ds):
    data = NetFlowData(cfg, ds)
    names = data.classes
    o1, how1 = old_meta(cfg, data, "p1B")
    oh, _ = old_meta(cfg, data, "p1H")
    b = get_split(cfg, data, "p1B").meta
    h = get_split(cfg, data, "p1H").meta
    vpc = (h.get("val_host_split") or {}).get("per_class") or {}
    print(f"\n=== {ds}: {b.get('n_attacker_ips')} distinct attacker source IPs, "
          f"{b.get('n_multi_class_attacker_ips')} of them run >= 2 attack classes "
          f"(v1 numbers {how1})")
    hdr = (f"{'class':15s} {'hosts':>5s} | {'p1B v1: test/train hosts':>24s} {'train flows':>12s} | "
           f"{'p1B v2: test/train hosts':>24s} {'train flows':>12s} {'test %':>6s} | "
           f"{'p1H v1 train':>12s} | {'p1H v2 val hosts':>16s} {'train flows':>12s} {'val flows':>10s}")
    print(hdr)
    print("-" * len(hdr))
    bad1 = bad2 = 0
    for c in range(1, len(names)):
        k = str(c)
        v2 = b["per_class"].get(k, {})
        v1 = (o1 or {}).get("per_class", {}).get(k, {})
        n_h = v2.get("src_ips")
        t1 = v1.get("test_src_ips")
        tr1 = (v1["src_ips"] - t1) if (t1 is not None and "src_ips" in v1) else None
        trf1 = (o1 or {}).get("train_class_counts", [None] * len(names))[c]
        trf2 = b["train_class_counts"][c]
        tef2 = b["test_class_counts"][c]
        trh1 = (oh or {}).get("train_class_counts", [None] * len(names))[c] if oh else None
        vh = vpc.get(k, {})
        flag1 = flag(trf1, (o1 or {}).get("test_class_counts", [None] * len(names))[c], v1.get("excluded"))
        flag2 = flag(trf2, tef2, v2.get("excluded"))
        bad1 += flag1 == "!!"
        bad2 += flag2 == "!!"
        note = f"  excluded: {v2.get('reason')}" if v2.get("excluded") else ""
        print(f"{names[c][:15]:15s} {fmt(n_h):>5s} | {flag1}{fmt(t1):>10s} / {fmt(tr1):<10s} {fmt(trf1):>12s} | "
              f"{flag2}{fmt(v2.get('test_src_ips')):>10s} / {fmt(v2.get('train_src_ips')):<10s} {fmt(trf2):>12s} "
              f"{100 * v2.get('test_frac', 0):6.1f} | {fmt(trh1):>12s} | {fmt(vh.get('test_src_ips')):>16s} "
              f"{fmt(h['train_class_counts'][c]):>12s} {fmt(h['val_class_counts'][c]):>10s}{note}")
    print(f"classes with no training or no test flow: v1 {bad1}, v2 {bad2}. "
          f"v2 excluded: {[names[c] for c in b['excluded_classes']]}; "
          f"leak check (test attackers seen in training): {b['attack_ip_overlap']}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="*", default=["ton", "unsw", "ids2018", "bot"])
    ap.add_argument("--results", default="results")
    ap.add_argument("--config", default="configs/default.yaml")
    a = ap.parse_args()
    snap = os.path.join(a.results, "config.yaml")
    cfg = yaml.safe_load(open(snap)) if os.path.exists(snap) else load_config(a.config)
    for ds in a.datasets:
        if not is_ready(cfg, ds):
            print(f"\n=== {ds}: not in the cache, skipped")
            continue
        report(cfg, ds)


if __name__ == "__main__":
    main()
