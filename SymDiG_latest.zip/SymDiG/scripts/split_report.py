"""Per-class view of the attacker-disjoint splits, old (v1) vs current. CPU only, a few minutes.

    python scripts/split_report.py                 # datasets ton unsw ids2018 bot (those in the cache)
    python scripts/split_report.py --datasets ton ids2018

Builds (and caches) the current splits p1B / p1H exactly as the experiment jobs will, and reads the
v1 numbers from the old cached split files when they exist (recomputes them in memory if not).
Prints only counts: hosts and flows per class. "!!" = a class the split leaves with no training
flow (cannot be learned) or, if not excluded, with no test flow; "ex" = excluded by design
(fewer than 2 source hosts): kept in training, not evaluated.
"""
import argparse
import json
import os
import sys

import numpy as np
import yaml

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symdig.data import HOST_SPLIT_VERSION, NetFlowData, get_split, host_split_v1, is_ready  # noqa: E402
from symdig.jobs import load_config  # noqa: E402


def old_meta(cfg, data, name):
    seed = int(cfg["data"].get("split_seed", 42))
    f = os.path.join(data.dir, "splits", f"{name}_s{seed}.json")
    if os.path.exists(f):
        return json.load(open(f)), "cached"
    if name != "p1B":
        return None, "missing"
    src_ip, _ = data.ip_arrays()
    y = data.y_multi
    tr, te, meta = host_split_v1(y, src_ip, float(cfg["data"].get("test_size", 0.25)), np.random.default_rng(seed))
    meta["train_class_counts"] = np.bincount(y[tr], minlength=len(data.classes)).tolist()
    meta["test_class_counts"] = np.bincount(y[te], minlength=len(data.classes)).tolist()
    return meta, "recomputed"


def flag(train_flows, test_flows, excluded):
    """!! = the class cannot be learned (no training flow) or, if not excluded, cannot be evaluated
    (no test flow); ex = excluded by design (too few hosts): training only, not in test."""
    if train_flows == 0:
        return "!!"
    if excluded:
        return "ex"
    return "!!" if test_flows == 0 else "  "


def fmt(n):
    return f"{n:,}" if n is not None else "-"


def report(cfg, ds):
    data = NetFlowData(cfg, ds)
    names = data.classes
    V = f"v{HOST_SPLIT_VERSION}"
    o1, how1 = old_meta(cfg, data, "p1B")
    oh, _ = old_meta(cfg, data, "p1H")
    b = get_split(cfg, data, "p1B").meta
    h = get_split(cfg, data, "p1H").meta
    vpc = (h.get("val_host_split") or {}).get("per_class") or {}
    print(f"\n=== {ds}: {b.get('n_attacker_ips')} distinct attacker source IPs, "
          f"{b.get('n_multi_class_attacker_ips')} of them run >= 2 attack classes (v1 numbers {how1})")
    hdr = (f"{'class':15s} {'hosts':>5s} | {'p1B v1: test/train hosts':>24s} {'train flows':>12s} | "
           f"{'p1B ' + V + ': test/train hosts':>24s} {'train flows':>12s} {'test %':>6s} | "
           f"{'p1H v1 train':>12s} | {'p1H ' + V + ': val hosts':>17s} {'val %':>6s} {'train flows':>12s}")
    print(hdr)
    print("-" * len(hdr))
    bad1 = bad2 = 0
    notes = []
    for c in range(1, len(names)):
        k = str(c)
        v3 = b["per_class"].get(k, {})
        v1 = (o1 or {}).get("per_class", {}).get(k, {})
        t1 = v1.get("test_src_ips")
        tr1 = (v1["src_ips"] - t1) if (t1 is not None and "src_ips" in v1) else None
        trf1 = (o1 or {}).get("train_class_counts", [None] * len(names))[c]
        trf3 = b["train_class_counts"][c]
        trh1 = (oh or {}).get("train_class_counts", [None] * len(names))[c] if oh else None
        vh = vpc.get(k, {})
        flag1 = flag(trf1, (o1 or {}).get("test_class_counts", [None] * len(names))[c], v1.get("excluded"))
        flag3 = flag(trf3, b["test_class_counts"][c], v3.get("excluded"))
        flagh = flag(trh1, 1, False) if trh1 is not None else "  "
        bad1 += flag1 == "!!"
        bad2 += flag3 == "!!"
        if v3.get("excluded"):
            notes.append(f"  p1B {names[c]}: not evaluated ({v3.get('reason')})")
        if vh.get("excluded"):
            notes.append(f"  p1H {names[c]}: not in validation ({vh.get('reason')})")
        vs = 100 * vh["test_frac"] if "test_frac" in vh else float("nan")
        print(f"{names[c][:15]:15s} {fmt(v3.get('src_ips')):>5s} | {flag1}{fmt(t1):>10s} / {fmt(tr1):<10s} {fmt(trf1):>12s} | "
              f"{flag3}{fmt(v3.get('test_src_ips')):>10s} / {fmt(v3.get('train_src_ips')):<10s} {fmt(trf3):>12s} "
              f"{100 * v3.get('test_frac', 0):6.1f} | {flagh}{fmt(trh1):>10s} | {fmt(vh.get('test_src_ips')):>17s} "
              f"{vs:6.1f} {fmt(h['train_class_counts'][c]):>12s}")
    print("\n".join(notes))
    print(f"classes that cannot be learned or evaluated: v1 {bad1}, {V} {bad2} | "
          f"leak check (test attackers seen in training): {b['attack_ip_overlap']}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="*", default=["ton", "unsw", "ids2018", "bot"])
    ap.add_argument("--results", default="results")
    ap.add_argument("--config", default="configs/default.yaml")
    a = ap.parse_args()
    snap = os.path.join(a.results, "config.yaml")
    cfg = yaml.safe_load(open(snap)) if os.path.exists(snap) else load_config(a.config)
    for ds in a.datasets:
        if not is_ready(cfg, ds):
            print(f"\n=== {ds}: not in the cache, skipped")
            continue
        report(cfg, ds)


if __name__ == "__main__":
    main()
