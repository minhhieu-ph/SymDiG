"""Check that the new machine can run every part of the pipeline. Takes ~1 minute.

    python env/check_env.py

Prints PASS / WARN / FAIL per item. FAIL items block experiments; WARN items only affect
T1 / the DiG-RSB repro (pyg-lib) or power readings (E6).
"""
import os
import platform
import shutil
import subprocess
import sys
import time
import traceback

RES = []


def item(name, fn, required=True):
    t0 = time.time()
    try:
        msg = fn() or ""
        RES.append(("PASS", name, msg))
    except Exception as ex:
        RES.append(("FAIL" if required else "WARN", name, f"{type(ex).__name__}: {ex}"))
        if os.environ.get("VERBOSE"):
            traceback.print_exc()
    print(f"[{RES[-1][0]:4s}] {name} ({time.time() - t0:.1f}s) {RES[-1][2]}", flush=True)


def system():
    import os as _os
    mem = _os.sysconf("SC_PAGE_SIZE") * _os.sysconf("SC_PHYS_PAGES") / 2**40
    st = _os.statvfs("/dev/shm")
    shm = st.f_blocks * st.f_frsize / 2**30
    du = shutil.disk_usage(".")
    note = "" if shm >= 32 else " -> workers will use torch sharing strategy 'file_system' (fine, slightly slower)"
    lim = None
    for f in ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
        try:
            v = open(f).read().strip()
            if v != "max" and int(v) < mem * 2**40:
                lim = int(v) / 2**30
                break
        except (OSError, ValueError):
            pass
    lim_s = f" | container memory limit {lim:.0f} GiB (this is what counts)" if lim else ""
    return (f"Python {platform.python_version()} | {os.cpu_count()} threads | RAM {mem:.2f} TiB{lim_s} | "
            f"/dev/shm {shm:.0f} GiB{note} | disk free here {du.free / 2**40:.2f} TiB")


def driver():
    out = subprocess.run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total,compute_cap",
                          "--format=csv,noheader"], capture_output=True, text=True, check=True).stdout.strip()
    return out


def torch_gpu():
    import torch
    assert torch.cuda.is_available(), "torch.cuda.is_available() is False"
    p = torch.cuda.get_device_properties(0)
    cc = f"{p.major}.{p.minor}"
    archs = torch.cuda.get_arch_list()
    x = torch.randn(4096, 4096, device="cuda", dtype=torch.bfloat16)
    y = (x @ x).float().sum().item()
    assert y == y, "NaN from bf16 matmul"
    torch.cuda.synchronize()
    ok_arch = any(a.startswith(f"sm_{p.major}") for a in archs) or any(a.startswith("compute_") for a in archs)
    if not ok_arch:
        raise RuntimeError(f"torch {torch.__version__} has no kernels for sm_{p.major}x (arch list {archs})")
    return (f"torch {torch.__version__} (CUDA {torch.version.cuda}) | {p.name} cc {cc} | "
            f"{p.total_memory / 2**30:.0f} GiB | archs {','.join(archs)}")


def pyg_layers():
    import torch
    import torch_geometric
    from torch_geometric.nn import GATv2Conv, GINEConv
    n, e, d = 1000, 5000, 32
    x = torch.randn(n, d, device="cuda")
    ei = torch.randint(0, n, (2, e), device="cuda")
    ea = torch.randn(e, d, device="cuda")
    g = GINEConv(torch.nn.Sequential(torch.nn.Linear(d, d), torch.nn.ReLU(), torch.nn.Linear(d, d)), edge_dim=d).cuda()
    a = GATv2Conv(d, d // 4, heads=4, edge_dim=d).cuda()
    with torch.autocast("cuda", dtype=torch.bfloat16):
        out = g(x, ei, ea) + a(x, ei, ea)
    out.float().sum().backward()
    return f"torch_geometric {torch_geometric.__version__}: GINEConv + GATv2Conv fwd/bwd on GPU"


def symdig_model():
    import numpy as np
    import torch
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from symdig.data import Graph
    from symdig.loader import SubgraphBatches, make_loader, to_device
    from symdig.models import build_model
    rng = np.random.default_rng(0)
    N, E = 2000, 40000
    src, dst = rng.integers(0, N, E), rng.integers(0, N, E)
    g = Graph.build(src, dst, np.arange(E), N)

    class Store:
        dim = 16

        def gather(self, ids):
            return np.random.default_rng(len(ids)).standard_normal((len(ids), 16)).astype(np.float32)
    y = rng.integers(0, 4, E)
    ds = SubgraphBatches(g, Store(), y, np.arange(E), 2048, {"coupled": True, "force": True},
                         {"fanout": [10, 10], "max_hop_edges": 100000}, shuffle=True, seed=0, max_batches=4)
    model = build_model({"arch": "dual", "coupled": True, "force": True, "fusion": "mha"}, 16, 4).cuda()
    n = 0
    for b in make_loader(ds, 4):           # forked DataLoader workers, as in the real runs
        b = to_device(b, torch.device("cuda"))
        with torch.autocast("cuda", dtype=torch.bfloat16):
            out = model(b)
        torch.nn.functional.cross_entropy(out["logits"].float(), b["y"]).backward()
        n += 1
    return f"SymDiG dual-stream model, {n} batches through 4 forked loader workers"


def xgb_gpu():
    import numpy as np
    import xgboost as xgb
    info = xgb.build_info()
    assert info.get("USE_CUDA"), "this xgboost build has no CUDA support"
    rng = np.random.default_rng(0)
    X = rng.standard_normal((200_000, 40)).astype(np.float32)
    y = (X[:, 0] + X[:, 1] > 0).astype(int) + (X[:, 2] > 1).astype(int)
    clf = xgb.XGBClassifier(n_estimators=50, max_depth=8, tree_method="hist", device="cuda")
    clf.fit(X, y)
    acc = (clf.predict(X) == y).mean()
    return f"xgboost {xgb.__version__} (CUDA {info.get('CUDA_VERSION')}) GPU fit ok, train acc {acc:.3f}"


def pyglib_sampler():
    import torch
    from torch_geometric.data import Data
    from torch_geometric.sampler import NeighborSampler, NodeSamplerInput
    import pyg_lib  # noqa: F401
    ei = torch.randint(0, 1000, (2, 10000))
    s = NeighborSampler(Data(edge_index=ei, num_nodes=1000), num_neighbors=[10, 10])
    out = s.sample_from_nodes(NodeSamplerInput(input_id=None, node=torch.arange(50)))
    return f"pyg_lib {pyg_lib.__version__}: NeighborSampler ok ({len(out.edge)} edges)"


def nvml_power():
    import pynvml
    pynvml.nvmlInit()
    h = pynvml.nvmlDeviceGetHandleByIndex(0)
    return f"board power {pynvml.nvmlDeviceGetPowerUsage(h) / 1000:.0f} W"


def misc():
    import optuna
    import pandas
    import scipy
    import sklearn
    import yaml  # noqa: F401
    return f"optuna {optuna.__version__}, pandas {pandas.__version__}, scipy {scipy.__version__}, sklearn {sklearn.__version__}"


if __name__ == "__main__":
    item("system", system)
    item("nvidia driver", driver)
    item("torch + GPU kernels", torch_gpu)
    item("PyG layers", pyg_layers)
    item("SymDiG model + loader", symdig_model)
    item("XGBoost GPU", xgb_gpu)
    item("python packages", misc)
    item("pyg-lib sampler (T1, repro only)", pyglib_sampler, required=False)
    item("NVML power (E6 only)", nvml_power, required=False)
    fails = [r for r in RES if r[0] == "FAIL"]
    warns = [r for r in RES if r[0] == "WARN"]
    print(f"\n{len(RES) - len(fails) - len(warns)} PASS, {len(warns)} WARN, {len(fails)} FAIL")
    sys.exit(1 if fails else 0)
