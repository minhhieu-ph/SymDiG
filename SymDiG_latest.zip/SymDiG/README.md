# SymDiG — mã nguồn thực nghiệm E1–E7

Mã nguồn chạy toàn bộ thực nghiệm trong *Đề xuất tái định hướng nghiên cứu SymDiG cho IEEE TDSC*. Mỗi thực nghiệm được tách thành các **job độc lập**, đặt trong một hàng đợi dùng chung. Mỗi GPU chạy một worker; nhiều pod Kubeflow có thể dùng chung một hàng đợi. Bảng và hình được sinh tự động từ file kết quả, nên mọi con số đều truy ngược được về một lần chạy cụ thể.

## 1. Cài đặt

```bash
cd SymDiG                                   # folder đã có dataset/ chứa 4 file CSV NetFlow v2
conda create -n symdig python=3.11 -y && conda activate symdig
pip install torch --index-url https://download.pytorch.org/whl/cu121   # chọn đúng bản CUDA của máy
pip install -r requirements.txt
git clone https://github.com/minhhieu-ph/LineGraph external/LineGraph  # FeCoGraph (chỉ dùng cho E4-p2)
python scripts/selfcheck.py                 # 1–3 phút, phải in "SELF-CHECK PASSED"
```

Yêu cầu Python ≥ 3.9. PyTorch Geometric chỉ cần bản thuần Python, **không** cần `torch-scatter` hay `torch-sparse`.

## 2. Chạy

```bash
# (0) Smoke test: mọi thực nghiệm ở cấu hình tí hon, 200k dòng đầu của ToN và UNSW (~10–20 phút)
python run.py smoke --datasets ton unsw
python make_tables.py --results results_smoke && python make_figures.py --results results_smoke

# (1) Lập kế hoạch (an toàn khi chạy lại: job trùng chỉ được tạo một lần)
python run.py plan E1 E2            # cốt lõi của bài: chẩn đoán + bậc thang ablation
python launch.py                    # 1 worker / GPU, tự chia CPU; worker tự thoát khi hết việc
python run.py status                # tiến độ, job lỗi, job bị chặn

python run.py plan tune E4 E5 E7    # tinh chỉnh (Optuna, cùng 30 trial cho mọi mô hình) -> so sánh -> độ bền -> evasion
python run.py plan E3 E6            # motif tổng hợp, chi phí triển khai
python launch.py

# (2) Bảng và hình
python make_tables.py               # results/tables/summary.md + E*.tex
python make_figures.py              # results/figures/*.pdf|png
```

- **Nhiều pod:** chạy `python launch.py` trên mỗi pod, trỏ `--results` và `paths.cache` vào cùng một PVC. Job được nhận bằng thao tác rename nguyên tử, nên mỗi job chỉ chạy một lần.
- **Pod bị khởi động lại:** chạy `python run.py requeue` (chuyển các job đang "running" về lại hàng đợi), rồi chạy `launch.py` lại.
- **Job lỗi:** sửa nguyên nhân, rồi chạy `python run.py retry`.
- **Chạy riêng một job để debug:** `python run.py run <job-id>`.

### Chia tài nguyên (4 × A100 40 GB, 11 core, 128 GiB)

`launch.py` mặc định chạy 1 worker cho mỗi GPU. Mỗi worker nhận `11 // 4 = 2` luồng CPU và 1 tiến trình lấy mẫu subgraph.

- Lấy mẫu chạy trên CPU, nên với 11 core cho cả 4 GPU, **CPU thường là nút thắt** của các job GNN.
- Nếu mỗi pod/GPU có riêng 11 core (như README của LineGraph mô tả), dùng `python launch.py --cpus 44` để mỗi worker có ~10 luồng lấy mẫu.
- Mảng dữ liệu được memory-map, nên 4 worker dùng chung page cache. BoT-IoT (lớn nhất) cần khoảng 11 GB cho đặc trưng cộng vài GB cho mỗi worker, nằm gọn trong 128 GiB.

## 3. Thực nghiệm → job → bảng/hình

| Thực nghiệm | Giả thuyết | Job | Bảng / hình |
|---|---|---|---|
| **E1** Chẩn đoán | H1 | `coverage`: độ phủ seed và độ phủ cặp xuôi–ngược của 3 kiểu sampler, fan-out 20/50/100, chia theo bậc node (không huấn luyện). `gnn` ladder0 + siêu tham số gốc của Multi-GNN: F1 trên phần seed được lấy mẫu (cách code gốc đo) so với F1 trên 100% test | `E1_coverage`, `E1_multignn`, `fig_e1_coverage` |
| **E2** Bậc thang ablation | H1, H2 | `gnn` ladder0–4 × 4 dataset × 5 seed (BoT 3 seed), cùng backbone và siêu tham số | `E2_ladder` (kèm Δ và p-value cặp), `E2_perclass_*`, `fig_e2_ladder` |
| **E3** Motif tổng hợp | H1, H2, Prop. 1–2 | `survival`: xác suất chu trình còn nguyên, đo thực nghiệm so với công thức. `gnn` ladder0–4 trên nhãn chỉ phụ thuộc cấu trúc, M = 1…256 | `E3_survival`, `E3_ladder`, `E3_perclass`, `fig_e3_*` |
| **E4** Cùng hệ quy chiếu | H3 | `tune` + 8 mô hình × 4 dataset × 5 seed; bản không có cổng; protocol FeCoGraph p2 (2%, 30% nhãn) với XGBoost, RF, E-GraphSAGE, SymDiG, FeCoGraph (repo của bạn) | `E4_main`, `E4_noports`, `E4_p2`, `E4_perclass_*`, `fig_e4_perclass` |
| **E5** Độ bền | H4 | Split theo host p1B (IP nguồn tấn công ở test không xuất hiện trong train) cho SymDiG, Multi-GNN, XGBoost, MLP; chuyển giao chéo dataset (nhị phân) | `E5_host`, `E5_transfer` |
| **E6** Triển khai | Góp ý editor | `sizes`: số node IP / IP:PORT / cạnh line graph. `deploy`: VRAM, targets/s, flows/s, độ trễ p95, có và không có giới hạn 16 GB | `E6_sizes`, `E6_deploy`, `fig_e6_cost` |
| **E7** Evasion | Góc security | Chèn chaff theo 3 chiến lược (pair / reverse / flood), K = 0…100, trên checkpoint của E4 | `E7_evasion`, `fig_e7_evasion` |

**Bậc thang ablation:** mỗi bậc thay đúng một yếu tố so với bậc trước.

| Bậc | arch | coupled | force | fusion | Ý nghĩa |
|---|---|---|---|---|---|
| 0 | hetero | false | false | — | Pipeline Multi-GNN: `LinkNeighborLoader` + `to_hetero(aggr='mean')`; loss chỉ tính trên seed được lấy mẫu |
| 1 | hetero | false | true | — | + cạnh đích luôn có trong subgraph |
| 2 | hetero | true | true | — | + xuôi/ngược dùng chung một tập cạnh |
| 3 | dual | true | true | concat | + hai luồng tách biệt, hợp nhất muộn |
| 4 | dual | true | true | mha | + hợp nhất bằng attention (SymDiG) |

**Số job với cấu hình mặc định:** khoảng 670, trong đó khoảng 365 job huấn luyện GNN. Thời gian phụ thuộc chủ yếu vào tốc độ lấy mẫu, nên hãy chạy E1 + E2 trước, xem `sec_per_step` trong `results/runs/*.json`, rồi mới quyết định số seed và số epoch cho các thực nghiệm còn lại.

## 4. Các lựa chọn cài đặt cần ghi trong bài

1. **Split.**
   - Split cố định với `split_seed = 42`. Seed của mô hình chỉ ảnh hưởng đến khởi tạo và thứ tự batch.
   - **p1A** chia ngẫu nhiên phân tầng 75/25. Validation là 10% tập train (tối đa 200k), chỉ dùng để chọn epoch và tinh chỉnh. Lúc train, đồ thị chỉ gồm flow của train; lúc test, đồ thị gồm mọi flow, nhưng không dùng nhãn test.
   - **p1B** chia theo IP nguồn tấn công.
     - Lớp có ít hơn 2 IP nguồn không chia được: lớp đó chỉ nằm trong train và bị loại khỏi macro-F1 của p1B. Các flow của lớp này xuất phát từ IP thuộc tập test bị bỏ hẳn để tránh rò rỉ.
     - `split_meta` ghi lại số IP, tỉ lệ test thực tế của từng lớp, và chỉ số `attack_ip_overlap` (phải bằng 0).
   - **p2** đúng theo protocol của FeCoGraph và là split transductive. Mọi mô hình trong E4-p2 dùng **cùng** tập con và cùng các tập train/val/test.
2. **Đặc trưng.**
   - log1p cho các cột số, tách 8 bit cho mỗi cột TCP flag, bỏ IP.
   - Cổng (giá trị gốc + 3 dải mỗi phía) là một biến thí nghiệm: `data.ports`.
   - Chuẩn hoá bằng thống kê tính trên các cạnh của đồ thị train.
3. **Đánh giá trên 100% tập test.** Với bậc 0, cạnh test không được lấy mẫu sẽ được đưa vào lại khi tính F1 "full". F1 theo cách của code gốc được báo cáo riêng (`metrics_covered`), kèm độ phủ.
4. **Sampler.**
   - Lấy mẫu đều, có hoàn lại, mỗi node B cạnh theo mỗi chiều mỗi hop. Đây là xấp xỉ của `LinkNeighborLoader` (không hoàn lại) khi bậc node lớn hơn nhiều so với B.
   - Mỗi hop giới hạn `max_hop_edges = 400k` cạnh để giữ an toàn bộ nhớ GPU; giới hạn này áp dụng như nhau cho mọi bậc.
5. **Multi-GNN.**
   - Được cài lại theo đúng ngữ nghĩa trong repo IBM: `to_hetero` gộp trung bình theo từng tầng, edge update riêng cho từng quan hệ, ego ID.
   - Không dùng port numbering, vì kỹ thuật này cần thứ tự thời gian mà NetFlow v2 không có.
   - Có thêm job E1 với siêu tham số gốc của họ (lr 0.006, hidden 66, fan-out 100, batch 8192).
6. **Tinh chỉnh.**
   - 30 trial Optuna (TPE, seed 0) cho **mọi** mô hình, tối ưu macro-F1 trên validation của p1A.
   - Mô hình bảng được tinh chỉnh trên cả 4 dataset. GNN được tinh chỉnh trên ToN và UNSW; IDS2018 và BoT dùng lại tham số của ToN (`tuning.gnn_datasets`).
   - Các bậc của ablation **không** được tinh chỉnh riêng, có chủ đích, để mỗi bậc chỉ khác đúng một yếu tố.
7. **Thống kê.** Mean ± std qua các seed. Giữa hai bậc liền kề dùng kiểm định hoán vị dấu cho cặp seed (với 5 seed, p nhỏ nhất đạt được là 0.0625).
8. **Evasion.**
   - Đặc trưng của chaff được sao từ flow benign thật trong tập test.
   - Precision được hiệu chỉnh khi lấy mẫu con các target không bị tấn công (trọng số 1/q).
   - XGBoost và MLP không bị chaff ảnh hưởng theo định nghĩa, vì chúng phân loại từng flow độc lập. Đây là một nhận xét trung thực cần nêu trong bài.

## 5. Gửi kết quả cho tôi

Sau mỗi đợt chạy, gửi:

```bash
python make_tables.py
tar czf symdig_results.tgz results/tables results/figures results/runs results/tuned results/index results/config.yaml \
    $(python run.py status | grep -o 'results/logs/[a-f0-9]*\.log')
```

Không cần gửi `results/ckpt` (checkpoint lớn) hay `cache/`.

## 6. Xử lý sự cố

| Triệu chứng | Cách xử lý |
|---|---|
| Lỗi liên quan bf16 trong `GATv2Conv` hoặc scatter | `python run.py plan ... --set train.amp=false` (job mới có id mới) |
| CUDA OOM khi huấn luyện | `--set train.batch_size=2048 sampler.max_hop_edges=200000` |
| GPU dùng thấp, CPU 100% | Lấy mẫu là nút thắt: tăng `--cpus`, hoặc giảm `--workers-per-gpu` |
| Thiếu RAM | Giữ `data.in_memory=false` (mặc định); giảm số worker |
| `p1B` loại bỏ hầu hết các lớp | Ghi nhận như một phát hiện: dataset có quá ít IP tấn công để kiểm chứng tổng quát hoá theo host |

## 7. Cấu trúc

```
configs/default.yaml      mọi siêu tham số + định nghĩa bậc thang + danh sách thực nghiệm
run.py / launch.py        CLI (plan, worker, status, smoke...) / khởi chạy worker theo GPU
symdig/data.py            CSV -> cache, đặc trưng, split p1A/p1B/p2, CSR đa đồ thị (cache memmap)
symdig/sampler.py         sampler cho bậc thang (coupled / force), thống kê độ phủ
symdig/loader.py          DataLoader: lấy mẫu song song trong worker
symdig/models.py          hetero (Multi-GNN), dual (SymDiG), dir (Dir-GNN), egsage (E-GraphSAGE)
symdig/trainer.py         huấn luyện, đánh giá full / covered, checkpoint
symdig/tabular.py         XGBoost, Random Forest (XGBRF), MLP trên GPU
symdig/fecograph_adapter.py  chạy repo LineGraph của bạn trên đúng split p2 (không sửa repo)
symdig/motifs.py          sinh đa đồ thị có motif + xác suất sống sót (Prop. 1)
symdig/evasion.py         chèn chaff (pair / reverse / flood)
symdig/tuning.py          Optuna, cùng ngân sách cho mọi mô hình
symdig/planner.py         E1–E7 -> job; symdig/jobs.py hàng đợi; symdig/executors.py thực thi từng loại job
make_tables.py / make_figures.py   bảng (Markdown + LaTeX) và hình (PDF vector)
scripts/selfcheck.py      kiểm tra môi trường + mọi kiến trúc trên dữ liệu tí hon
tests/                    test phần numpy (không cần GPU)
```

## 8. Tái hiện DiG-RSB bằng chính code gốc (repro/)

```bash
git clone https://github.com/minhhieu-ph/DiG-RSB external/DiG-RSB
pip install torchmetrics            # repo gốc cần; wandb không bắt buộc (đã có stub)
bash repro/run_digrsb.sh ton        # 4 cấu hình song song trên 4 GPU
python repro/summarize.py           # bảng: paper-style / test @ best val / last
```

Harness `repro/digrsb_repro.py` import nguyên vẹn code DiG-RSB và chỉ thay cách chia dữ liệu:

- Giữ đúng tập 25% của bài (`random_state = 89`) làm **test**, và tách thêm 10% của phần train làm **validation**.
- Mỗi epoch ghi lại macro-F1 trên cả validation lẫn test.

Bốn cấu hình chạy song song, mỗi cấu hình bỏ đi một yếu tố:

| Tag | Thay đổi so với bài |
|---|---|
| `paper` | Không đổi gì (bậc IP làm node feature + embedding cho cổng) |
| `constx` | Node feature = 1, tức bỏ "dấu vân tay" bậc của từng host |
| `unkport` | Mọi cổng được ánh xạ về `<UNK>`, tức bỏ embedding cho cổng |
| `constx_unkport` | Bỏ cả hai |

Cột `paper-style` là macro-F1 cao nhất trên test qua các epoch, đúng con số bài báo đã báo cáo. Cột `test @ best val` là con số theo đúng protocol (chọn epoch bằng validation, báo cáo trên test).

Nếu một epoch quá lâu, thêm `MAX_STEPS=1000` để giới hạn số batch mỗi epoch. Ví dụ: `EPOCHS=30 MAX_STEPS=1000 bash repro/run_digrsb.sh ton`.

## 9. E8 — Ngữ cảnh đồ thị làm đặc trưng cho XGBoost (mô hình lai)

```bash
python run.py plan E8      # chạy SAU khi các worker của đợt trước đã thoát
python launch.py
```

Thiết kế, để không rò rỉ nhãn:

- Các target có nhãn của tập train được chia đôi, phân tầng theo lớp. GNN (`multignn_fixed`, tức bậc 2, đã tinh chỉnh) chỉ học trên **nửa A**. Mọi biến thể XGBoost học trên **nửa B**, nên đặc trưng lấy từ GNN luôn là ngoài mẫu.
- Đối chứng: XGBoost học trên nửa B chỉ với đặc trưng flow, và XGBoost học trên toàn bộ tập train làm mốc tham chiếu.
- Các bộ đặc trưng được thêm vào:
  - `stats`: thống kê đồ thị không dùng nhãn (bậc, số láng giềng phân biệt, bội số cạnh, trung bình đặc trưng của các flow kề);
  - `prob`: xác suất lớp do GNN dự đoán;
  - `hid`: tầng ẩn cuối của bộ đọc GNN.
- Chạy trên cả p1A và p1B. Nếu `stats` chỉ giúp trên p1A mà không giúp trên p1B, đó là dấu hiệu model học thuộc host.

Kết quả nằm trong các bảng `E8_p1A`, `E8_p1B` và `E8_perclass_*`.

## 10. T1: dùng TargetEdgeLoader của bạn làm sampler

```bash
python scripts/check_tel.py                 # kiểm tra nhanh trên đồ thị tổng hợp (~10 giây)
python scripts/check_tel.py --dataset ton   # kiểm tra thêm trên đồ thị train thật của ToN
python run.py plan T1                       # chạy SAU khi các worker của đợt trước đã thoát
python launch.py
python make_tables.py                       # sinh bảng T1 và T1_sampler
```

- File `symdig/target_edge_loader.py` là bản sao **nguyên văn** của `data_loader.py` của bạn. Lớp adapter `symdig/tel.py` chỉ gọi `TargetEdgeLoader._build_batch` rồi đổi batch về đúng định dạng của pipeline. Edge id toàn cục được mang theo trong `edge_attr`.
- Mọi thứ khác giữ y hệt bậc 1 của E2: đặc trưng cạnh (log1p, không IP, không port), split p1A, batch 4096, mô hình `hetero` (mean), loss có trọng số, early stopping và đánh giá trên toàn bộ tập test. Các seed cũng giống E2, nên có thể kiểm định cặp với bậc 1 native.
- Có hai backend:
  - `tel_orig`: loader đúng như bạn viết.
  - `tel_fixed`: sửa đúng một chỗ, là `out.edge = perm[out.edge]`. `NeighborSampler` của PyG chuyển đồ thị sang dạng CSC và trả `out.edge` là **vị trí trong thứ tự CSC**. Các loader của chính PyG phải ánh xạ ngược lại qua `edge_permutation` (xem `filter_data`), còn TargetEdgeLoader lấy thẳng `out.edge` làm edge id.
- Chỉ số chẩn đoán *edge consistency* là tỉ lệ cạnh được lấy mẫu có cả hai đầu mút nằm trong tập node được lấy mẫu. Một sampler láng giềng đúng phải cho đúng 1.0.
- Khác biệt cố ý so với sampler native, để trung thành với loader gốc:
  - fanout áp dụng cho tổng in và out của mỗi node, thay vì lấy B cạnh vào cộng B cạnh ra riêng rẽ;
  - lấy mẫu không hoàn lại, theo đúng PyG;
  - không giới hạn số cạnh mỗi hop (`max_hop_edges`);
  - `rev_to` chỉ gồm các cạnh ngược mà sampler kéo vào.

### Tạm hoãn một phần hàng chờ

```bash
python run.py hold T1      # cất mọi job pending KHÔNG thuộc T1 vào results/queue/held (job prepare thì giữ lại)
python run.py release      # đưa chúng trở lại hàng chờ
```

## 11. Máy mới: 1 × B300 (275 GB), 256 luồng CPU, 3,9 TiB RAM

### 11.1 Cài môi trường

```bash
bash env/setup_env.sh            # tạo env conda "symdig": tự chọn torch/xgboost bản cu130 (driver >= 580) hoặc cu128
conda activate symdig
python env/check_env.py          # mọi mục FAIL phải về PASS; WARN chỉ ảnh hưởng T1/repro (pyg-lib) hoặc E6 (đo điện)
```

B300 có compute capability 10.3. Các wheel cu128 và cu130 đều có kernel sm_100, mà kernel này chạy được trên 10.3 vì cùng kiến trúc chính. Nếu `check_env.py` báo thiếu kernel, cài lại với `CUDA_TAG=cu130 TORCH_VERSION=<bản mới hơn> bash env/setup_env.sh`.

### 11.2 Chuyển dữ liệu và kết quả

Trên máy cũ: dừng worker, chạy `python run.py requeue`, rồi copy sang máy mới:

```bash
rsync -a dataset/ cache/ results/ external/ <máy-mới>:<đường-dẫn>/SymDiG/   # cache/ không bắt buộc: thiếu thì prepare tự dựng lại
```

Config hash không đổi, nên mọi job đã xong được giữ nguyên và chỉ phần còn lại chạy tiếp. Trên máy mới, chạy `python run.py requeue` một lần nữa để đưa các job đang dở từ máy cũ về hàng chờ, rồi `python run.py status`.

### 11.3 Chạy

```bash
python launch.py                 # tự chọn: 12 worker cùng chia 1 GPU B300, 21 luồng CPU mỗi worker, tối đa 16 sampling worker mỗi job
python run.py status
```

- **Ngân sách VRAM:** khi nhiều worker dùng chung một GPU, mỗi worker chỉ nhận job khi VRAM ước lượng của job còn vừa với phần trống, tức 275 GB trừ 10 GB dự phòng trừ phần các worker khác đã giữ. Bảng ước lượng nằm trong `symdig/gpu_budget.py`: GNN 4–8 GB, XGBoost trên BoT 24 GB (đã hiệu chỉnh theo số đo thật trên B300), và tương tự cho các loại job khác. Có thể chỉnh trong `runtime.vram_gb` hoặc nhân toàn bộ bằng biến môi trường `SYMDIG_VRAM_SCALE`. Phần đã giữ được ghi trong `results/queue/vram_gpu0.json`.
- **E6 (job `deploy`)** giữ cả GPU nên luôn chạy một mình, để số đo thời gian và công suất không bị job khác làm nhiễu. Mọi job E6 phải chạy trên cùng một máy.
- **/dev/shm nhỏ** (thường gặp trong container): worker tự chuyển sang chiến lược chia sẻ `file_system` của torch, nên không bị lỗi "bus error".
- **Tùy chỉnh:** `python launch.py --workers-per-gpu 12 --max-loader-workers 12` để chạy nhiều job hơn, hoặc `--vram-reserve-gb 20` để chừa thêm VRAM dự phòng.
- Trong bài báo, ghi rõ phần cứng của từng nhóm run, ví dụ: E1–E2 trên A100, phần còn lại trên B300. Độ chính xác không phụ thuộc phần cứng, chỉ các số đo chi phí của E6 là phụ thuộc.

### 11.4 Giới hạn RAM của container

Container có thể giới hạn RAM thấp hơn nhiều so với RAM vật lý của máy, ví dụ 450 GiB thay vì 3,9 TiB. Khi tổng RAM của các worker chạm giới hạn này, cả nhóm tiến trình bị kill vì OOM.

`launch.py` đọc giới hạn này từ cgroup và dành 85% làm ngân sách RAM. Mỗi worker chỉ nhận job khi **cả VRAM lẫn RAM ước lượng** của job còn vừa với phần trống. Mức RAM ước lượng được **tính từ kích thước bộ dữ liệu**: số flow và số đặc trưng đọc từ `cache/<bộ>/meta.json`. Ví dụ E8 trên BoT khoảng 80 GB, XGBoost trên BoT khoảng 28 GB, GNN khoảng 11 GB. Sau khi một loại job chạy xong lần đầu, mức RAM **đo thật** của nó (PSS của worker cộng các tiến trình lấy mẫu, nhân hệ số dự phòng 1.15) sẽ thay cho công thức. Số đo được lưu trong `results/queue/ram_observed.json`, và log của mỗi job có dòng `peak host RAM ...`. VRAM cũng được hiệu chỉnh theo cách này: dùng số đo thật nhân 1.2, lưu trong `results/queue/vram_observed.json`, kèm dòng `peak VRAM ...` trong log.

Các tùy chỉnh:
- `--ram-gb 350`: đặt ngân sách RAM bằng tay.
- `SYMDIG_RAM_SCALE=1.3`: tăng toàn bộ mức ước lượng RAM nếu vẫn bị OOM.
- `--max-loader-workers 8` (mặc định mới) và `SYMDIG_PREFETCH=2` (mặc định mới): giảm số tiến trình lấy mẫu dữ liệu và bộ đệm pinned. Kết quả không đổi, vì việc lấy mẫu được cố định seed theo từng batch.

## 12. Tune theo đúng giao thức đánh giá (p1B, p2)

Từ bản này, mọi run trên p1B và p2 dùng siêu tham số được tune trên tập validation của **chính** p1B hoặc p2 (`experiments.tune_on_eval_split: true`). Lý do: p1A là split ngẫu nhiên. Nếu tune trên p1A rồi đánh giá trên p1B, bước chọn siêu tham số đã thấy nhãn của một phần các flow thuộc tập test p1B.

- `python run.py plan E4 E5 E8` thêm khoảng 26 job tune mới (p1B và p2), cùng các run E4 p2, E5 p1B và E8 p1B dùng siêu tham số mới. Các run này có job id mới.
- Các run cũ (tune trên p1A) vẫn được giữ trong `results/`, nhưng `make_tables.py` tự chỉ dùng run mới khi đã có. Danh sách run cũ bị thay thế được ghi trong trường `superseded`.
- E5 transfer, E6 và E7 vẫn dùng tune p1A, vì chúng đánh giá trên p1A.

### E8 có thể chạy tiếp sau khi bị dừng

Sau giai đoạn GNN (phần lâu nhất), E8 lưu đặc trưng đồ thị và đầu ra của GNN vào `results/stage/<job_id>/`. Nếu job bị dừng giữa chừng (OOM, mất máy), lần chạy lại sẽ nạp từ đó và chỉ chạy lại phần XGBoost. Thư mục này tự xóa khi job xong. Với BoT, nó có thể chiếm vài chục GB đĩa.

## 13. HINT: NIDS bất biến theo host (đề cương Host-Invariant NIDS)

Code chính nằm trong `symdig/hostnorm.py` (chuẩn hóa theo host), `symdig/hint.py` (mô hình, huấn luyện, probe) và `symdig/hint_spec.py` (các biến thể).

```bash
python scripts/check_hint.py        # kiểm tra toàn bộ phần torch trên dữ liệu tổng hợp, vài phút
python run.py plan HP               # thử nghiệm nhanh: ToN + IDS2018, 3 seed, chưa tune
python launch.py
python make_tables.py               # bảng H_main, H_ablation, H_probe, H_hosts
# nếu thử nghiệm nhanh đạt tiêu chí (H2, H3 trong đề cương):
python run.py plan H                # đầy đủ: tune ngang ngân sách, 4 bộ, 5 seed, ablation, p1A, quét λ
python launch.py
```

- **Split `p1H`:** dùng đúng tập test của p1B (cùng seed), và tập validation cũng **tách host tấn công** với tập train. Nhờ vậy việc tune và chọn epoch không thưởng cho việc học thuộc host.
- **Các biến thể** (trường `model` của job):

  | Biến thể | Mô tả |
  |---|---|
  | `gnn_plain` | GNN đã sửa sampler, không có thành phần nào của HINT |
  | `hint_gnn` | Đầy đủ: chuẩn hóa theo host, nhánh đối kháng host (gradient reversal), GroupDRO theo host |
  | `hint_gnn_nohn`, `hint_gnn_noadv`, `hint_gnn_nodro` | Ablation: bỏ lần lượt từng thành phần |
  | `hint_flow`, `hint_flow_ftt` | Không dùng đồ thị; encoder MLP hoặc FT-Transformer |
  | `flow_plain` | Mạng flow không có thành phần nào của HINT |

- **Baseline:** XGBoost và MLP, mỗi mô hình chạy cả bản đặc trưng thường lẫn bản có chuẩn hóa theo host (`features: hostnorm`, kiểm tra H3). Tất cả được tune trên validation của p1H.
- **Mỗi run HINT ghi lại:**
  - macro-F1;
  - recall theo từng host tấn công chưa thấy (`host_recall`: p10, trung vị, nhỏ nhất);
  - probe tuyến tính đo mức có thể đoán host từ đầu vào (`probe_input`) và từ biểu diễn (`probe_hid`), kiểm tra H1.
- Thông số mặc định nằm trong `symdig/hint_spec.py` (`DEFAULTS`). Tham số tune được áp lên trên mặc định, sau đó các công tắc ablation (`force`) luôn được ưu tiên cuối cùng.
- Config hash không đổi, nên các job cũ giữ nguyên job id.
