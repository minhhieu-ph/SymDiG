"""VRAM budget for several workers sharing one large GPU (e.g. 1 x B300, 275 GB).

Each worker claims a job only if the job's estimated VRAM fits into what the other workers on the
same GPU have reserved. Claiming and reserving happen under one file lock, so two workers cannot
over-commit the GPU at the same time. Reservations of dead workers are dropped automatically.

Estimates are deliberately conservative (GB). Override any of them without touching the hashed
configuration, e.g. in configs/default.yaml -> runtime.vram_gb, or scale all of them with the
environment variable SYMDIG_VRAM_SCALE.
Jobs that measure time / power (E6 "deploy") reserve the whole GPU so that they run alone.
"""
import fcntl
import json
import os
import socket
import time

HOST = socket.gethostname()

DEFAULT_VRAM_GB = {
    "cpu": 0,                        # prepare, coverage, survival
    "gnn": {"default": 12, "ids2018": 24, "bot": 24},
    "gnn_paper": 32,                 # Multi-GNN released hyper-parameters (fan-out 100, batch 8192)
    "tabular_xgb": {"default": 16, "unsw": 8, "ton": 32, "ids2018": 32, "bot": 64},
    "tabular_mlp": 8,
    "hybrid": {"default": 32, "unsw": 12, "bot": 64},
    "fecograph": 24,
    "exclusive": -1,                 # whole GPU
}
CPU_KINDS = {"prepare", "coverage", "survival", "sizes"}
EXCLUSIVE_KINDS = {"deploy"}


def _by_ds(v, ds):
    if isinstance(v, dict):
        return v.get(ds, v.get("default", 0))
    return v


def estimate_gb(spec, cfg, capacity):
    table = dict(DEFAULT_VRAM_GB)
    table.update((cfg.get("runtime") or {}).get("vram_gb") or {})
    kind, ds, model = spec["kind"], spec.get("dataset", ""), spec.get("model") or ""
    tabular = model in ("xgboost", "rf", "mlp")
    if kind in CPU_KINDS:
        need = table["cpu"]
    elif kind in EXCLUSIVE_KINDS:
        need = capacity
    elif kind in ("tabular",) or (kind == "tune" and tabular):
        need = _by_ds(table["tabular_mlp"] if model == "mlp" else table["tabular_xgb"], ds)
    elif kind == "hybrid":
        need = _by_ds(table["hybrid"], ds)
    elif kind == "fecograph":
        need = _by_ds(table["fecograph"], ds)
    elif spec.get("preset") == "multignn_paper":
        need = _by_ds(table["gnn_paper"], ds)
    else:                                      # gnn, tune (gnn), reeval, transfer, evasion
        need = _by_ds(table["gnn"], ds)
        if (spec.get("overrides") or {}).get("sampler.backend"):   # T1: uncapped PyG sampler
            need *= 2
    need = float(need) * float(os.environ.get("SYMDIG_VRAM_SCALE", 1.0))
    return min(need, capacity)


class GpuBudget:
    def __init__(self, results, gpu_id, capacity_gb):
        d = os.path.join(results, "queue")
        os.makedirs(d, exist_ok=True)
        self.ledger = os.path.join(d, f"vram_gpu{gpu_id}.json")
        self.lockf = self.ledger + ".lock"
        self.capacity = float(capacity_gb)

    def _load(self):
        try:
            led = json.load(open(self.ledger))
        except (FileNotFoundError, json.JSONDecodeError):
            led = {}
        alive = {}
        for jid, r in led.items():
            if r.get("host") != HOST:     # written on another machine (e.g. results copied over)
                continue
            try:
                os.kill(int(r["pid"]), 0)
                alive[jid] = r
            except (OSError, ValueError):
                pass
        return alive

    def _save(self, led):
        tmp = f"{self.ledger}.tmp{os.getpid()}"
        with open(tmp, "w") as fh:
            json.dump(led, fh, indent=1)
        os.replace(tmp, self.ledger)

    def reserved(self):
        return sum(r["gb"] for r in self._load().values())

    def claim(self, q, accept, need_fn):
        """Claim the next runnable job that fits. Returns (spec, gb) or (None, 0)."""
        with open(self.lockf, "a") as lk:
            fcntl.flock(lk, fcntl.LOCK_EX)
            try:
                led = self._load()
                free = self.capacity - sum(r["gb"] for r in led.values())
                fit = lambda s: (accept is None or accept(s)) and need_fn(s) <= free + 1e-9
                spec, _ = q.claim(fit)
                if spec is None:
                    return None, 0.0
                gb = need_fn(spec)
                led[spec["id"]] = {"pid": os.getpid(), "host": HOST, "gb": gb, "kind": spec["kind"],
                                   "dataset": spec.get("dataset"), "since": time.time()}
                self._save(led)
                return spec, gb
            finally:
                fcntl.flock(lk, fcntl.LOCK_UN)

    def release(self, jid):
        with open(self.lockf, "a") as lk:
            fcntl.flock(lk, fcntl.LOCK_EX)
            try:
                led = self._load()
                led.pop(jid, None)
                self._save(led)
            finally:
                fcntl.flock(lk, fcntl.LOCK_UN)
