# Copied VERBATIM from the user's code (source/data_loader.py, TargetEdgeLoader v4).
# Do not edit: symdig/tel.py adapts it to the SymDiG batch format without changing its logic.
"""
TargetEdgeLoader (v4)
=====================
Loader cho edge classification trên MULTIGRAPH CÓ HƯỚNG với PyG.

Điểm mới so với v3
------------------
1. LINH HOẠT KIỂU DỮ LIỆU: nhận vào
     - Data       : đồ thị homogeneous có hướng (một loại cạnh u->v), hoặc
     - HeteroData : hai quan hệ ('node','to','node') và ('node','rev_to','node')
                    đại diện cạnh xuôi / cạnh đảo (rev_to = to.flipud, dùng
                    chung edge_attr).
   Loader tự phát hiện kiểu và trả về batch CÙNG KIỂU với input.

2. HAI MODE (đều LUÔN ép đủ cạnh target — không còn tùy chọn):
     - "in-edges"   : chỉ mở rộng neighborhood theo hướng ĐI VÀO seed.
     - "both-edges" : mở rộng theo cả hướng đi vào lẫn đi ra.

3. num_neighbors nhận List[int] HOẶC Dict (theo edge type).

4. BỎ HẲN flow_id_col: e_id nội bộ luôn là arange(E). edge_attr giữ nguyên
   toàn bộ là feature thật.

Đảm bảo 100% cạnh target: duyệt target qua DataLoader thuần + ép target vào
subgraph bằng union trên e_id. Target luôn định danh trên cạnh xuôi ('to').
"""

from __future__ import annotations

from typing import Dict, List, Optional, Union

import torch
from torch import Tensor
from torch.utils.data import DataLoader
from torch_geometric.data import Data, HeteroData
from torch_geometric.sampler import NeighborSampler, NodeSamplerInput


TO = ('node', 'to', 'node')
REV = ('node', 'rev_to', 'node')

NumNeighbors = Union[List[int], Dict]


def _collate_eids(x):
    return torch.stack(x) if isinstance(x, list) else x


class TargetEdgeLoader:
    def __init__(
        self,
        data: Union[Data, HeteroData],
        target_edge_ids: Tensor,
        num_neighbors: NumNeighbors,
        sample_mode: str = "both-edges",     # "in-edges" | "both-edges"
        batch_size: int = 4096,
        shuffle: bool = True,
        num_workers: int = 0,
    ) -> None:
        assert sample_mode in ("in-edges", "both-edges"), \
            "sample_mode phải là 'in-edges' hoặc 'both-edges'."
        self.is_hetero = isinstance(data, HeteroData)
        self.data = data
        self.sample_mode = sample_mode
        self.batch_size = batch_size

        # ---- Trích edge_index / edge_attr / y / x / num_nodes thống nhất ----
        if self.is_hetero:
            assert TO in data.edge_types, "HeteroData thiếu ('node','to','node')."
            self.edge_index = data[TO].edge_index            # [2, E] cạnh xuôi
            self.edge_attr = data[TO].get('edge_attr', None)
            self.y = data[TO].get('y', None)
            self.x = data['node'].get('x', None)
            self.num_nodes = data['node'].num_nodes
        else:
            self.edge_index = data.edge_index                # [2, E]
            self.edge_attr = data.get('edge_attr', None)
            # self.y = data.get('edge_label', None)            # nhãn cạnh (nếu có)
            self.y = data.get('y', None)
            self.x = data.get('x', None)
            self.num_nodes = data.num_nodes

        self.E = self.edge_index.size(1)
        self.target_edge_ids = target_edge_ids.long().view(-1)

        # ---- Đồ thị dùng cho SAMPLING ----
        # e_id nội bộ = arange(E) (cạnh xuôi). Với "both-edges" ta bổ sung cạnh
        # đảo để sampler mở rộng theo hướng đi ra; các cạnh đảo này CHỈ dùng để
        # tìm neighbor, không bao giờ là target.
        ei = self.edge_index
        if sample_mode == "both-edges":
            rev = ei.flip(0)
            sample_edge_index = torch.cat([ei, rev], dim=1)  # [2, 2E]
            # id trong không gian sampling: [0,E) là xuôi, [E,2E) là đảo.
            self._orig_eid = torch.cat([torch.arange(self.E),
                                        torch.arange(self.E)])
        else:  # "in-edges": chỉ cạnh xuôi; sampler mặc định đi theo in-edges.
            sample_edge_index = ei
            self._orig_eid = torch.arange(self.E)
        self._sample_edge_index = sample_edge_index
        self._S = sample_edge_index.size(1)

        sample_data = Data(edge_index=sample_edge_index, num_nodes=self.num_nodes)
        self.sampler = NeighborSampler(
            sample_data, num_neighbors=self._normalize_num_neighbors(num_neighbors),
        )

        # ---- Buffers tái sử dụng (E, N lớn -> reset O(batch)) ----
        self._eid_to_local = torch.full((self.E,), -1, dtype=torch.long)
        self._node_map = torch.full((self.num_nodes,), -1, dtype=torch.long)

        self._edge_loader = DataLoader(
            self.target_edge_ids, batch_size=batch_size, shuffle=shuffle,
            num_workers=num_workers, collate_fn=_collate_eids,
        )

    # ------------------------------------------------------------------ #
    def _normalize_num_neighbors(self, num_neighbors: NumNeighbors):
        """Chấp nhận List[int] hoặc Dict. Sampler nội bộ chạy trên đồ thị
        HOMOGENEOUS (kể cả khi input là HeteroData, ta đã hợp nhất về một
        edge_index), nên cần trả về List[int]."""
        if isinstance(num_neighbors, dict):
            # Ưu tiên lấy fanout của quan hệ 'to'; nếu không có, lấy value đầu.
            if TO in num_neighbors:
                return list(num_neighbors[TO])
            return list(next(iter(num_neighbors.values())))
        return list(num_neighbors)

    def __len__(self):
        return len(self._edge_loader)

    def __iter__(self):
        for batch_eids in self._edge_loader:
            yield self._build_batch(batch_eids.long().view(-1))

    # ------------------------------------------------------------------ #
    def _build_batch(self, batch_eids: Tensor):
        ei = self.edge_index

        # 1) Seed nodes = endpoint của cạnh target.
        seed_nodes = torch.cat([ei[0, batch_eids], ei[1, batch_eids]]).unique()

        # 2) Sample quanh seed trên đồ thị-sampling.
        out = self.sampler.sample_from_nodes(
            NodeSamplerInput(input_id=None, node=seed_nodes)
        )
        sub_nodes = out.node
        sub_s_eids = out.edge                 # id trong KHÔNG GIAN SAMPLING

        # 3) LUÔN ép cạnh target (bản xuôi) vào subgraph.
        #    Trong không gian sampling, cạnh xuôi target có id == batch_eids
        #    (vì [0,E) là phần xuôi, khớp arange).
        all_s_eids = torch.cat([sub_s_eids, batch_eids]).unique()
        orig_eid = self._orig_eid[all_s_eids]      # id cạnh GỐC để tra attr/edge_index

        # 4) Node global -> local (buffer tái sử dụng).
        used_nodes = torch.cat([
            sub_nodes,
            self._sample_edge_index[0, all_s_eids],
            self._sample_edge_index[1, all_s_eids],
        ]).unique()
        self._node_map[used_nodes] = torch.arange(used_nodes.size(0))

        # 5) edge_index cục bộ theo KHÔNG GIAN SAMPLING (giữ đúng chiều đảo
        #    cho những cạnh đảo mà sampler kéo vào ở mode both-edges).
        local_edge_index = self._node_map[self._sample_edge_index[:, all_s_eids]]

        # 6) edge_attr theo cạnh GỐC (cạnh đảo tra về attr của cạnh gốc).
        edge_attr = None
        if self.edge_attr is not None:
            edge_attr = self.edge_attr[orig_eid].contiguous()

        # 7) Định vị target bằng e_id — CHỈ cạnh xuôi mới là target.
        #    Ở không gian sampling: cạnh xuôi là các id < E.
        is_forward = all_s_eids < self.E
        self._eid_to_local.fill_(-1)
        fwd_positions = torch.arange(all_s_eids.size(0))[is_forward]
        self._eid_to_local[all_s_eids[is_forward]] = fwd_positions
        target_edge_local_idx = self._eid_to_local[batch_eids]
        assert (target_edge_local_idx >= 0).all(), \
            "Cạnh target không nằm trong subgraph — kiểm tra bước ép (3)."

        # 8) Node features + nhãn của target.
        x = self.x[used_nodes] if self.x is not None else None
        y = self.y[batch_eids] if self.y is not None else None

        # 9) Đóng gói batch CÙNG KIỂU với input.
        if self.is_hetero:
            batch = self._pack_hetero(x, local_edge_index, edge_attr,
                                      all_s_eids, orig_eid,
                                      target_edge_local_idx, batch_eids, y,
                                      used_nodes)
        else:
            batch = self._pack_homo(x, local_edge_index, edge_attr,
                                    target_edge_local_idx, batch_eids, y,
                                    used_nodes)

        # 10) Reset buffer node_map: O(batch).
        self._node_map[used_nodes] = -1
        return batch

    # ------------------------------------------------------------------ #
    def _pack_homo(self, x, local_edge_index, edge_attr,
                   target_edge_local_idx, batch_eids, y, used_nodes) -> Data:
        batch = Data(x=x, edge_index=local_edge_index, edge_attr=edge_attr)
        batch.num_nodes = used_nodes.size(0)
        batch.target_edge_local_idx = target_edge_local_idx
        batch.target_edge_global_id = batch_eids
        if y is not None:
            # batch.edge_label = y
            batch.y = y
        batch.n_id = used_nodes
        return batch

    def _pack_hetero(self, x, local_edge_index, edge_attr,
                     all_s_eids, orig_eid, target_edge_local_idx,
                     batch_eids, y, used_nodes) -> HeteroData:
        """Tách các cạnh trong subgraph thành hai quan hệ to / rev_to đúng
        schema đầu vào. Cạnh xuôi -> to; cạnh đảo -> rev_to. Đảm bảo mỗi cạnh
        target có mặt ở 'to', và bản đảo của nó có mặt ở 'rev_to' (đối xứng)."""
        is_forward = all_s_eids < self.E

        batch = HeteroData()
        if x is not None:
            batch['node'].x = x
        batch['node'].num_nodes = used_nodes.size(0)

        # --- quan hệ 'to' (cạnh xuôi) ---
        to_ei = local_edge_index[:, is_forward]
        batch[TO].edge_index = to_ei
        if edge_attr is not None:
            batch[TO].edge_attr = edge_attr[is_forward]

        # --- quan hệ 'rev_to' ---
        # Với "both-edges": lấy đúng các cạnh đảo sampler kéo vào.
        # Với "in-edges": không có cạnh đảo trong all_s_eids, nên rev_to được
        # dựng bằng flip của toàn bộ cạnh 'to' (đảm bảo đối xứng cho target và
        # cho mọi cạnh 'to' trong subgraph).
        if self.sample_mode == "both-edges":
            rev_mask = ~is_forward
            if rev_mask.any():
                batch[REV].edge_index = local_edge_index[:, rev_mask]
                if edge_attr is not None:
                    batch[REV].edge_attr = edge_attr[rev_mask]
            else:
                batch[REV].edge_index = to_ei.flip(0)
                if edge_attr is not None:
                    batch[REV].edge_attr = edge_attr[is_forward]
        else:  # in-edges -> rev_to = flip của to
            batch[REV].edge_index = to_ei.flip(0)
            if edge_attr is not None:
                batch[REV].edge_attr = edge_attr[is_forward]

        # --- target + nhãn: chỉ trên 'to' ---
        # target_edge_local_idx đang trỏ theo chỉ số trong all_s_eids; cần
        # chuyển sang chỉ số trong không gian 'to' (chỉ cạnh xuôi).
        # Xây map: vị-trí-trong-all_s_eids (forward) -> vị-trí-trong-to.
        fwd_positions = torch.arange(all_s_eids.size(0))[is_forward]
        pos_in_to = torch.full((all_s_eids.size(0),), -1, dtype=torch.long)
        pos_in_to[fwd_positions] = torch.arange(fwd_positions.size(0))
        target_idx_in_to = pos_in_to[target_edge_local_idx]
        assert (target_idx_in_to >= 0).all()

        batch[TO].target_edge_local_idx = target_idx_in_to
        batch[TO].target_edge_global_id = batch_eids
        if y is not None:
            batch[TO].y = y
        batch['node'].n_id = used_nodes
        return batch


# ---------------------------------------------------------------------- #
def read_edge_logits(node_emb, edge_index, target_edge_local_idx, edge_mlp=None):
    """Homogeneous: edge_index = batch.edge_index.
       Hetero: edge_index = batch[('node','to','node')].edge_index."""
    s = edge_index[0, target_edge_local_idx]
    d = edge_index[1, target_edge_local_idx]
    feat = torch.cat([node_emb[s], node_emb[d]], dim=-1)
    return edge_mlp(feat) if edge_mlp is not None else feat