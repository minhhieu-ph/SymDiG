#!/usr/bin/env bash
# Create the conda environment for SymDiG on a new machine (tested target: 1 x NVIDIA B300, Ubuntu 24.04).
#
#   bash env/setup_env.sh                 # env name "symdig"
#   bash env/setup_env.sh myenv
# Optional overrides:  PYTHON_VERSION=3.11  TORCH_VERSION=2.9.1  CUDA_TAG=cu130|cu128
#
# CUDA build selection: driver >= 580 -> cu130 wheels (CUDA 13), otherwise cu128 (CUDA 12.8).
# Both contain sm_100 kernels, which run on B300 (sm_103, same major architecture).
set -euo pipefail

ENV_NAME=${1:-symdig}
PYTHON_VERSION=${PYTHON_VERSION:-3.11}
TORCH_VERSION=${TORCH_VERSION:-2.9.1}
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v conda >/dev/null 2>&1; then
  echo "conda not found. Install Miniconda first, e.g.:"
  echo "  wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh && bash Miniconda3-latest-Linux-x86_64.sh -b -p \$HOME/miniconda3"
  echo "  source \$HOME/miniconda3/bin/activate"
  exit 1
fi

DRIVER=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1 || true)
if [ -z "${CUDA_TAG:-}" ]; then
  if [ -n "$DRIVER" ] && [ "${DRIVER%%.*}" -ge 580 ]; then CUDA_TAG=cu130; else CUDA_TAG=cu128; fi
fi
echo "[setup] driver ${DRIVER:-none} -> PyTorch ${TORCH_VERSION}+${CUDA_TAG}, Python ${PYTHON_VERSION}, env ${ENV_NAME}"

eval "$(conda shell.bash hook)"
if conda env list | awk '{print $1}' | grep -qx "$ENV_NAME"; then
  echo "[setup] env ${ENV_NAME} exists -> reusing it"
else
  conda create -y -n "$ENV_NAME" "python=${PYTHON_VERSION}"
fi
conda activate "$ENV_NAME"
python -m pip install --upgrade pip wheel

# 1. PyTorch for the chosen CUDA build
pip install "torch==${TORCH_VERSION}" --index-url "https://download.pytorch.org/whl/${CUDA_TAG}"

# 2. XGBoost with GPU support matching the CUDA major version
if [ "$CUDA_TAG" = "cu130" ]; then
  pip install xgboost                      # default Linux wheel is built with CUDA 13
else
  pip uninstall -y xgboost >/dev/null 2>&1 || true
  pip install xgboost-cu12                 # CUDA 12 build of XGBoost
fi

# 3. the rest (PyG is pure Python here; no torch-scatter / torch-sparse needed)
pip install -r "${HERE}/requirements-base.txt"

# 4. pyg-lib: needed only by T1 (TargetEdgeLoader -> PyG NeighborSampler) and repro/digrsb_repro.py
TV=$(python -c "import torch; v=torch.__version__.split('+')[0].split('.'); print(f'{v[0]}.{v[1]}.0')")
if ! pip install pyg_lib -f "https://data.pyg.org/whl/torch-${TV}+${CUDA_TAG}.html"; then
  echo "[setup] WARNING: no pyg-lib wheel for torch ${TV}+${CUDA_TAG}; T1 and the DiG-RSB repro will not run."
  echo "        Try: TORCH_VERSION=<a version listed on https://data.pyg.org/whl/> bash env/setup_env.sh ${ENV_NAME}"
fi

echo "[setup] done. Next:  conda activate ${ENV_NAME} && python env/check_env.py"
