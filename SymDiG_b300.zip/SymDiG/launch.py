"""Start one worker process per GPU (or several per GPU) on this machine / pod.

  python launch.py                          # all visible GPUs; workers per GPU chosen from its VRAM
  python launch.py --gpus 0 1 2 3 --workers-per-gpu 1 --cpus 11
  python launch.py --workers-per-gpu 8      # e.g. 1 x B300 (275 GB): 8 workers share it under a VRAM budget
  python launch.py --kinds prepare coverage sizes survival --gpus none --workers 4   # CPU-only jobs

Several pods (Kubeflow) can run launch.py at the same time against the same --results and
cache directories on a shared volume: jobs are claimed by atomic rename, so each job runs once.
Workers exit when the queue is empty. Logs: results/logs/<job>.log and results/workers/*.log.
"""
import argparse
import os
import subprocess
import sys
import time


def detect_gpus():
    """[(index, total MiB)] of the visible GPUs."""
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.total", "--format=csv,noheader,nounits"],
                             capture_output=True, text=True, check=True).stdout
        res = []
        for l in out.splitlines():
            if l.strip():
                i, m = [x.strip() for x in l.split(",")]
                res.append((i, float(m)))
        return res
    except Exception:
        return []


def auto_workers_per_gpu(mib):
    gb = mib / 1024
    if gb >= 160:
        return 8          # B200 / B300 / GB200 class
    if gb >= 70:
        return 2          # H100 / A100 80 GB
    return 1


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gpus", nargs="+", default=None, help="GPU indices, or 'none' for CPU-only workers")
    ap.add_argument("--workers-per-gpu", type=int, default=None,
                    help="default: 8 on >=160 GB GPUs, 2 on >=70 GB, else 1")
    ap.add_argument("--max-loader-workers", type=int, default=16, help="cap on DataLoader workers per job")
    ap.add_argument("--vram-reserve-gb", type=float, default=10.0, help="VRAM kept free per GPU (driver, context)")
    ap.add_argument("--workers", type=int, default=None, help="number of CPU-only workers (with --gpus none)")
    ap.add_argument("--cpus", type=int, default=os.cpu_count(), help="CPU cores to share among the workers")
    ap.add_argument("--results", default="results")
    ap.add_argument("--kinds", nargs="+", default=None)
    args = ap.parse_args()

    if args.gpus == ["none"]:
        slots = [None] * (args.workers or 1)
    else:
        found = dict(detect_gpus())
        gpus = args.gpus or list(found)
        if not gpus:
            sys.exit("no GPU found; use --gpus none --workers N for CPU-only jobs")
        mib = {g: found.get(g, 40960.0) for g in gpus}
        wpg = {g: args.workers_per_gpu or auto_workers_per_gpu(mib[g]) for g in gpus}
        slots = [g for g in gpus for _ in range(wpg[g])]
    n = len(slots)
    threads = max(1, args.cpus // n)
    loader_workers = max(1, min(threads - 1, args.max_loader_workers))
    os.makedirs(os.path.join(args.results, "workers"), exist_ok=True)
    for g in set(x for x in slots if x is not None):      # fresh VRAM ledger for the GPUs we drive
        f = os.path.join(args.results, "queue", f"vram_gpu{g}.json")
        if os.path.exists(f):
            os.remove(f)
    procs = []
    for i, g in enumerate(slots):
        env = dict(os.environ, SYMDIG_THREADS=str(threads), SYMDIG_NUM_WORKERS=str(loader_workers),
                   OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", PYTHONUNBUFFERED="1")
        env["CUDA_VISIBLE_DEVICES"] = "" if g is None else str(g)
        if g is not None and wpg[g] > 1:       # shared GPU -> VRAM admission control
            env["SYMDIG_GPU_ID"] = str(g)
            env["SYMDIG_GPU_CAPACITY_GB"] = f"{mib[g] / 1024 - args.vram_reserve_gb:.1f}"
            env.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
        cmd = [sys.executable, "run.py", "worker", "--results", args.results]
        if args.kinds:
            cmd += ["--kinds", *args.kinds]
        log = open(os.path.join(args.results, "workers", f"worker{i}_gpu{g}.log"), "a")
        procs.append((subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT), log))
        print(f"worker {i}: GPU {g}, {threads} threads, {loader_workers} sampling workers"
              + (f", VRAM budget {env['SYMDIG_GPU_CAPACITY_GB']} GB shared by {wpg[g]} workers"
                 if g is not None and wpg[g] > 1 else ""))
        time.sleep(2)  # stagger start-up (first jobs read the same files)
    try:
        while any(p.poll() is None for p, _ in procs):
            time.sleep(30)
    except KeyboardInterrupt:
        for p, _ in procs:
            p.terminate()
    for p, log in procs:
        log.close()
    print("all workers finished; `python run.py status` for a summary")


if __name__ == "__main__":
    main()
