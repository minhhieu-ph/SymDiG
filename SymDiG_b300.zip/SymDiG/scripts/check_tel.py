"""Sanity check for T1 (TargetEdgeLoader backend). Run once before `python run.py plan T1`:

    python scripts/check_tel.py                 # synthetic multigraph, ~10 s
    python scripts/check_tel.py --dataset ton   # also on the real ToN training graph (needs `prepare`)

Checks, for tel_orig and tel_fixed:
  * every target is in its batch and the bookkeeping (tpos) points at the right edge
  * edge consistency (share of sampled edges whose endpoints are both sampled nodes):
    a correct neighbour sampler gives 1.000; tel_orig is expected to be far below 1 because it uses
    PyG's CSC positions as edge ids; tel_fixed must be exactly 1.000
  * with tel_fixed, every non-target edge in the batch is within `len(fanout)` hops of a target endpoint
  * one forward/backward pass of the rung-1 model on a TEL batch
"""
import argparse
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symdig.data import Graph  # noqa: E402
from symdig.loader import SubgraphBatches  # noqa: E402
from symdig.sampler import build_batch  # noqa: E402
from symdig.tel import build_batch_tel  # noqa: E402


def hops_ok(graph, b, K):
    """All edges of the batch lie within K hops (undirected) of the targets' endpoints."""
    src, dst = graph.src, graph.dst
    frontier = np.unique(np.concatenate([src[b["targets"]], dst[b["targets"]]]))
    reach = set(frontier.tolist())
    allowed = set()
    for _ in range(K):
        nxt = []
        for n in frontier:
            for ptr, eid in ((graph.in_ptr, graph.in_eid), (graph.out_ptr, graph.out_eid)):
                es = np.asarray(eid[ptr[n]:ptr[n + 1]])
                allowed.update(es.tolist())
                nxt.append(src[es]); nxt.append(dst[es])
        nb = np.unique(np.concatenate(nxt)) if nxt else np.zeros(0, np.int64)
        frontier = np.array([x for x in nb.tolist() if x not in reach], np.int64)
        reach.update(frontier.tolist())
    edges = np.union1d(b["ef_ids"], b["er_ids"])
    return float(np.isin(edges, np.fromiter(allowed, np.int64)).mean())


def check(graph, targets, fanout, label, bs=512, n_batches=5, hop_check=True):
    rng = np.random.default_rng(0)
    print(f"\n[{label}] graph: {graph.n_edges:,} edges, {graph.num_nodes:,} nodes | fanout {fanout}")
    res = {}
    for be in ("tel_orig", "tel_fixed"):
        cons, hops, ne = [], [], []
        for i in range(n_batches):
            t = rng.choice(targets, bs, replace=False)
            b = build_batch_tel(graph, t, {"coupled": False, "force": True}, {"backend": be, "fanout": fanout}, rng)
            assert b["present"].all() and np.array_equal(b["ef_ids"][b["tpos"]], b["targets"])
            cons.append(b["tel_consistency"])
            ne.append(len(b["ef_ids"]) + len(b["er_ids"]))
            if hop_check and i < 2:
                hops.append(hops_ok(graph, b, len(fanout)))
        res[be] = np.mean(cons)
        print(f"  {be:10s} edge consistency {np.mean(cons):.3f} | edges/batch {np.mean(ne):,.0f}"
              + (f" | edges within {len(fanout)} hops of targets {np.mean(hops):.3f}" if hops else "")
              + f" | perm is identity: {b['tel_perm_is_identity']}")
    nb = build_batch(graph, rng.choice(targets, bs, replace=False), {"coupled": False, "force": True},
                     {"fanout": fanout, "max_hop_edges": None}, rng)
    print(f"  native     edges/batch {len(nb['ef_ids']) + len(nb['er_ids']):,} (B in + B out per node and hop)")
    assert res["tel_fixed"] > 0.999, "tel_fixed must give edge consistency 1.0"
    return res


def forward_pass(graph, targets):
    import torch
    from symdig.models import build_model

    class Store:
        dim = 8

        def gather(self, ids):
            r = np.random.default_rng(1)
            return r.standard_normal((len(ids), 8)).astype(np.float32)
    labels = np.random.default_rng(2).integers(0, 3, len(graph.src))
    ds = SubgraphBatches(graph, Store(), labels, targets[:1024], 256, {"coupled": False, "force": True},
                         {"backend": "tel_fixed", "fanout": [10, 10]}, shuffle=True, seed=0)
    b = ds[0]
    model = build_model({"arch": "hetero", "coupled": False, "force": True}, 8, 3)
    out = model(b)
    loss = torch.nn.functional.cross_entropy(out["logits"], b["y"])
    loss.backward()
    print(f"\n[model] rung-1 forward/backward on a TEL batch: logits {tuple(out['logits'].shape)}, "
          f"loss {loss.item():.3f}, tel_consistency {b['tel_consistency']:.3f}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default=None)
    ap.add_argument("--config", default="configs/default.yaml")
    a = ap.parse_args()
    rng = np.random.default_rng(0)
    N, E = 3000, 60000
    w = rng.pareto(1.2, N) + 1                      # heavy-tailed degrees (hubs), unsorted edge order
    src = rng.choice(N, E, p=w / w.sum()).astype(np.int64)
    dst = rng.choice(N, E, p=w / w.sum()).astype(np.int64)
    eids = np.sort(rng.choice(E, int(0.8 * E), replace=False))
    g = Graph.build(src, dst, eids, N)
    check(g, eids, [20, 20], "synthetic")
    forward_pass(g, eids)
    if a.dataset:
        from symdig.data import NetFlowData, get_split, graph_for
        from symdig.jobs import load_config
        cfg = load_config(a.config)
        data = NetFlowData(cfg, a.dataset)
        split = get_split(cfg, data, "p1A")
        gt = graph_for(data, split, "train")
        check(gt, np.asarray(split.train), list(cfg["sampler"]["fanout"]), a.dataset, bs=4096, n_batches=5,
              hop_check=False)
    print("\nOK")


if __name__ == "__main__":
    main()
