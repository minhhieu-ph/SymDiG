#!/usr/bin/env bash
# Factor decomposition of the DiG-RSB numbers with the original code (one run per GPU).
# Usage:  bash repro/run_digrsb.sh ton        (or unsw)
#         EPOCHS=30 MAX_STEPS=0 bash repro/run_digrsb.sh ton
set -e
DS=${1:-ton}
case $DS in
  ton)  CSV=$(ls dataset/*[Tt]o[Nn]-[Ii]o[Tt]*v2*.csv | head -1) ;;
  unsw) CSV=$(ls dataset/*UNSW*v2*.csv | head -1) ;;
  ids2018) CSV=$(ls dataset/*IDS2018*v2*.csv | head -1) ;;
  bot)  CSV=$(ls dataset/*[Bb]o[Tt]-[Ii]o[Tt]*v2*.csv | head -1) ;;
esac
EPOCHS=${EPOCHS:-30}
MAX_STEPS=${MAX_STEPS:-0}
REPO=${REPO:-external/DiG-RSB}
mkdir -p results_digrsb/logs
run () {  # gpu tag extra-args...
  local gpu=$1 tag=$2; shift 2
  CUDA_VISIBLE_DEVICES=$gpu nohup python repro/digrsb_repro.py --repo "$REPO" --data "$CSV" --tag "${DS}_${tag}" \
     --epochs "$EPOCHS" --max-steps "$MAX_STEPS" --out "$(pwd)/results_digrsb" "$@" \
     > "results_digrsb/logs/${DS}_${tag}.log" 2>&1 &
}
run 0 paper
run 1 constx  --x-mode const
run 2 unkport --ports-mode unk
run 3 constx_unkport --x-mode const --ports-mode unk
wait
python repro/summarize.py
