"""Summary table of results_digrsb/*.json (macro-F1 %)."""
import glob
import json
import os
import sys

root = sys.argv[1] if len(sys.argv) > 1 else "results_digrsb"
rows = []
for f in sorted(glob.glob(os.path.join(root, "*.json"))):
    r = json.load(open(f))
    s = r["summary"]
    rows.append((r["tag"], len(r["history"]), 100 * s["paper_style_max_test"], 100 * s["protocol_test_at_best_val"],
                 s["best_val_epoch"], 100 * s["last_test"]))
print(f"{'run':28s} {'epochs':>6s} {'paper-style (max test)':>23s} {'test @ best val':>16s} {'best val ep':>11s} {'last':>7s}")
for t in rows:
    print(f"{t[0]:28s} {t[1]:6d} {t[2]:23.2f} {t[3]:16.2f} {t[4]:11d} {t[5]:7.2f}")
