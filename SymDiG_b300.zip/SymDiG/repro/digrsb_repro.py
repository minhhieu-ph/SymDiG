"""Reproduce DiG-RSB (github.com/minhhieu-ph/DiG-RSB) with its OWN code, under a protocol
that has a held-out test set, and isolate the factors behind its ToN/UNSW numbers.

What the original pipeline does (data_preprocessing.get_data + training.train):
  * one 75/25 stratified split (random_state=89); the 25 % "valid" part is also the reported
    test set, and the paper number is the BEST macro-F1 on it over 200 epochs
  * node features x = [1, in_degree + 1, out_degree + 1] (raw degrees of the IP graph) + ego ID
  * source/destination ports as vocabulary indices -> nn.Embedding (top 30 000 ports, freq >= 100)
  * GATv2 encoder (3 convs per layer x 2 layers) on the sampled subgraph and on its flip, MHA fusion

This harness imports the repository unmodified (data_utils, models, training, train_utils,
balanced_mse) and only changes how the data are split and how epochs are evaluated:
  * the paper's 25 % part is kept as the TEST set (same rows, random_state=89)
  * a validation set (val_frac of the 75 %) is carved out of the training part
  * every epoch we record validation AND test macro-F1, so we can report
        paper-style  = max over epochs of test macro-F1 (what the paper reports)
        protocol     = test macro-F1 at the epoch with the best validation macro-F1
        last         = test macro-F1 after the final epoch
Ablations (one factor at a time):
  --x-mode const     node features = ones (removes the per-host degree fingerprint)
  --ports-mode unk   every port mapped to <UNK> (removes the port embedding)
GCL/RSM pre-training is not run (it did not change the results according to the authors).

Example (one GPU per run):
  python repro/digrsb_repro.py --repo external/DiG-RSB --data dataset/NF-ToN-IoT-v2.csv --tag ton_paper
  python repro/digrsb_repro.py ... --x-mode const --tag ton_constx
"""
import argparse
import json
import os
import sys
import time
import types

import numpy as np


def stub_wandb():
    try:
        import wandb  # noqa: F401
    except ImportError:
        m = types.ModuleType("wandb")
        m.init = lambda *a, **k: types.SimpleNamespace()
        m.log = lambda *a, **k: None
        m.config = {}
        sys.modules["wandb"] = m


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", default="external/DiG-RSB")
    ap.add_argument("--data", required=True, help="NetFlow v2 CSV")
    ap.add_argument("--tag", required=True)
    ap.add_argument("--out", default="results_digrsb")
    ap.add_argument("--task", default="multiple")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--max-steps", type=int, default=0, help="cap training batches per epoch (0 = full epoch, as the paper)")
    ap.add_argument("--val-frac", type=float, default=0.1)
    ap.add_argument("--seed", type=int, default=1234, help="paper default")
    ap.add_argument("--x-mode", choices=["degree", "const"], default="degree")
    ap.add_argument("--ports-mode", choices=["embed", "unk"], default="embed")
    ap.add_argument("--loss", default="dwb", help="dwb (paper) | ce | wce | bsce | focal")
    ap.add_argument("--layer", default="gatv2")
    ap.add_argument("--no-ego", action="store_true")
    a = ap.parse_args()

    repo = os.path.abspath(a.repo)
    data_path = os.path.abspath(a.data)
    out_dir = os.path.abspath(a.out)
    os.makedirs(out_dir, exist_ok=True)
    stub_wandb()
    sys.path.insert(0, repo)
    os.chdir(repo)                      # the repo writes asset/*.json relative to its root
    os.makedirs("asset", exist_ok=True)

    import pandas as pd
    import torch
    from sklearn.model_selection import train_test_split
    from torch_geometric.utils import degree
    from torch_geometric.data import Data
    import data_utils as du
    import training as tr
    import utils as ut
    from train_utils import AddEgoIds
    from torch_geometric.loader import LinkNeighborLoader

    args = ut.create_parser().parse_args(["--data", data_path, "--task", a.task, "--loss_fn", a.loss,
                                          "--layer", a.layer, "--seed", str(a.seed)] + ([] if a.no_ego else ["--ego"]))
    args.num_neighbors = [int(x) for x in args.num_neighbors]
    ut.set_seed(a.seed)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    name = os.path.basename(data_path).replace(".csv", "")
    t0 = time.time()

    # ---------------- data, exactly as data_preprocessing.get_data, but with a 3-way split
    df, target_names, labels = du.preprocessing(args.task, pd.read_csv(data_path))
    train_df, test_df = du.split_data(df)            # the paper's 75/25 split (random_state=89)
    train_df, val_df = train_test_split(train_df, test_size=a.val_frac, random_state=a.seed,
                                        stratify=train_df["label"])
    print(f"[data] train {len(train_df):,} | val {len(val_df):,} | test {len(test_df):,} | {time.time() - t0:.0f}s", flush=True)
    train_df, train_map = du.create_ip_map_json(train_df, name)
    class_counts = train_df["label"].value_counts().reindex(range(len(labels)), fill_value=1).tolist()
    val_df, val_map = du.map_extend(val_df, train_map)
    test_df, test_map = du.map_extend(test_df, val_map)
    frames = {"train": train_df,
              "val": pd.concat([train_df, val_df], ignore_index=True),
              "test": pd.concat([train_df, val_df, test_df], ignore_index=True)}
    target_ids = {"train": np.arange(len(train_df)),
                  "val": np.arange(len(train_df), len(train_df) + len(val_df)),
                  "test": np.arange(len(train_df) + len(val_df), len(frames["test"]))}
    n_nodes = {"train": len(train_map), "val": len(val_map), "test": len(test_map)}
    if a.ports_mode == "embed":
        vocab = du.build_port_vocab(train_df, "L4_SRC_PORT", "L4_DST_PORT", name, args=args)
    else:
        vocab = {"<UNK>": 0}
    vocab_size = len(vocab)
    for k in frames:
        frames[k] = du.encode_ports(frames[k].copy(), "L4_SRC_PORT", "L4_DST_PORT", vocab)

    # same column handling as the original (identity columns first, then scaled quantitative ones)
    exclude = ['IPV4_SRC_ADDR', 'IPV4_DST_ADDR', 'label', 'L4_SRC_PORT_IDX', 'L4_DST_PORT_IDX', 'SRC_IS_WELL_KNOW',
               'SRC_IS_REGISTERED', 'SRC_IS_DYNAMIC', 'DST_IS_WELL_KNOW', 'DST_IS_REGISTERED', 'DST_IS_DYNAMIC']
    flag_cols = [c for c in frames["train"].columns if "TCP_FLAGS_" in c]
    identity = exclude[3:] + flag_cols
    exclude = exclude + flag_cols
    attr_cols = frames["train"].columns.difference(exclude, sort=False).tolist()
    scaler = None

    def build(k):
        nonlocal scaler
        f = frames[k]
        n = n_nodes[k]
        ei = torch.LongTensor(f[["IPV4_SRC_ADDR", "IPV4_DST_ADDR"]].values).T
        x = torch.ones((n, 3), dtype=torch.float)
        if a.x_mode == "degree":
            x[:, 1] += degree(ei[1], num_nodes=n)
            x[:, 2] += degree(ei[0], num_nodes=n)
        q = f[attr_cols].values
        q, scaler = du.preprocess_selective_feature(q, scaler, scaler is None)
        ea = torch.tensor(np.concatenate([f[identity].values, q], axis=1), dtype=torch.float)
        return Data(x=x, y=torch.LongTensor(f["label"].values), edge_index=ei, edge_attr=ea)

    data = {k: build(k) for k in ("train", "val", "test")}   # scaler fitted on train first
    print(f"[data] graphs built, port vocab {vocab_size}, x-mode {a.x_mode} | {time.time() - t0:.0f}s", flush=True)

    transform = None if a.no_ego else AddEgoIds()
    inds = {k: torch.LongTensor(v) for k, v in target_ids.items()}

    def loader(k, shuffle):
        d = data[k]
        return LinkNeighborLoader(d, num_neighbors=args.num_neighbors, edge_label_index=d.edge_index[:, inds[k]],
                                  edge_label=d.y[inds[k]], batch_size=args.batch_size, shuffle=shuffle,
                                  transform=transform)

    L = {"train": loader("train", True), "val": loader("val", False), "test": loader("test", False)}
    if a.max_steps:
        import itertools

        class Capped:
            def __init__(self, l, n):
                self.l, self.n, self.data = l, n, l.data

            def __iter__(self):
                return itertools.islice(iter(self.l), self.n)

            def __len__(self):
                return min(self.n, len(self.l))
        L["train"] = Capped(L["train"], a.max_steps)
    model = tr.get_model(next(iter(L["val"])), len(labels), vocab_size, args).to(dev)
    optim = torch.optim.AdamW(model.parameters(), lr=0.0005, weight_decay=1e-5)   # as training.train

    def evaluate(k):
        loss = tr.valid(0, L[k], model, inds[k], dev)
        m = model.valid_metrics.compute()
        model.valid_metrics.reset()
        return {"loss": float(loss), "macro_f1": float(m["f1_macro"]), "acc": float(m["acc"]),
                "per_class_f1": {target_names[i]: float(v) for i, v in enumerate(m["f1"].tolist())}}

    hist = []
    for ep in range(a.epochs):
        te = time.time()
        loss = tr.train_one_epoch(ep, model, optim, L["train"], inds["train"], class_counts, dev, args)
        model.train_metrics.reset()
        v, t = evaluate("val"), evaluate("test")
        hist.append({"epoch": ep, "train_loss": float(loss), "val": v, "test": t, "sec": time.time() - te})
        print(f"[epoch {ep}] loss {loss:.4f} | val macro-F1 {v['macro_f1']:.4f} | test macro-F1 {t['macro_f1']:.4f} "
              f"| {time.time() - te:.0f}s", flush=True)
        best = int(np.argmax([h["val"]["macro_f1"] for h in hist]))
        summary = {"paper_style_max_test": max(h["test"]["macro_f1"] for h in hist),
                   "protocol_test_at_best_val": hist[best]["test"]["macro_f1"], "best_val_epoch": best,
                   "last_test": hist[-1]["test"]["macro_f1"]}
        rec = {"tag": a.tag, "args": vars(a), "dataset": name, "classes": target_names, "summary": summary,
               "history": hist, "n": {k: int(len(v)) for k, v in target_ids.items()}, "vocab_size": vocab_size}
        with open(os.path.join(out_dir, f"{a.tag}.json"), "w") as fh:   # rewritten every epoch (safe to stop early)
            json.dump(rec, fh, indent=1)
    print("[summary]", json.dumps(summary))


if __name__ == "__main__":
    main()
