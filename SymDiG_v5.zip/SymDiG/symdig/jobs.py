"""File-based job queue shared by any number of workers / GPUs / pods.

results/queue/{pending,running,done,failed}/<id>.json   job specs (claimed by atomic rename)
results/runs/<id>.json                                   outputs (spec + resolved config + result)
results/index/<exp>.json                                 ids planned for each experiment
results/queue/owners/<id>.json                           host and pid of the worker running a job

If a worker process dies while it runs a job (e.g. killed for using too much host memory), its job
would stay in 'running' for ever and block every job that depends on it. Idle workers therefore
check the owners of running jobs on their host and put orphaned jobs back in the queue
(reap_orphans; at most `max_retries` times, then the job is marked failed with an explanation).

A job id is the hash of its spec without 'exp' / 'after' / 'priority', so the same run
requested by two experiments is executed once. Dependencies: a job is claimable only when
every id in spec['after'] has an output.
"""
import copy
import hashlib
import json
import os
import socket
import time

import yaml

STATES = ("pending", "running", "done", "failed")
HASH_EXCLUDE = ("exp", "after", "priority")


def load_config(path, overrides=()):
    with open(path) as fh:
        cfg = yaml.safe_load(fh)
    for o in overrides or ():
        k, v = o.split("=", 1)
        set_dotted(cfg, k, yaml.safe_load(v))
    return cfg


def set_dotted(cfg, key, value):
    parts = key.split(".")
    d = cfg
    for p in parts[:-1]:
        d = d.setdefault(p, {})
    d[parts[-1]] = value


def deep_update(base, upd):
    for k, v in (upd or {}).items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            deep_update(base[k], v)
        else:
            base[k] = copy.deepcopy(v)
    return base


def job_id(spec):
    s = {k: v for k, v in spec.items() if k not in HASH_EXCLUDE}
    return hashlib.sha1(json.dumps(s, sort_keys=True, default=str).encode()).hexdigest()[:16]


class Queue:
    def __init__(self, root):
        self.root = root
        for s in STATES:
            os.makedirs(os.path.join(root, "queue", s), exist_ok=True)
        for d in ("runs", "index", "ckpt", "logs", "tuned", "models"):
            os.makedirs(os.path.join(root, d), exist_ok=True)

    # ------------------------------------------------------------------ ownership / orphans
    def _owner_path(self, jid):
        return os.path.join(self.root, "queue", "owners", f"{jid}.json")

    def set_owner(self, jid):
        os.makedirs(os.path.join(self.root, "queue", "owners"), exist_ok=True)
        self._write(self._owner_path(jid), {"host": socket.gethostname(), "pid": os.getpid(), "since": time.time()})

    def clear_owner(self, jid):
        try:
            os.remove(self._owner_path(jid))
        except FileNotFoundError:
            pass

    @staticmethod
    def pid_alive(pid):
        try:
            os.kill(int(pid), 0)
        except (OSError, ValueError, TypeError):
            return False
        try:                                   # guard against a recycled pid
            cmd = open(f"/proc/{int(pid)}/cmdline", "rb").read().replace(b"\0", b" ")
            return b"run.py" in cmd or b"python" in cmd
        except OSError:
            return True

    def orphans(self):
        """Running jobs whose recorded worker (on this host) no longer exists, and running jobs
        without an owner record (claimed by code before owner records existed)."""
        dead, unknown = [], []
        host = socket.gethostname()
        for jid in self.list("running"):
            try:
                o = json.load(open(self._owner_path(jid)))
            except FileNotFoundError:
                unknown.append(jid)
                continue
            except json.JSONDecodeError:
                continue
            if o.get("host") == host and not self.pid_alive(o.get("pid")):
                dead.append((jid, o))
        return dead, unknown

    def reap_orphans(self, max_retries=2, log=print):
        n = 0
        for jid, o in self.orphans()[0]:
            src = self.p("running", jid)
            tmp = f"{src}.reap{os.getpid()}"
            try:
                os.rename(src, tmp)            # only one worker reaps a given job
            except OSError:
                continue
            spec = json.load(open(tmp))
            k = int(spec.get("orphan_retries", 0)) + 1
            spec["orphan_retries"] = k
            if k > max_retries:
                err = (f"the worker process (pid {o.get('pid')}) died while running this job, {k} times; "
                       "no Python traceback, so it was killed from outside, most often for using too much host "
                       "memory. See the end of the job log; `python run.py retry` runs it again.")
                self._write(self.p("failed", jid), dict(spec, error=err))
                log(f"[queue] {jid[:8]} {spec['kind']} {spec.get('dataset')}: worker died {k} times -> failed")
            else:
                self._write(self.p("pending", jid), spec)
                log(f"[queue] {jid[:8]} {spec['kind']} {spec.get('dataset')}: worker pid {o.get('pid')} is gone "
                    f"-> back to pending (retry {k}/{max_retries})")
            os.remove(tmp)
            self.clear_owner(jid)
            n += 1
        return n

    def p(self, state, jid):
        return os.path.join(self.root, "queue", state, f"{jid}.json")

    def out(self, jid):
        return os.path.join(self.root, "runs", f"{jid}.json")

    def has_output(self, jid):
        return os.path.exists(self.out(jid))

    def state_of(self, jid):
        for s in STATES:
            if os.path.exists(self.p(s, jid)):
                return s
        return "done" if self.has_output(jid) else None

    def add(self, spec):
        jid = job_id(spec)
        spec = dict(spec, id=jid)
        st = self.state_of(jid)
        if st in ("pending", "running") or self.has_output(jid):
            if st == "pending":   # merge experiment tags / dependencies
                old = json.load(open(self.p("pending", jid)))
                old["exps"] = sorted(set(old.get("exps", [])) | {spec.get("exp")})
                old["after"] = sorted(set(old.get("after", [])) | set(spec.get("after", [])))
                self._write(self.p("pending", jid), old)
            return jid, False
        if st == "failed":
            os.remove(self.p("failed", jid))
        spec["exps"] = [spec.get("exp")]
        self._write(self.p("pending", jid), spec)
        return jid, True

    def _write(self, path, obj):
        tmp = f"{path}.tmp{os.getpid()}"
        with open(tmp, "w") as fh:
            json.dump(obj, fh, indent=1, default=str)
        os.replace(tmp, path)

    def list(self, state):
        d = os.path.join(self.root, "queue", state)
        return sorted(f[:-5] for f in os.listdir(d) if f.endswith(".json"))

    def spec(self, jid):
        for s in STATES:
            if os.path.exists(self.p(s, jid)):
                return json.load(open(self.p(s, jid)))
        if self.has_output(jid):
            return json.load(open(self.out(jid)))["spec"]
        raise KeyError(jid)

    def claim(self, accept=None):
        """Atomically claim the next runnable job (lowest priority first). Returns (spec, n_blocked)."""
        cands = []
        for jid in self.list("pending"):
            try:
                cands.append(json.load(open(self.p("pending", jid))))
            except (FileNotFoundError, json.JSONDecodeError):
                continue
        cands.sort(key=lambda s: (s.get("priority", 50), s["id"]))
        blocked = 0
        for s in cands:
            if accept and not accept(s):
                continue
            deps = s.get("after", [])
            if any(not self.has_output(d) for d in deps):
                blocked += 1
                continue
            try:
                os.rename(self.p("pending", s["id"]), self.p("running", s["id"]))
            except (FileNotFoundError, OSError):
                continue
            return s, blocked
        return None, blocked

    def failed_deps(self, spec):
        return [d for d in spec.get("after", []) if os.path.exists(self.p("failed", d))]

    def finish(self, spec, result, cfg, t0, ok=True, error=None):
        jid = spec["id"]
        rec = {"id": jid, "spec": spec, "cfg": cfg, "result": result, "started": t0, "finished": time.time(),
               "host": socket.gethostname(), "gpu": os.environ.get("CUDA_VISIBLE_DEVICES")}
        if ok:
            self._write(self.out(jid), rec)
            dst = self.p("done", jid)
        else:
            rec["error"] = error
            dst = self.p("failed", jid)
        self._write(dst, dict(spec, error=error) if not ok else spec)
        if os.path.exists(self.p("running", jid)):
            os.remove(self.p("running", jid))
        self.clear_owner(jid)

    def requeue(self, states=("running",)):
        n = 0
        for s in states:
            for jid in self.list(s):
                os.replace(self.p(s, jid), self.p("pending", jid))
                n += 1
        return n

    def record_index(self, exp, ids):
        f = os.path.join(self.root, "index", f"{exp}.json")
        old = json.load(open(f)) if os.path.exists(f) else []
        new = sorted(set(old) | set(ids))
        self._write(f, new)

    def runs_of(self, exp):
        f = os.path.join(self.root, "index", f"{exp}.json")
        if not os.path.exists(f):
            return []
        out = []
        for jid in json.load(open(f)):
            if self.has_output(jid):
                out.append(json.load(open(self.out(jid))))
        return out
