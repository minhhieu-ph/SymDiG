"""All result tables (Markdown summary + LaTeX tabular bodies) from results/runs/.

  python make_tables.py [--results results]
  -> results/tables/summary.md and results/tables/E*.tex
Numbers are mean ± std over seeds (macro-F1 in %, full test set unless stated).
"""
import argparse
import os

import numpy as np

from symdig.report import (DS_ORDER, DS_SHORT, MODEL_NAMES, RUNG_NAMES, fmt_delta, load_runs, macro, mstat, paired_test,
                           select)


class Out:
    def __init__(self, d):
        self.d, self.md = d, ["# SymDiG results (auto-generated)\n"]

    def table(self, name, title, header, rows, note=None):
        if not rows:
            return
        self.md.append(f"\n## {title}\n")
        self.md.append("| " + " | ".join(header) + " |")
        self.md.append("|" + "---|" * len(header))
        for r in rows:
            self.md.append("| " + " | ".join(str(x) for x in r) + " |")
        if note:
            self.md.append(f"\n{note}\n")
        tex = [" & ".join(header) + r" \\", r"\midrule"]
        tex += [" & ".join(str(x).replace("±", r"$\pm$").replace("%", r"\%") for x in r) + r" \\" for r in rows]
        with open(os.path.join(self.d, f"{name}.tex"), "w") as fh:
            fh.write("\n".join(tex) + "\n")

    def save(self):
        with open(os.path.join(self.d, "summary.md"), "w") as fh:
            fh.write("\n".join(self.md) + "\n")


def present_ds(runs):
    s = {r["spec"]["dataset"] for r in runs}
    return [d for d in DS_ORDER if d in s]


def e1(R, O):
    rows = []
    cov = [r for r in select(R, kind="coverage") if r.get("result") and "multignn" in r["result"]
           and not (r["spec"].get("overrides") or {}).get("sampler.backend")]       # T1 runs have their own table
    for r in sorted(cov, key=lambda r: (DS_ORDER.index(r["spec"]["dataset"])
                                                               if r["spec"]["dataset"] in DS_ORDER else 9,
                                                               r["spec"]["fanout"][0])):
        x = r["result"]
        rows.append([DS_SHORT.get(r["spec"]["dataset"], r["spec"]["dataset"]), str(r["spec"]["fanout"]),
                     f"{100 * x['multignn']['seed_coverage']:.1f}", f"{100 * x['multignn']['twin_coverage']:.1f}",
                     f"{100 * x['asym_forced']['twin_coverage']:.1f}", f"{x['multignn']['edges_per_batch']:.0f}",
                     f"{x['coupled_forced']['edges_per_batch']:.0f}"])
    O.table("E1_coverage", "E1 — Sampler diagnosis on the training graph (no training)",
            ["Dataset", "Fan-out", "Seed coverage, Multi-GNN (%)", "Twin coverage, Multi-GNN (%)",
             "Twin coverage, forced (%)", "Edges/batch Multi-GNN", "Edges/batch coupled"], rows,
            "Seed coverage = share of training targets that enter the computation graph and receive a loss. "
            "Twin coverage = share of sampled forward edges whose reverse twin is also sampled.")
    rows = []
    for d in present_ds(select(R, kind="gnn", preset="multignn_paper")):
        rs = select(R, kind="gnn", preset="multignn_paper", dataset=d)
        rows.append([DS_SHORT.get(d, d), mstat(macro(rs, "metrics_covered"))[2], mstat(macro(rs))[2],
                     mstat([r["result"].get("train_seed_coverage") for r in rs])[2],
                     mstat([r["result"].get("test_seed_coverage") for r in rs])[2], len(rs)])
    O.table("E1_multignn", "E1 — Multi-GNN with its released hyper-parameters (fan-out 100)",
            ["Dataset", "Macro-F1 on sampled test targets (as the original code reports)",
             "Macro-F1 on 100% of test targets", "Train seed coverage (%)", "Test seed coverage (%)", "Seeds"], rows)


def e2(R, O, exp_datasets=None):
    G = select(R, kind="gnn", split="p1A", task="multi")
    lad = [r for r in G if str(r["spec"].get("model", "")).startswith("ladder") and not r["spec"].get("preset")
           and not r["spec"]["dataset"].startswith("motif")
           and not (r["spec"].get("overrides") or {}).get("sampler.backend")             # T1 runs: table t1
           and not (r["spec"].get("overrides") or {}).get("model.score_all")]            # X1 (ES) runs: rows 1b / 2b
    es = [r for r in G if str(r["spec"].get("model", "")).startswith("ladder")
          and (r["spec"].get("overrides") or {}).get("model.score_all")]
    dss = present_ds(lad)
    if not lad:
        return
    rows, by = [], {}
    for k in range(5):
        row = [RUNG_NAMES[k]]
        for d in dss:
            rs = [r for r in lad if r["spec"]["dataset"] == d and r["spec"]["model"] == f"ladder{k}"]
            by[(k, d)] = rs
            row.append(mstat(macro(rs))[2])
        rows.append(row)
    for k in range(1, 5):
        row = [f"Δ ({k}) vs ({k - 1}) [95% CI] p"]
        for d in dss:
            row.append(fmt_delta(by.get((k - 1, d), []), by.get((k, d), [])))
        rows.append(row)
    rows.append(["Δ (2) vs (0) [95% CI] p"] + [fmt_delta(by.get((0, d), []), by.get((2, d), [])) for d in dss])
    for k, tag in ((1, "1b"), (2, "2b")):     # X1: endpoint scoring instead of target forcing
        rs_es = {d: [r for r in es if r["spec"]["dataset"] == d and r["spec"]["model"] == f"ladder{k}"] for d in dss}
        if not any(rs_es.values()):
            continue
        sam = "asymmetric" if k == 1 else "coupled"
        rows.append([f"({tag}) {sam} sampler, endpoint scoring (no forcing)"] + [mstat(macro(rs_es[d]))[2] for d in dss])
        rows.append([f"Δ ({tag}) vs (0) [95% CI] p"] + [fmt_delta(by.get((0, d), []), rs_es[d]) for d in dss])
        rows.append([f"Δ ({k}) vs ({tag}) [95% CI] p"] + [fmt_delta(rs_es[d], by.get((k, d), [])) for d in dss])
        rows.append([f"({tag}) share of test targets whose own edge is in the graph (%)"] +
                    [mstat([r["result"].get("test_target_in_graph") for r in rs_es[d]])[2] for d in dss])
    rows.append(["(0) on sampled targets only"] + [mstat(macro(by.get((0, d), []), "metrics_covered"))[2] for d in dss])
    rows.append(["(0) test seed coverage (%)"] + [mstat([r["result"].get("test_seed_coverage") for r in by.get((0, d), [])])[2]
                                                  for d in dss])
    rows.append(["val macro-F1 of (4)"] + [mstat([((r["result"].get("val_metrics") or {}).get("macro_f1")
                                                    if r["result"].get("val_metrics") else r["result"].get("val_best_macro_f1"))
                                                   for r in by.get((4, d), [])])[2] for d in dss])
    reev = all(r["result"].get("reevaluated") or r["result"].get("eval_order") == "random"
               for k in range(5) for d in dss for r in by.get((k, d), []))
    O.table("E2_ladder", "E2 — Ablation ladder (macro-F1 %, full test set, mean ± std over seeds)" +
            ("" if reev else " — NOTE: some runs not re-evaluated (run `plan R1`)"),
            ["Rung"] + [DS_SHORT[d] for d in dss], rows,
            "Each rung changes one factor with respect to the previous one; same backbone and hyper-parameters. "
            "Δ = mean paired difference over seeds with its 95% t-interval; p_t = paired t-test, p_perm = two-sided "
            "sign-flip permutation test over paired seeds (its minimum attainable value is 2/2^n).")
    # per-class, ToN-like
    for d in dss:
        r2, r4 = by.get((2, d), []), by.get((4, d), [])
        if not r2 or not r4:
            continue
        classes = r4[0]["result"]["classes"]
        rows = []
        for c in classes:
            sup = r4[0]["result"]["metrics"]["per_class"][c]["support"]
            f = lambda rs: mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2]
            rows.append([c, f"{sup:,}", f(by.get((0, d), [])), f(r2), f(r4)])
        O.table(f"E2_perclass_{d}", f"E2 — Per-class F1 on {DS_SHORT[d]} (rungs 0, 2, 4)",
                ["Class", "Test support", "(0) Multi-GNN pipeline", "(2) coupled, per-layer mean", "(4) SymDiG"], rows)


def e3(R, O):
    S = sorted(select(R, kind="survival"), key=lambda r: r["result"].get("multiplicity") or 0)
    rows = [[r["result"]["multiplicity"], f"{r['result']['asym_strict']:.3f} / {r['result']['pred_asym_strict']:.3f}",
             f"{r['result']['asym_fwd']:.3f} / {r['result']['pred_asym_fwd']:.3f}",
             f"{r['result']['coupled']:.3f} / {r['result']['pred_coupled']:.3f}", r["result"]["n"]] for r in S]
    O.table("E3_survival", "E3 — Probability that a planted cycle survives sampling (empirical / predicted)",
            ["Multiplicity M", "Asymmetric, both relations", "Asymmetric, forward only", "Coupled", "Instances"], rows)
    G = [r for r in select(R, kind="gnn") if r["spec"]["dataset"].startswith("motif")]
    Ms = sorted({int(r["spec"]["dataset"].split("_m")[1]) for r in G})
    if not G:
        return
    rows = []
    for k in range(5):
        row = [RUNG_NAMES[k]]
        for M in Ms:
            rs = [r for r in G if r["spec"]["dataset"] == f"motif_m{M}" and r["spec"]["model"] == f"ladder{k}"]
            row.append(mstat(macro(rs))[2])
        rows.append(row)
    O.table("E3_ladder", "E3 — Macro-F1 (%) on structure-only motif labels vs multiplicity",
            ["Rung"] + [f"M={M}" for M in Ms], rows)
    classes = ["FanIn", "FanOut", "Cycle", "ScatterGather"]
    rows = []
    for M in Ms:
        for k in (2, 3, 4):
            rs = [r for r in G if r["spec"]["dataset"] == f"motif_m{M}" and r["spec"]["model"] == f"ladder{k}"]
            if rs:
                rows.append([M, RUNG_NAMES[k]] + [mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2]
                                                  for c in classes])
    O.table("E3_perclass", "E3 — Per-motif F1 (%): does late fusion lose mixed-direction motifs?",
            ["M", "Rung"] + classes, rows)


def model_rows(R, split, models, dss, ports=True):
    rows = []
    for m in models:
        row = [MODEL_NAMES.get(m, m)]
        any_ = False
        for d in dss:
            rs = select(R, split=split, model=m, dataset=d, task="multi")
            rs = [r for r in rs if r["spec"]["kind"] in ("gnn", "tabular", "fecograph") and
                  (r["spec"]["kind"] == "fecograph" or (r.get("cfg") or {}).get("data", {}).get("ports", True) == ports)]
            any_ |= bool(rs)
            row.append(mstat(macro(rs))[2])
        if any_:
            rows.append(row)
    return rows


def b0(R, O):
    rows = []
    B = [r for r in R if r["spec"]["kind"] == "tabular" and "B0" in r["spec"].get("exps", [r["spec"].get("exp")])
         and not r["spec"].get("tuned")]
    dss = present_ds(B)
    for m in ("xgboost", "mlp"):
        rows.append([MODEL_NAMES[m] + " (untuned)"] +
                    [mstat(macro([r for r in B if r["spec"]["model"] == m and r["spec"]["dataset"] == d]))[2] for d in dss])
    lad = [r for r in select(R, kind="gnn", split="p1A", model="ladder4") if not r["spec"].get("preset")]
    rows.append(["SymDiG, rung 4 (untuned, E2)"] + [mstat(macro([r for r in lad if r["spec"]["dataset"] == d]))[2] for d in dss])
    O.table("B0_quick", "B0 — Untuned per-flow baselines vs the E2 GNN (split p1A, macro-F1 %)",
            ["Model"] + [DS_SHORT[d] for d in dss], rows if dss else [])
    # per-class on ToN-like datasets
    for d in dss:
        xs = [r for r in B if r["spec"]["model"] == "xgboost" and r["spec"]["dataset"] == d]
        ms = [r for r in B if r["spec"]["model"] == "mlp" and r["spec"]["dataset"] == d]
        gs = [r for r in lad if r["spec"]["dataset"] == d]
        if not xs or not gs:
            continue
        rows = []
        for c in xs[0]["result"]["classes"]:
            f = lambda rs: mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2] if rs else "--"
            rows.append([c, f(xs), f(ms), f(gs)])
        O.table(f"B0_perclass_{d}", f"B0 — Per-class F1 on {DS_SHORT[d]}", ["Class", "XGBoost", "MLP", "SymDiG rung 4"], rows)


def e4(R, O, cfg_models):
    dss = present_ds(select(R, split="p1A"))
    O.table("E4_main", "E4 — All models in one frame (split p1A, tuned, macro-F1 %)",
            ["Model"] + [DS_SHORT[d] for d in dss], model_rows(R, "p1A", cfg_models, dss))
    O.table("E4_noports", "E4 — Without port features",
            ["Model"] + [DS_SHORT[d] for d in dss], model_rows(R, "p1A", ["xgboost", "symdig"], dss, ports=False))
    d2 = present_ds(select(R, split="p2"))
    O.table("E4_p2", "E4 — FeCoGraph protocol p2 (2% subsample, 30% labeled), same split for all",
            ["Model"] + [DS_SHORT[d] for d in d2],
            model_rows(R, "p2", ["xgboost", "rf", "egsage", "symdig", "fecograph"], d2))
    sel = lambda m, sp, d: select(R, split=sp, model=m, dataset=d, task="multi", ports=True)
    pairs = [("Multi-GNN + SymDiG sampler vs Multi-GNN (p1A, tuned)", "multignn", "multignn_fixed", "p1A"),
             ("SymDiG vs FeCoGraph (p2)", "fecograph", "symdig", "p2"),
             ("SymDiG vs E-GraphSAGE (p2)", "egsage", "symdig", "p2")]
    dd = [d for d in DS_ORDER if d in set(dss) | set(d2)]
    rows = [[lab] + [fmt_delta([r for r in sel(ma, sp, d) if r["spec"]["kind"] != "tune"],
                               [r for r in sel(mb, sp, d) if r["spec"]["kind"] != "tune"]) for d in dd]
            for lab, ma, mb, sp in pairs]
    O.table("E4_deltas", "E4 — Paired differences, macro-F1 points [95% CI]", ["Comparison"] + [DS_SHORT[d] for d in dd],
            rows, "Paired over seeds; p_t = paired t-test, p_perm = sign-flip permutation test.")
    for d in dss:
        a = select(R, kind="gnn", split="p1A", model="symdig", dataset=d, task="multi", ports=True)
        b = select(R, kind="tabular", split="p1A", model="xgboost", dataset=d, task="multi", ports=True)
        c0 = select(R, kind="gnn", split="p1A", model="multignn", dataset=d, task="multi", ports=True)
        if not a or not b:
            continue
        rows = []
        for c in a[0]["result"]["classes"]:
            f = lambda rs: mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2] if rs else "--"
            rows.append([c, f"{a[0]['result']['metrics']['per_class'][c]['support']:,}", f(b), f(c0), f(a)])
        O.table(f"E4_perclass_{d}", f"E4 — Per-class F1 on {DS_SHORT[d]}: where does the graph help?",
                ["Class", "Test support", "XGBoost", "Multi-GNN", "SymDiG"], rows)


def e5(R, O):
    vshift = variant_shift_classes(os.path.dirname(O.d))
    dss = present_ds(select(R, split="p1B"))
    rows = []
    for m in ("symdig", "multignn", "xgboost", "mlp"):
        for d in dss:
            a = select(R, split="p1A", model=m, dataset=d, task="multi", ports=True)
            b = select(R, split="p1B", model=m, dataset=d, task="multi", ports=True)
            b = [r for r in b if r["spec"]["kind"] in ("gnn", "tabular")]
            if not b:
                continue
            ma, mb = mstat(macro(a)), mstat(macro(b))
            excl = b[0]["result"].get("split_meta", {}).get("excluded_classes")
            drop = vshift.get(d, set())
            mh = mstat([macro_without(r, drop) for r in b]) if drop else mb
            names = b[0]["result"].get("classes") or []
            rows.append([MODEL_NAMES.get(m, m), DS_SHORT[d], ma[2], mb[2],
                         "--" if ma[0] is None or mb[0] is None else f"{mb[0] - ma[0]:+.2f}", mh[2],
                         ", ".join(names[i] if isinstance(i, int) and i < len(names) else str(i) for i in excl)
                         if excl else "-"])
    O.table("E5_host", "E5 — Random split (p1A) vs attacker-disjoint split (p1B), macro-F1 %",
            ["Model", "Dataset", "p1A", "p1B", "Δ", "p1B, host shift only", "Classes not evaluated in p1B"], rows,
            "p1B macro-F1 is computed over the classes that could be split by attacker source IP. "
            "'Host shift only' leaves out the classes whose test flows are mostly a sub-attack never seen in training "
            + ("(" + "; ".join(f"{DS_SHORT.get(d, d)}: {', '.join(sorted(v))}" for d, v in vshift.items() if v) + ")"
               if any(vshift.values()) else "(run scripts/host_variant_report.py; only IDS2018 has sub-attack labels)")
            + "; on the other datasets it equals p1B.")
    T = select(R, kind="transfer")
    if T:
        rows = []
        for m in sorted({r["spec"]["model"] for r in T}):
            for src in DS_ORDER:
                row = [MODEL_NAMES.get(m, m), DS_SHORT[src]]
                ok = False
                for tgt in DS_ORDER:
                    rs = [r for r in T if r["spec"]["model"] == m and r["spec"]["source"] == src and r["spec"]["dataset"] == tgt]
                    ok |= bool(rs)
                    row.append("—" if src == tgt else mstat(macro(rs))[2])
                if ok:
                    rows.append(row)
        O.table("E5_transfer", "E5 — Cross-dataset binary transfer (train on row, test on column), macro-F1 %",
                ["Model", "Train on"] + [DS_SHORT[d] for d in DS_ORDER], rows)


def e6(R, O):
    rows = []
    for r in select(R, kind="sizes"):
        def _num(k):
            try:
                return float(k)
            except ValueError:
                return None
        items = [(f, x) for f, x in r["result"].items() if _num(f) is not None and isinstance(x, dict)]  # skip peak_ram_gb etc.
        for f, x in sorted(items, key=lambda kv: float(kv[0])):
            rows.append([DS_SHORT.get(r["spec"]["dataset"], r["spec"]["dataset"]), f"{float(f) * 100:g}%", f"{x['flows']:,}",
                         f"{x['ip_nodes']:,}", f"{x['ipport_nodes']:,}", f"{x['line_graph_edges_ipport']:.3g}"])
    O.table("E6_sizes", "E6 — Graph sizes on the same flows",
            ["Dataset", "Share of flows", "Flows (= edges)", "Nodes, IP-centric", "Nodes, IP:PORT",
             "Line-graph edges (IP:PORT hosts)"], rows)
    rows, hw = [], set()
    for r in sorted(select(R, kind="deploy"), key=lambda r: (r["spec"]["dataset"], r["spec"]["model"],
                                                             r["spec"].get("frac", 1), str(r["spec"].get("mem_cap_gb")))):
        x = r["result"]
        if x.get("status") != "ok":
            rows.append([DS_SHORT.get(r["spec"]["dataset"]), MODEL_NAMES.get(r["spec"]["model"]), x.get("frac"),
                         x.get("mem_cap_gb") or "40", x.get("status"), "", "", "", ""])
            continue
        tr = x["train"]
        inf = x.get(f"infer_bs{8192}") or next((v for k, v in x.items() if k.startswith("infer_bs")), {})
        hw.add(x.get("gpu_name") or f"GPU not recorded (host {r.get('host', '?')})")
        rows.append([DS_SHORT.get(r["spec"]["dataset"]), MODEL_NAMES.get(r["spec"]["model"]), x.get("frac"),
                     x.get("mem_cap_gb") or "40", "ok", f"{tr.get('peak_vram_gb') or 0:.2f}",
                     f"{tr.get('targets_per_sec') or 0:,.0f}", f"{inf.get('flows_per_sec_end_to_end', 0):,.0f}",
                     f"{inf.get('gpu_ms_p95', 0):.1f}"])
    O.table("E6_deploy", "E6 — Training and inference cost on one GPU: " + "; ".join(sorted(hw)),
            ["Dataset", "Model", "Share of flows", "Memory cap (GB)", "Status", "Train peak VRAM (GB)",
             "Train targets/s", "Inference flows/s (end-to-end)", "Inference p95 GPU ms/batch"], rows)


def sc(R, O):
    """SC: full-graph E-GraphSAGE vs E-GraphSAGE + C3S on the same data fractions (symdig/scale.py)."""
    S = [r for r in select(R, kind="scale") if r.get("result")]
    if not S:
        return
    by = {}
    for r in S:
        x = r["result"]
        by.setdefault((r["spec"]["dataset"], float(r["spec"]["frac"]), r["spec"]["mode"]), []).append(x)
    gpus = sorted({x.get("gpu_name") or "?" for r in S for x in [r["result"]]})
    total = max([x.get("gpu_total_gb") or 0 for r in S for x in [r["result"]]] or [0])
    rows = []
    gb = lambda v: f"{v:.1f}" if v is not None else "--"
    mins = lambda v: f"{v / 60:.1f}" if v is not None else "--"
    f1 = lambda xs: mstat([((x.get("metrics") or {}).get("macro_f1")) for x in xs])[2] if xs else "--"
    for d in DS_ORDER:
        for frac in sorted({k[1] for k in by if k[0] == d}):
            fg, cs = by.get((d, frac, "fullgraph"), []), by.get((d, frac, "c3s"), [])
            x, y = (fg[0] if fg else {}), (cs[0] if cs else {})
            if x.get("status") == "OOM":
                st = f"OOM ({x.get('oom_stage', '?')}) at {gb(x.get('peak_vram_gb'))} GB"
            else:
                st = x.get("status", "--")
            pk = x.get("peak_vram_gb")
            fits = ("--" if pk is None or x.get("status") != "ok" else
                    "/".join("yes" if pk <= c else "no" for c in (16, 40)))
            rows.append([DS_SHORT.get(d, d), f"{100 * frac:g}%", f"{x.get('n_graph_train') or y.get('n_graph_train') or 0:,}",
                         st, gb(pk), fits, mins(x.get("train_sec")), f1([z for z in fg if z.get("status") == "ok"]),
                         y.get("status", "--"), gb(y.get("peak_vram_gb")), mins(y.get("train_sec")),
                         f1([z for z in cs if z.get("status") == "ok"])])
    O.table("SC_scale", f"SC — Coverage–scale trade-off: full-graph vs C3S training of E-GraphSAGE "
            f"({'; '.join(gpus)}, {total:.0f} GB)",
            ["Dataset", "Share of flows", "Train-graph edges", "Full-graph status", "Full-graph peak VRAM (GB)",
             "Fits 16/40 GB", "Full-graph train (min)", "Full-graph macro-F1", "C3S status",
             "C3S peak VRAM (GB)", "C3S train (min)", "C3S macro-F1"], rows,
            "Same backbone (E-GraphSAGE on IP:PORT nodes) and untuned hyper-parameters; macro-F1 on the full test "
            "set of the same fraction. Full-graph runs are uncapped with the GPU to themselves, so their peak "
            "memory says whether they would fit a 16 GB / 40 GB card; C3S runs are capped at 16 GB.")


def e7(R, O):
    E = [r for r in select(R, kind="evasion") if r["spec"].get("context", "full") == "full"]   # IC runs: table IC
    if not E:
        return
    rows = []
    for m in sorted({r["spec"]["model"] for r in E}):
        rs = [r for r in E if r["spec"]["model"] == m]
        strats = rs[0]["result"]["results"].keys()
        for s in strats:
            ks = sorted(rs[0]["result"]["results"][s].keys(), key=int)
            rows.append([MODEL_NAMES.get(m, m), s] + [mstat([r["result"]["results"][s][k]["mean_f1"] for r in rs])[2] for k in ks])
    ks = sorted(E[0]["result"]["results"][next(iter(E[0]["result"]["results"]))].keys(), key=int)
    O.table("E7_evasion", f"E7 — Mean F1 (%) of the attacked classes {E[0]['result']['attacked']} under injection",
            ["Model", "Strategy"] + [f"K={k}" for k in ks], rows,
            "XGBoost and the MLP score each flow independently, so injected chaff cannot change their predictions "
            "on the attack flows; compare with their clean per-class F1 in E4.")


def _ctx_run(r, ctx):
    """A ctxeval record seen as an ordinary run scored with one context (for mstat / fmt_delta / macro_without)."""
    x = (r["result"].get("contexts") or {}).get(ctx)
    return {"spec": {"seed": r["spec"].get("seed")}, "result": {"metrics": (x or {}).get("metrics")}} if x else None


def _cell(rs, drop):
    """mean ± std; for datasets with variant-shift classes also the value without them, in parentheses."""
    v = mstat(macro(rs))[2]
    if drop and rs:
        v += f" ({mstat([macro_without(r, drop) for r in rs])[2]})"
    return v


CTX_NAMES = {"full": "test-graph context (as in E4/E5)", "train": "training-graph context (IC)", "none": "no sampled context"}


def ic(R, O):
    """IC: the same checkpoints scored with the test graph, the training graph, or no context."""
    C = [r for r in select(R, kind="ctxeval") if r.get("result") and r["result"].get("split_seed", 42) == 42]
    vshift = variant_shift_classes(os.path.dirname(O.d))
    for split in ("p1B", "p1A"):
        Cs = [r for r in C if r["result"]["split"] == split]
        if not Cs:
            continue
        dss = present_ds(Cs)
        rows = []
        for m in sorted({r["result"]["src_model"] for r in Cs}):
            for ctx in ("full", "train", "none"):
                cells, any_ = [], False
                for d in dss:
                    rs = [x for x in (_ctx_run(r, ctx) for r in Cs if r["result"]["src_model"] == m and r["spec"]["dataset"] == d) if x]
                    any_ |= bool(rs)
                    cells.append(_cell(rs, vshift.get(d) if split == "p1B" else None))
                if any_:
                    rows.append([MODEL_NAMES.get(m, m), CTX_NAMES[ctx]] + cells)
            for ctx in ("train", "none"):
                row = [MODEL_NAMES.get(m, m), f"Δ {ctx} vs test-graph context [95% CI] p"]
                for d in dss:
                    rr = [r for r in Cs if r["result"]["src_model"] == m and r["spec"]["dataset"] == d]
                    a = [x for x in (_ctx_run(r, "full") for r in rr) if x]
                    b = [x for x in (_ctx_run(r, ctx) for r in rr) if x]
                    row.append(fmt_delta(a, b))
                rows.append(row)
        for m in ("xgboost", "mlp"):
            cells, any_ = [], False
            for d in dss:
                rs = [r for r in select(R, kind="tabular", split=split, model=m, dataset=d, task="multi", ports=True)
                      if not r["spec"].get("features") or r["spec"].get("features") == "plain"]
                any_ |= bool(rs)
                cells.append(_cell(rs, vshift.get(d) if split == "p1B" else None))
            if any_:
                rows.append([MODEL_NAMES.get(m, m), "per-flow (reference)"] + cells)
        name = "attacker-disjoint split p1B" if split == "p1B" else "random split p1A"
        O.table(f"IC_{split}", f"IC — Inductive context: the same trained GNN scored with different graph contexts, {name} (macro-F1 %)",
                ["Model", "Context"] + [DS_SHORT[d] for d in dss], rows,
                "Same checkpoints (tuned, as in E4/E5) for every context; Δ is paired over model seeds. "
                "Training-graph context: neighbours are drawn from the training graph only, so the test-period flows "
                "(including those of new attackers) never enter the context; every test flow is still scored. "
                + ("In parentheses: without the variant-shift classes. " if split == "p1B" and any(vshift.values()) else ""))
        # per class, attacker-disjoint split
        if split == "p1B":
            for d in dss:
                rr = [r for r in Cs if r["spec"]["dataset"] == d]
                if not rr:
                    continue
                classes = rr[0]["result"]["classes"]
                rows = []
                for c in classes:
                    row, ok = [c], False
                    for m in sorted({r["result"]["src_model"] for r in rr}):
                        for ctx in ("full", "train"):
                            v = [((r["result"]["contexts"].get(ctx) or {}).get("metrics") or {}).get("per_class", {}).get(c, {})
                                 for r in rr if r["result"]["src_model"] == m]
                            v = [x["f1"] for x in v if x and x.get("support", 0) > 0]
                            ok |= bool(v)
                            row.append(mstat(v)[2])
                    if ok:
                        rows.append(row)
                hdr = [f"{MODEL_NAMES.get(m, m)}: {ctx}" for m in sorted({r["result"]["src_model"] for r in rr}) for ctx in ("test graph", "training graph")]
                O.table(f"IC_perclass_{d}", f"IC — Per-class F1 on {DS_SHORT.get(d, d)}, split p1B (%)", ["Class"] + hdr, rows)
    E = [r for r in select(R, kind="evasion") if r["spec"].get("context") == "train" and r.get("result")]
    if E:
        rows = []
        for m in sorted({r["spec"]["model"] for r in E}):
            rs = [r for r in E if r["spec"]["model"] == m]
            for st in rs[0]["result"]["results"]:
                ks = sorted(rs[0]["result"]["results"][st].keys(), key=int)
                rows.append([MODEL_NAMES.get(m, m), st] + [mstat([r["result"]["results"][st][k]["mean_f1"] for r in rs])[2] for k in ks])
        ks = sorted(E[0]["result"]["results"][next(iter(E[0]["result"]["results"]))].keys(), key=int)
        O.table("IC_evasion", "IC — Traffic injection (E7) with the training-graph context: mean F1 (%) of the attacked classes",
                ["Model", "Strategy"] + [f"K={k}" for k in ks], rows,
                "Same checkpoints and injected flows as E7; the chaff is part of the live traffic but not of the training graph.")


def split_seed_of(r):
    ov = r["spec"].get("overrides") or {}
    if "data.split_seed" in ov:
        return int(ov["data.split_seed"])
    return int((r.get("result") or {}).get("split_seed", 42) or 42)


def hs(R, O):
    """HS: P-host estimates over several split seeds (split seed 42 = the main runs)."""
    vshift = variant_shift_classes(os.path.dirname(O.d))
    seeds = sorted({split_seed_of(r) for r in R if r["spec"].get("split") == "p1B" or (r.get("result") or {}).get("split") == "p1B"})
    if len(seeds) < 2:
        return
    dss = present_ds([r for r in R if r["spec"].get("split") == "p1B"])
    rows = []
    entries = [("symdig", "full"), ("symdig", "train"), ("multignn_fixed", "full"), ("multignn_fixed", "train"),
               ("xgboost", None), ("mlp", None)]
    for m, ctx in entries:
        row, any_ = [MODEL_NAMES.get(m, m), CTX_NAMES[ctx] if ctx else "per-flow"], False
        for d in dss:
            per = []
            for k in seeds:
                if ctx:
                    rs = [x for x in (_ctx_run(r, ctx) for r in select(R, kind="ctxeval", dataset=d)
                                      if r.get("result") and r["result"].get("src_model") == m
                                      and r["result"].get("split") == "p1B" and split_seed_of(r) == k) if x]
                else:
                    rs = [r for r in select(R, kind="tabular", split="p1B", model=m, dataset=d, task="multi", ports=True)
                          if split_seed_of(r) == k and (r["spec"].get("features") or "plain") == "plain"]
                drop = vshift.get(d)
                vals = [macro_without(r, drop) for r in rs] if drop else macro(rs)
                per.append(mstat(vals)[0])
            ok = [v for v in per if v is not None]
            any_ |= bool(ok)
            row.append(" / ".join("--" if v is None else f"{v:.1f}" for v in per)
                       + (f" → {np.mean(ok):.1f} ± {np.std(ok, ddof=1):.1f}" if len(ok) > 1 else ""))
        if any_:
            rows.append(row)
    O.table("HS_splits", "HS — Attacker-disjoint split with different split seeds (p1B, macro-F1 %; "
            + " / ".join(f"split {k}" for k in seeds) + " → mean ± std over splits)",
            ["Model", "Context"] + [DS_SHORT[d] for d in dss], rows,
            "Each entry is the mean over model seeds on one split; hyper-parameters are those tuned on the first split (42). "
            + ("Datasets with variant-shift classes are scored without them. " if any(vshift.values()) else ""))


def e8(R, O):
    H = select(R, kind="hybrid")
    if not H:
        return
    names = ["xgb_full", "xgb", "xgb+stats", "xgb+prob", "xgb+hid", "xgb+prob+hid", "xgb+stats+prob+hid"]
    label = {"xgb_full": "XGBoost, full train (reference)", "xgb": "XGBoost, half B (control)",
             "xgb+stats": "+ graph statistics", "xgb+prob": "+ GNN probabilities", "xgb+hid": "+ GNN hidden layer",
             "xgb+prob+hid": "+ GNN prob. + hidden", "xgb+stats+prob+hid": "+ statistics + GNN prob. + hidden"}
    for split in ("p1A", "p1B"):
        Hs = [r for r in H if r["spec"]["split"] == split]
        dss = present_ds(Hs)
        if not dss:
            continue
        rows = []
        for n in names:
            rows.append([label[n]] + [mstat([r["result"]["variants"][n]["metrics"]["macro_f1"]
                                             for r in Hs if r["spec"]["dataset"] == d])[2] for d in dss])
        rows.append(["GNN alone (half A)"] + [mstat([r["result"]["gnn_half_a"]["metrics"]["macro_f1"]
                                                     for r in Hs if r["spec"]["dataset"] == d])[2] for d in dss])
        rows.append(["Δ (+ GNN prob. + hidden) vs control [p]"] +
                    [_pair(Hs, d, "xgb", "xgb+prob+hid") for d in dss])
        rows.append(["Δ (+ graph statistics) vs control [p]"] + [_pair(Hs, d, "xgb", "xgb+stats") for d in dss])
        O.table(f"E8_{split}", f"E8 — Graph context as XGBoost features, split {split} (macro-F1 %)",
                ["Variant"] + [DS_SHORT[d] for d in dss], rows,
                "All variants except the reference are trained on the same half B of the training targets; "
                "GNN features come from a GNN trained on the disjoint half A (out-of-sample).")
        for d in dss:
            rs = [r for r in Hs if r["spec"]["dataset"] == d]
            classes = rs[0]["result"]["classes"]
            f = lambda n, c: mstat([r["result"]["variants"][n]["metrics"]["per_class"][c]["f1"] for r in rs])[2]
            rows = [[c, f("xgb", c), f("xgb+stats", c), f("xgb+prob+hid", c), f("xgb+stats+prob+hid", c)] for c in classes]
            O.table(f"E8_perclass_{d}_{split}", f"E8 — Per-class F1 on {DS_SHORT[d]}, split {split}",
                    ["Class", "XGBoost (B)", "+ statistics", "+ GNN prob. + hidden", "+ all"], rows)


def t1(R, O):
    T = [r for r in select(R, exp="T1", kind="gnn") if r.get("result")]
    if not T:
        return
    be = lambda r: ((r["spec"].get("overrides") or {}).get("sampler.backend"))
    base = [r for r in select(R, exp="E2", kind="gnn", model="ladder1") if r.get("result")]
    dss = present_ds(T)
    groups = [("(1) native sampler (E2, re-evaluated)", base), ("(1) TargetEdgeLoader as written", [r for r in T if be(r) == "tel_orig"]),
              ("(1) TargetEdgeLoader + CSC-permutation fix", [r for r in T if be(r) == "tel_fixed"])]
    rows = [[n] + [mstat(macro([r for r in g if r["spec"]["dataset"] == d]))[2] for d in dss] for n, g in groups]
    for n, g in groups[1:]:
        cells = []
        for d in dss:
            m, p, k = paired_test([r for r in base if r["spec"]["dataset"] == d], [r for r in g if r["spec"]["dataset"] == d])
            cells.append("--" if m is None else f"{m:+.2f} [{p:.2f}, n={k}]")
        rows.append([f"Δ {n[4:]} vs native [p]"] + cells)
    O.table("T1", "T1 — The TargetEdgeLoader as the sampler of rung 1 (macro-F1 %, full test set)",
            ["Sampler"] + [DS_SHORT[d] for d in dss], rows,
            "Same features, split, batch size, model (hetero, to_hetero-style mean), loss and evaluation as E2; "
            "only the subgraph sampler differs. All targets are present in every batch for all three samplers.")
    C = [r for r in select(R, exp="T1", kind="coverage") if r.get("result")]
    rows = []
    for r in sorted(C, key=lambda r: (DS_ORDER.index(r["spec"]["dataset"]) if r["spec"]["dataset"] in DS_ORDER else 99, be(r))):
        x = r["result"][be(r)]
        rows.append([DS_SHORT.get(r["spec"]["dataset"], r["spec"]["dataset"]), be(r), f"{100 * x['seed_coverage']:.1f}",
                     f"{100 * x['twin_coverage']:.1f}", f"{100 * x.get('tel_consistency', float('nan')):.1f}",
                     f"{x['edges_per_batch']:,.0f}"])
    O.table("T1_sampler", "T1 — Sampler diagnostics (training graph, p1A)",
            ["Dataset", "Backend", "Target coverage %", "Twin coverage %", "Edge consistency %", "Edges / batch"], rows,
            "Edge consistency = share of sampled edges whose two endpoints are both sampled nodes "
            "(100 % for a correct neighbour sampler).")


def macro_without(r, drop):
    """Macro-F1 over the classes present in the test set, leaving out the classes in `drop`."""
    pc = (r["result"].get("metrics") or {}).get("per_class") or {}
    v = [x["f1"] for c, x in pc.items() if x.get("support", 0) > 0 and c not in drop]
    return float(np.mean(v)) if v else None


def variant_shift_classes(results, min_unseen=0.5):
    """dataset -> classes whose test flows are mostly an unseen sub-attack (scripts/host_variant_report.py)."""
    import glob as _glob
    import json as _json
    out = {}
    for f in _glob.glob(os.path.join(results, "variants", "*.json")):
        z = _json.load(open(f))
        out[os.path.basename(f)[:-5]] = {c for c, v in z["classes"].items()
                                          if v.get("unseen_frac") is not None and v["unseen_frac"] >= min_unseen}
    return out


def h(R, O):
    """Host-invariant NIDS (experiments H / HP)."""
    H = [r for r in R if r["spec"].get("exp") == "H" and r.get("result")]
    if not H:
        return
    def runs(kind, split="p1H", **kw):
        out = []
        for r in H:
            sp = r["spec"]
            if sp["kind"] != kind or sp.get("split") != split:
                continue
            if all(sp.get(k) == v for k, v in kw.items()):
                out.append(r)
        return out
    rows_def = [("XGBoost", ("tabular", {"model": "xgboost", "features": "plain"})),
                ("XGBoost + host norm.", ("tabular", {"model": "xgboost", "features": "hostnorm"})),
                ("MLP", ("tabular", {"model": "mlp", "features": "plain"})),
                ("MLP + host norm.", ("tabular", {"model": "mlp", "features": "hostnorm"})),
                ("GNN, sampler fix (no HINT)", ("hint", {"model": "gnn_plain"})),
                ("Flow net (no HINT)", ("hint", {"model": "flow_plain"})),
                ("HINT-flow (MLP)", ("hint", {"model": "hint_flow"})),
                ("HINT-flow (FT-Transformer)", ("hint", {"model": "hint_flow_ftt"})),
                ("HINT-flow, host-relative only, no DRO", ("hint", {"model": "hint_flow_rel"})),
                ("HINT-GNN", ("hint", {"model": "hint_gnn"})),
                ("HINT-GNN − GroupDRO", ("hint", {"model": "hint_gnn_nodro"})),
                ("HINT-GNN, host-relative only, no DRO", ("hint", {"model": "hint_gnn_rel"}))]
    dss = present_ds(runs("hint") + runs("tabular"))
    f1 = lambda rs: mstat([r["result"]["metrics"]["macro_f1"] for r in rs])
    by = {name: {d: runs(k, **dict(kw, dataset=d)) for d in dss} for name, (k, kw) in rows_def}
    rows = [[name] + [f1(by[name][d])[2] for d in dss] for name, _ in rows_def if any(by[name][d] for d in dss)]
    def delta(a_name, b_name, d):
        m, p, n = paired_test(by[a_name][d], by[b_name][d])
        return "--" if m is None else f"{m:+.2f} [{p:.2f}]"
    base_names = ["XGBoost", "XGBoost + host norm.", "MLP", "MLP + host norm.", "GNN, sampler fix (no HINT)"]
    best_cells = []
    for d in dss:
        cand = [(f1(by[b][d])[0], b) for b in base_names if by[b][d]]
        if cand and by["HINT-GNN"][d]:
            best = max(cand)[1]
            best_cells.append(f"{delta(best, 'HINT-GNN', d)} vs {best}")
        else:
            best_cells.append("--")
    rows.append(["Δ HINT-GNN vs best baseline [p]"] + best_cells)
    hint_names = [n for n in ("HINT-flow (MLP)", "HINT-flow (FT-Transformer)", "HINT-flow, host-relative only, no DRO",
                              "HINT-GNN", "HINT-GNN − GroupDRO", "HINT-GNN, host-relative only, no DRO")
                  if any(by[n][d] for d in dss)]
    cells = []
    for d in dss:
        cand = [(f1(by[b][d])[0], b) for b in base_names if by[b][d]]
        hc = [(f1(by[n][d])[0], n) for n in hint_names if by[n][d]]
        cells.append("--" if not (cand and hc) else f"{delta(max(cand)[1], max(hc)[1], d)} ({max(hc)[1]} vs {max(cand)[1]})")
    rows.append(["Δ best HINT variant vs best baseline [p]"] + cells)
    rows.append(["Δ HINT-GNN vs XGBoost + host norm. [p] (H3)"] + [delta("XGBoost + host norm.", "HINT-GNN", d) for d in dss])
    O.table("H_main", "H — Generalisation to unseen attackers (split p1H, macro-F1 %)", ["Model"] + [DS_SHORT[d] for d in dss],
            rows, "p1H = the p1B test set (attacker source IPs disjoint from training) with an attacker-disjoint "
                  "validation set used for tuning and model selection.")

    # same, without the classes whose test flows are mostly a sub-attack never seen in training
    # (written by scripts/host_variant_report.py): host shift only, no variant shift
    vshift = variant_shift_classes(os.path.dirname(O.d))
    if any(vshift.get(d) for d in dss):
        def mf1_sub(r, drop):
            pc = r["result"]["metrics"]["per_class"]
            v = [x["f1"] for c, x in pc.items() if x.get("support", 0) > 0 and c not in drop]
            return float(np.mean(v)) if v else None
        f1s = lambda rs, d: mstat([mf1_sub(r, vshift.get(d, set())) for r in rs])
        rows = [[name] + [f1s(by[name][d], d)[2] for d in dss] for name, _ in rows_def if any(by[name][d] for d in dss)]
        cells = []
        for d in dss:
            cand = [(f1s(by[b][d], d)[0], b) for b in base_names if by[b][d]]
            hc = [(f1s(by[n][d], d)[0], n) for n in hint_names if by[n][d]]
            if not (cand and hc):
                cells.append("--")
                continue
            bb, hh = max(cand)[1], max(hc)[1]
            cells.append(f"{max(hc)[0] - max(cand)[0]:+.2f} ({hh} vs {bb})")
        rows.append(["Δ best HINT variant vs best baseline"] + cells)
        O.table("H_main_hostshift", "H — Host shift only: macro-F1 % without variant-shift classes (split p1H)",
                ["Model"] + [DS_SHORT[d] for d in dss], rows,
                "Left out: " + "; ".join(f"{DS_SHORT[d]}: {', '.join(sorted(vshift[d]))}" for d in dss if vshift.get(d))
                + " (test flows are mostly a sub-attack that never occurs in training).")

    abl = [("HINT-GNN (full)", "hint_gnn"), ("− host normalisation", "hint_gnn_nohn"), ("− host adversary", "hint_gnn_noadv"),
           ("− GroupDRO", "hint_gnn_nodro"), ("host-relative only, − GroupDRO", "hint_gnn_rel"), ("− graph (HINT-flow)", "hint_flow"), ("all off (GNN, sampler fix)", "gnn_plain")]
    A = {lab: {d: runs("hint", model=v, dataset=d) for d in dss} for lab, v in abl}
    rows = [[lab] + [f1(A[lab][d])[2] for d in dss] for lab, _ in abl if any(A[lab][d] for d in dss)]
    for lab, _ in abl[1:]:
        cells = []
        for d in dss:
            m, p, n = paired_test(A["HINT-GNN (full)"][d], A[lab][d])
            cells.append("--" if m is None else f"{m:+.2f} [{p:.2f}]")
        rows.append([f"Δ {lab} [p]"] + cells)
    O.table("H_ablation", "H — Ablation of HINT-GNN (split p1H, macro-F1 %)", ["Variant"] + [DS_SHORT[d] for d in dss], rows)

    pc_cols = [n for n in ("XGBoost", "MLP + host norm.", "GNN, sampler fix (no HINT)", "HINT-flow (MLP)",
                           "HINT-GNN", "HINT-GNN − GroupDRO")
               if any(by[n][d] for d in dss)]
    for d in dss:
        any_r = next((by[n][d][0] for n in pc_cols if by[n][d]), None)
        if any_r is None:
            continue
        tr_counts = (any_r["result"].get("split_meta") or {}).get("train_class_counts")
        rows = []
        for i, c in enumerate(any_r["result"]["metrics"]["per_class"]):
            cell = lambda rs: mstat([r["result"]["metrics"]["per_class"][c]["f1"] for r in rs])[2] if rs else "--"
            rows.append([c, f"{tr_counts[i]:,}" if tr_counts else "--"] + [cell(by[n][d]) for n in pc_cols])
        O.table(f"H_perclass_{d}", f"H — Per-class F1 on {DS_SHORT[d]}, split p1H (%)",
                ["Class", "Train flows"] + pc_cols, rows)

    def probe(rs, key):
        return mstat([((r["result"].get(key) or {}).get("acc")) for r in rs])[2]
    prow = [("Input: global features", "gnn_plain", "probe_input"), ("Input: global + host-normalised", "hint_gnn", "probe_input"),
            ("Representation: GNN (no HINT)", "gnn_plain", "probe_hid"), ("Representation: HINT-GNN", "hint_gnn", "probe_hid"),
            ("Representation: flow net (no HINT)", "flow_plain", "probe_hid"), ("Representation: HINT-flow", "hint_flow", "probe_hid")]
    rows = [[lab] + [probe(runs("hint", model=v, dataset=d), key) for d in dss] for lab, v, key in prow]
    rows.append(["Majority host (chance level)"] + [mstat([((r["result"].get("probe_hid") or {}).get("majority"))
                                                           for r in runs("hint", model="gnn_plain", dataset=d)])[2] for d in dss])
    O.table("H_probe", "H — How well can the source host be read off? (linear probe accuracy %, held-out flows)",
            ["Probe on"] + [DS_SHORT[d] for d in dss], rows,
            "Lower is better for invariance. Hosts = the K source hosts with most training flows.")

    hr = [("XGBoost", "tabular", {"model": "xgboost", "features": "plain"}), ("XGBoost + host norm.", "tabular", {"model": "xgboost", "features": "hostnorm"}),
          ("GNN, sampler fix (no HINT)", "hint", {"model": "gnn_plain"}), ("HINT-flow (MLP)", "hint", {"model": "hint_flow"}),
          ("HINT-GNN", "hint", {"model": "hint_gnn"})]
    q = lambda rs, k: mstat([((r["result"].get("host_recall") or {}).get(k)) for r in rs])[2]
    by_cls = any("class_mean_median" in (r["result"].get("host_recall") or {}) for r in H)
    k1, k2 = ("class_mean_median", "class_min_median") if by_cls else ("p10", "median")
    rows = [[lab] + [f"{q(runs(k, **dict(kw, dataset=d)), k1)} / {q(runs(k, **dict(kw, dataset=d)), k2)}" for d in dss]
            for lab, k, kw in hr]
    O.table("H_hosts", "H — Recall on the attack flows of individual unseen attackers (" +
            ("mean over classes of the median host / worst class" if by_cls else "p10 / median over hosts") + ", %)",
            ["Model"] + [DS_SHORT[d] for d in dss], rows, "Attacking source hosts with at least 50 test attack flows"
            + (" of the class." if by_cls else "; a class with many hosts (IDS2018 Infiltration) dominates these quantiles."))

    rows = []
    for lab, v in (("GNN, sampler fix (no HINT)", "gnn_plain"), ("HINT-GNN", "hint_gnn")):
        rows.append([lab] + [f1(runs("hint", split="p1A", model=v, dataset=d))[2] for d in dss])
    cells = []
    for d in dss:
        m, p, n = paired_test(runs("hint", split="p1A", model="gnn_plain", dataset=d), runs("hint", split="p1A", model="hint_gnn", dataset=d))
        cells.append("--" if m is None else f"{m:+.2f} [{p:.2f}]")
    rows.append(["Δ HINT-GNN vs GNN [p]"] + cells)
    O.table("H_p1A", "H — Cost on the random split (p1A, macro-F1 %)", ["Model"] + [DS_SHORT[d] for d in dss], rows)

    L = runs("hint", model="hint_gnn_lambda")
    if L:
        rows = []
        for lam in sorted({r["spec"]["sweep_lambda"] for r in L}):
            rs = [r for r in L if r["spec"]["sweep_lambda"] == lam]
            rows.append([f"{lam:g}", f1(rs)[2], probe(rs, "probe_hid")])
        O.table("H_lambda", f"H — Adversary strength on {DS_SHORT.get(L[0]['spec']['dataset'], '')} (split p1H)",
                ["λ", "macro-F1 %", "host probe acc. %"], rows)


def d1(R, O):
    """Diagnostic D1 (symdig/diag.py): the same trained model on held-out flows of seen attacker
    hosts and on the unseen hosts of p1B; the GNN also with less graph context."""
    D = [r for r in R if r["spec"].get("kind") == "diag_host" and r.get("result")]
    if not D:
        return
    dss = present_ds(D)
    vshift = variant_shift_classes(os.path.dirname(O.d))
    models = [("xgboost", "XGBoost"), ("flow_plain", "Flow net"), ("gnn_plain", "GNN, sampler fix")]
    sets = {"xgboost": [("seen", "seen hosts"), ("unseen", "unseen hosts")],
            "flow_plain": [("seen", "seen hosts"), ("unseen", "unseen hosts")],
            "gnn_plain": [("seen", "seen hosts"), ("unseen", "unseen hosts"),
                          ("unseen_ctx_train", "unseen, training-graph context"),
                          ("unseen_ctx_none", "unseen, no sampled context")]}

    def get(r, key, setn):
        return ((r["result"]["models"].get(key) or {}).get(setn) or {}).get("metrics")

    rows = []
    for key, lab in models:
        for setn, slab in sets[key]:
            row = [lab, slab]
            for d in dss:
                ms = [get(r, key, setn) for r in D if r["spec"]["dataset"] == d]
                drop = vshift.get(d, set())
                full = mstat([m["macro_f1"] if m else None for m in ms])[2]
                if drop:
                    sub = mstat([macro_without({"result": {"metrics": m}}, drop) if m else None for m in ms])[2]
                    full = f"{full} (host shift only: {sub})"
                row.append(full)
            rows.append(row)
    O.table("D1_summary", "D1 — Same trained model on seen vs unseen attacker hosts (split p1B, macro-F1 %)",
            ["Model", "Test flows"] + [DS_SHORT[d] for d in dss], rows,
            "Seen hosts = 5 % of the training targets (at most 300k) held out of the loss before training. "
            "Untuned defaults, like the HP pilot. 'Host shift only' leaves out the variant-shift classes.")
    for d in dss:
        rs = [r for r in D if r["spec"]["dataset"] == d]
        classes = rs[0]["result"]["classes"]
        cols = [(key, setn, f"{lab}: {slab}") for key, lab in models for setn, slab in sets[key]
                if setn in ("seen", "unseen") or (key == "gnn_plain" and setn == "unseen_ctx_none")]
        rows = []
        for c in classes:
            row = [c + (" *" if c in vshift.get(d, set()) else "")]
            for key, setn, _ in cols:
                vals = []
                for r in rs:
                    m = get(r, key, setn)
                    x = (m or {}).get("per_class", {}).get(c)
                    vals.append(x["f1"] if x and x.get("support", 0) > 0 else None)
                row.append(mstat(vals)[2])
            rows.append(row)
        O.table(f"D1_perclass_{d}", f"D1 — Per-class F1 on {DS_SHORT[d]}: seen vs unseen attacker hosts (%)",
                ["Class"] + [h for _, _, h in cols], rows,
                "* = variant-shift class (test flows are mostly a sub-attack never seen in training)." if vshift.get(d) else None)


def _pair(rs, d, a, b):
    import numpy as _np
    xs = {r["spec"]["seed"]: r["result"]["variants"] for r in rs if r["spec"]["dataset"] == d}
    diffs = [100 * (v[b]["metrics"]["macro_f1"] - v[a]["metrics"]["macro_f1"]) for v in xs.values()]
    if not diffs:
        return "--"
    n = len(diffs)
    signs = _np.array([[1 if (i >> j) & 1 else -1 for j in range(n)] for i in range(2 ** n)])
    p = float((_np.abs((signs * _np.array(diffs)).mean(1)) >= abs(_np.mean(diffs)) - 1e-12).mean())
    return f"{_np.mean(diffs):+.2f} [{p:.2f}]"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    a = ap.parse_args()
    R = load_runs(a.results)
    d = os.path.join(a.results, "tables")
    os.makedirs(d, exist_ok=True)
    O = Out(d)
    models = ["xgboost", "rf", "mlp", "egsage", "dirgnn", "multignn", "multignn_fixed", "symdig"]
    # runs on other attacker-disjoint split seeds (experiment HS) only enter the HS table
    R_main = [r for r in R if split_seed_of(r) == 42]
    for f in (e1, e2, b0, e3, lambda R, O: e4(R, O, models), e5, e6, sc, e7, e8, t1, h, d1, ic):
        try:
            f(R_main, O)
        except Exception as ex:  # partial results are normal while experiments are running
            O.md.append(f"\n(skipped a table: {type(ex).__name__}: {ex})\n")
    try:
        hs(R, O)
    except Exception as ex:
        O.md.append(f"\n(skipped a table: {type(ex).__name__}: {ex})\n")
    O.save()
    print("\n".join(O.md))
    print(f"\nwrote {d}/summary.md and {d}/*.tex")


if __name__ == "__main__":
    main()
