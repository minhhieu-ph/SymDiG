"""End-to-end check of the code-v5 additions on a tiny synthetic dataset (GPU or CPU, ~2-3 minutes).
Run once on the experiment machine before `python run.py plan IC HS`:

    python scripts/check_v5.py

  IC  trains a tiny GNN on the attacker-disjoint split, scores the checkpoint with the test-graph,
      training-graph and no context (job kind `ctxeval`), and runs traffic injection with the
      training-graph context (chaff must not change the scores).
  HS  builds the attacker-disjoint split with another split seed and checks that it differs.
Writes only under results_check_v5/.
"""
import copy
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tests"))

from synthetic import SPEC, make  # noqa: E402
from symdig.data import NetFlowData, get_split, prepare  # noqa: E402
from symdig.executors import resolve, resolved_cfg_for_record, run_ctxeval, run_evasion, run_gnn  # noqa: E402
from symdig.jobs import job_id, load_config  # noqa: E402
from symdig.planner import smoke_config  # noqa: E402

ROOT = "results_check_v5"


def train(cfg, spec):
    spec = dict(spec, id=job_id(spec))
    res = run_gnn(cfg, spec, ROOT, lambda *a: None)
    json.dump({"id": spec["id"], "spec": spec, "cfg": resolved_cfg_for_record(cfg, spec, ROOT), "result": res},
              open(os.path.join(ROOT, "runs", f"{spec['id']}.json"), "w"), default=str)
    return spec["id"], res


def main():
    shutil.rmtree(ROOT, ignore_errors=True)
    for d in ("dataset", "ckpt", "runs"):
        os.makedirs(f"{ROOT}/{d}", exist_ok=True)
    make(f"{ROOT}/dataset/NF-ToN-IoT-v2.csv", SPEC["NF-ToN-IoT-v2.csv"], 60000, 0)
    cfg = smoke_config(load_config("configs/default.yaml"))
    cfg["paths"].update(data_root=f"{ROOT}/dataset", cache=f"{ROOT}/cache", results=ROOT)
    cfg["data"]["max_rows"] = None
    cfg["runtime"] = {"threads": 4, "num_workers": 2}
    quiet = lambda *a: None
    prepare(cfg, "ton", log=quiet)

    print("IC inductive context")
    for split in ("p1B", "p1A"):
        jid, res = train(cfg, {"kind": "gnn", "dataset": "ton", "model": "ladder2", "split": split, "task": "multi",
                               "seed": 0, "overrides": {}})
        out = run_ctxeval(cfg, {"kind": "ctxeval", "dataset": "ton", "source_job": jid, "seed": 0, "split": split,
                                "contexts": ["full", "train", "none"]}, ROOT, quiet)
        f = {k: v["metrics"]["macro_f1"] for k, v in out["contexts"].items()}
        print(f"  {split}: trained run {res['metrics']['macro_f1']:.3f} | ctxeval full {f['full']:.3f} | "
              f"train {f['train']:.3f} | none {f['none']:.3f}")
        assert all(abs(v["coverage"] - 1.0) < 1e-9 for v in out["contexts"].values())   # every test flow scored
        assert out["split_seed"] == 42
        if split == "p1A":
            ev = run_evasion(cfg, {"kind": "evasion", "dataset": "ton", "model": "ladder2", "split": "p1A", "seed": 0,
                                   "source_job": jid, "classes": ["MITM", "Ransomware", "Backdoor", "Injection"],
                                   "strategies": ["flood"], "k": [0, 2], "context": "train"}, ROOT, quiet)
            r = ev["results"]["flood"]
            print(f"  injection with training-graph context: K=0 {r['0']['mean_f1']:.3f} | K=2 {r['2']['mean_f1']:.3f}")
            assert abs(r["0"]["mean_f1"] - r["2"]["mean_f1"]) < 1e-6        # chaff never enters the context

    print("HS other split seeds")
    data = NetFlowData(cfg, "ton")
    a = get_split(cfg, data, "p1B")
    c2 = copy.deepcopy(cfg)
    c2["data"]["split_seed"] = 43
    b = get_split(c2, data, "p1B")
    print(f"  split 42: {len(a.test):,} test flows | split 43: {len(b.test):,} test flows | "
          f"tags {a.meta.get('tag')} / {b.meta.get('tag')}")
    assert a.meta.get("tag") != b.meta.get("tag") and (len(a.test) != len(b.test) or (a.test != b.test).any())
    c3 = resolve(cfg, {"model": "xgboost", "overrides": {"data.split_seed": 44}}, ROOT)
    assert c3["data"]["split_seed"] == 44
    print("check_v5: all good")


if __name__ == "__main__":
    main()
