"""Code v3 checks that do not need PyTorch: endpoint-scoring batches (X1), the X1 / SC planner,
the SC budget estimates and the new tables (E2 rows 1b/2b, SC) on fabricated records.

    python tests/synthetic.py --out tests/tmp_dataset --rows 80000     (once)
    python tests/test_v3_numpy.py
"""
import json
import os
import shutil
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tests"))
os.chdir(ROOT)

from symdig.data import NetFlowData, get_split, graph_for  # noqa: E402
from symdig.jobs import job_id  # noqa: E402
from symdig.planner import Planner  # noqa: E402
from symdig.sampler import build_batch  # noqa: E402
from test_numpy_side import cfg_for_tests  # noqa: E402


def test_es_batch(cfg):
    d = NetFlowData(cfg, "ton")
    sp = get_split(cfg, d, "p1A")
    g = graph_for(d, sp, "test")
    t = np.random.default_rng(0).choice(sp.test, 500, replace=False)
    s_cfg = {"fanout": [5, 5], "tau_s": 0.0, "oversample": 4, "max_hop_edges": 50000}
    for coupled in (False, True):
        b0 = build_batch(g, t, {"coupled": coupled, "force": False}, s_cfg, np.random.default_rng(3))
        b = build_batch(g, t, {"coupled": coupled, "force": False, "score_all": True}, s_cfg, np.random.default_rng(3))
        # same sampled graph as the unforced sampler (ES changes the scoring, not the sampling)
        assert np.array_equal(b["ef_ids"], b0["ef_ids"]) and np.array_equal(b["er_ids"], b0["er_ids"])
        assert b["present"].all() and len(b["t_src"]) == len(b["targets"])
        nodes = b["nodes"]
        assert np.array_equal(nodes[b["t_src"]], d.src[b["targets"]])
        assert np.array_equal(nodes[b["t_dst"]], d.dst[b["targets"]])
        assert np.array_equal(nodes[b["ei_f"][0]], d.src[b["ef_ids"]])
        if coupled:
            assert np.array_equal(b["ei_r"], b["ei_f"][::-1])
        else:
            assert np.array_equal(nodes[b["ei_r"][0]], d.dst[b["er_ids"]])
        ing = np.isin(b["targets"], b["ef_ids"]).mean()
        cov0 = b0["present"].mean()
        assert abs(ing - cov0) < 1e-12        # the unforced sampler's coverage = ES in-graph share
        print(f"  ES batch ok (coupled={coupled}): every target scored, own edge sampled for {100 * ing:.1f}%")


def test_planner(cfg):
    cfg = json.loads(json.dumps(cfg))
    cfg["experiments"]["seeds"] = [0, 1, 2, 3, 4]
    cfg["experiments"]["seeds_large"] = [0, 1, 2]
    P = Planner(cfg, cfg_hash="h")
    specs = P.plan(["X1"])
    x1 = [s for s in specs if s["exp"] == "X1"]
    assert len(x1) == 2 * (3 * 5 + 3), len(x1)          # rungs 1, 2 x (ton/unsw/ids2018: 5 seeds, bot: 3)
    assert all(s["overrides"] == {"model.force": False, "model.score_all": True} for s in x1)
    P2 = Planner(cfg, cfg_hash="h")
    e2 = {job_id(s) for s in P2.plan(["E2"]) if s["kind"] == "gnn"}
    assert not e2 & {job_id(s) for s in x1}              # ES never collides with a ladder job
    P3 = Planner(cfg, cfg_hash="h")
    sc = [s for s in P3.plan(["SC"]) if s["kind"] == "scale"]
    assert len(sc) == 4 * 4 * 2, len(sc)
    assert {s["mode"] for s in sc} == {"fullgraph", "c3s"}
    print(f"  planner ok: X1 {len(x1)} jobs, SC {len(sc)} jobs")


def test_budget(cfg):
    from symdig.gpu_budget import estimate_gb, estimate_ram_gb, ram_key
    fg = {"kind": "scale", "dataset": "ton", "mode": "fullgraph", "frac": 1.0, "mem_cap_gb": None, "model": "egsage"}
    cs = dict(fg, mode="c3s", mem_cap_gb=16)
    assert estimate_gb(fg, cfg, 275) == 275           # full-graph: GPU to itself
    assert estimate_gb(cs, cfg, 275) == 16
    assert ram_key(fg) != ram_key(dict(fg, frac=0.1)) != ram_key(cs)
    assert estimate_ram_gb(fg, cfg) > 0
    print("  budget ok")


def test_tables():
    import importlib
    mt = importlib.import_module("make_tables")
    res = "tests/tmp_results_v3"
    shutil.rmtree(res, ignore_errors=True)
    os.makedirs(f"{res}/runs")
    rng = np.random.default_rng(0)
    classes = ["Benign", "a", "b"]

    def met(f):
        return {"macro_f1": f, "per_class": {c: {"f1": f, "support": 10} for c in classes}}
    recs = []
    for rung in range(5):
        for s in range(3):
            recs.append({"spec": {"exp": "E2", "kind": "gnn", "dataset": "ton", "model": f"ladder{rung}", "split": "p1A",
                                  "task": "multi", "seed": s, "overrides": {}},
                         "result": {"metrics": met(0.6 + 0.05 * rung + 0.01 * rng.random()), "classes": classes,
                                    "eval_order": "random", "test_seed_coverage": 0.5 if rung == 0 else None,
                                    "metrics_covered": met(0.9) if rung == 0 else None}})
    for rung in (1, 2):
        for s in range(3):
            recs.append({"spec": {"exp": "X1", "kind": "gnn", "dataset": "ton", "model": f"ladder{rung}", "split": "p1A",
                                  "task": "multi", "seed": s, "overrides": {"model.force": False, "model.score_all": True}},
                         "result": {"metrics": met(0.55 + 0.01 * rng.random()), "classes": classes, "eval_order": "random",
                                    "test_target_in_graph": 0.4, "test_seed_coverage": 1.0}})
    for frac in (0.1, 1.0):
        recs.append({"spec": {"exp": "SC", "kind": "scale", "dataset": "ton", "model": "egsage", "mode": "fullgraph",
                              "frac": frac, "seed": 0},
                     "result": ({"status": "ok", "peak_vram_gb": 12.0, "train_sec": 300, "metrics": met(0.7),
                                 "n_graph_train": 1000, "gpu_name": "TestGPU", "gpu_total_gb": 80} if frac < 1 else
                                {"status": "OOM", "oom_stage": "train", "peak_vram_gb": 79.5, "n_graph_train": 10000,
                                 "gpu_name": "TestGPU", "gpu_total_gb": 80})})
        recs.append({"spec": {"exp": "SC", "kind": "scale", "dataset": "ton", "model": "egsage", "mode": "c3s",
                              "frac": frac, "seed": 0},
                     "result": {"status": "ok", "peak_vram_gb": 2.5, "train_sec": 900, "metrics": met(0.8),
                                "n_graph_train": 1000 if frac < 1 else 10000, "gpu_name": "TestGPU", "gpu_total_gb": 80}})
    for i, r in enumerate(recs):
        r["id"] = f"r{i}"
        json.dump(r, open(f"{res}/runs/r{i}.json", "w"))
    R = mt.load_runs(res)
    O = mt.Out(res)
    mt.e2(R, O)
    mt.sc(R, O)
    md = "\n".join(O.md)
    assert "(1b) asymmetric sampler, endpoint scoring" in md and "(2b) coupled sampler" in md
    assert "OOM (train) at 79.5 GB" in md and "yes/yes" in md
    row1 = next(l for l in md.splitlines() if l.startswith("| (1) "))
    assert "55." not in row1                              # ES runs are not mixed into rung 1
    shutil.rmtree(res, ignore_errors=True)
    print("  tables ok")


def test_orphans():
    """A job whose worker process died goes back to pending (at most max_retries times), then fails."""
    import subprocess
    import tempfile
    from symdig.jobs import Queue
    root = tempfile.mkdtemp()
    q = Queue(root)
    jid, _ = q.add({"exp": "X", "kind": "gnn", "dataset": "ton", "seed": 0, "after": []})
    p = subprocess.Popen([sys.executable, "-c", "pass"])
    p.wait()                                            # a pid that no longer exists
    for k in (1, 2, 3):
        spec, _ = q.claim()
        assert spec and spec["id"] == jid
        q.set_owner(jid)
        live = q.orphans()[0]
        assert not live                                 # owned by this (alive) process: not an orphan
        json.dump({"host": __import__("socket").gethostname(), "pid": p.pid}, open(q._owner_path(jid), "w"))
        assert q.reap_orphans(max_retries=2, log=lambda *a: None) == 1
        state = q.state_of(jid)
        assert state == ("pending" if k <= 2 else "failed"), (k, state)
    assert "died" in json.load(open(q.p("failed", jid)))["error"]
    # jobs claimed by older code (no owner record) are reported, never touched
    jid2, _ = q.add({"exp": "X", "kind": "gnn", "dataset": "ton", "seed": 1, "after": []})
    q.claim()
    dead, unknown = q.orphans()
    assert not dead and unknown == [jid2]
    assert q.reap_orphans(log=lambda *a: None) == 0 and q.state_of(jid2) == "running"
    shutil.rmtree(root, ignore_errors=True)
    print("  orphan recovery ok")


def test_v5_planner(cfg):
    cfg = json.loads(json.dumps(cfg))
    cfg["experiments"]["seeds"] = [0, 1, 2, 3, 4]
    cfg["experiments"]["seeds_large"] = [0, 1, 2]
    P = Planner(cfg, cfg_hash="h")
    sp = P.plan(["IC"])
    ce = [s for s in sp if s["kind"] == "ctxeval"]
    ev = [s for s in sp if s["kind"] == "evasion"]
    assert len(ce) == 2 * 2 * (3 * 5 + 3), len(ce) and len(ev) == 3
    assert all(s["context"] == "train" for s in ev)
    # IC trains nothing new for models already in E4 / E5: same job ids
    P2 = Planner(cfg, cfg_hash="h")
    e45 = {job_id(s) for s in P2.plan(["E4", "E5"]) if s["kind"] == "gnn"}
    ic_gnn = {job_id(s) for s in sp if s["kind"] == "gnn"}
    new = [s for s in sp if s["kind"] == "gnn" and job_id(s) not in e45]
    assert all(s["model"] == "multignn_fixed" and s["split"] == "p1B" for s in new), {(s["model"], s["split"]) for s in new}
    assert len(ic_gnn) == len(ce)
    P3 = Planner(cfg, cfg_hash="h")
    hs = P3.plan(["HS"])
    fin = [s for s in hs if s["kind"] in ("gnn", "tabular") and s.get("overrides", {}).get("data.split_seed")]
    assert len(fin) == 2 * 4 * 4 * 3, len(fin)
    assert len([s for s in hs if s["kind"] == "ctxeval"]) == 2 * 4 * 2 * 3
    print(f"  v5 planner ok: IC {len(ce)} ctxeval + {len(new)} new trainings, HS {len(fin)} runs")


def test_v5_tables():
    import importlib
    mt = importlib.import_module("make_tables")
    res = "tests/tmp_results_v5"
    shutil.rmtree(res, ignore_errors=True)
    os.makedirs(f"{res}/runs")
    classes = ["Benign", "a", "b"]

    def met(f):
        return {"macro_f1": f, "per_class": {c: {"f1": f, "support": 10} for c in classes}}
    recs = []
    for ss in (42, 43):
        for m in ("symdig", "multignn_fixed"):
            for s in range(3):
                recs.append({"spec": {"exp": "IC" if ss == 42 else "HS", "kind": "ctxeval", "dataset": "ids2018", "seed": s,
                                      "split": "p1B", "split_v": 3, "source_job": f"x{ss}{m}{s}"},
                             "result": {"src_model": m, "split": "p1B", "split_seed": ss, "classes": classes,
                                        "contexts": {"full": {"metrics": met(0.30 + 0.01 * s)},
                                                     "train": {"metrics": met(0.60 + 0.01 * s)},
                                                     "none": {"metrics": met(0.55)}}}})
        for s in range(3):
            ov = {} if ss == 42 else {"data.split_seed": ss}
            recs.append({"spec": {"exp": "E5", "kind": "tabular", "dataset": "ids2018", "model": "xgboost", "split": "p1B", "split_v": 3,
                                  "task": "multi", "seed": s, "overrides": ov},
                         "result": {"metrics": met(0.62), "classes": classes}, "cfg": {"data": {"ports": True}}})
    recs.append({"spec": {"exp": "IC", "kind": "evasion", "dataset": "ton", "model": "symdig", "seed": 0, "context": "train"},
                 "result": {"attacked": ["a"], "context": "train",
                            "results": {"flood": {"0": {"mean_f1": 0.8}, "10": {"mean_f1": 0.8}}}}})
    for i, r in enumerate(recs):
        r["id"] = f"r{i}"
        json.dump(r, open(f"{res}/runs/r{i}.json", "w"))
    R = mt.load_runs(res)
    O = mt.Out(res)
    R_main = [r for r in R if mt.split_seed_of(r) == 42]
    mt.ic(R_main, O)
    mt.hs(R, O)
    mt.e7(R_main, O)
    md = "\n".join(O.md)
    assert "training-graph context (IC)" in md and "Δ train vs test-graph context" in md, md[:500]
    assert "+30.00" in md                                   # paired delta train vs full
    assert "HS — Attacker-disjoint split" in md and "30.0 / 30.0" in md.replace("31.0", "30.0") or "/" in md
    assert "IC_evasion" not in md or "Traffic injection" in md
    assert "E7 — Mean F1" not in md                         # IC evasion runs stay out of the E7 table
    shutil.rmtree(res, ignore_errors=True)
    print("  v5 tables ok")


if __name__ == "__main__":
    c = cfg_for_tests()
    test_es_batch(c)
    test_planner(c)
    test_budget(c)
    test_tables()
    test_orphans()
    test_v5_planner(c)
    test_v5_tables()
    print("test_v3_numpy: all good")
