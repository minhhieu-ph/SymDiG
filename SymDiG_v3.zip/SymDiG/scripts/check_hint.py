"""End-to-end check of the HINT code on a tiny synthetic dataset (GPU or CPU, ~2-5 minutes).
Run once on the experiment machine before `python run.py plan HP`:

    python scripts/check_hint.py

Trains every HINT variant for 2 short epochs, runs a 2-trial tuning and a tiny D1 diagnostic,
and checks that metrics, worst-host recall and host probes come out. Writes only under results_check_hint/.
"""
import copy
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tests"))

from synthetic import SPEC, make  # noqa: E402
from symdig.data import NetFlowData, get_split  # noqa: E402
from symdig.hint import VARIANTS, run_hint, tune_hint  # noqa: E402
from symdig.hint_spec import resolve_hp, variant_spec  # noqa: E402
from symdig.jobs import load_config  # noqa: E402
from symdig.planner import smoke_config  # noqa: E402

ROOT = "results_check_hint"


def main():
    shutil.rmtree(ROOT, ignore_errors=True)
    os.makedirs(f"{ROOT}/dataset", exist_ok=True)
    make(f"{ROOT}/dataset/NF-ToN-IoT-v2.csv", SPEC["NF-ToN-IoT-v2.csv"], 60000, 0)
    cfg = smoke_config(load_config("configs/default.yaml"))
    cfg["paths"].update(data_root=f"{ROOT}/dataset", cache=f"{ROOT}/cache", results=ROOT)
    cfg["data"]["max_rows"] = None
    cfg["runtime"] = {"threads": 4, "num_workers": 2}
    cfg["train"]["num_workers"] = 2
    data = NetFlowData(cfg, "ton")
    split = get_split(cfg, data, "p1H")
    print(f"split p1H: train {len(split.train):,} | val {len(split.val):,} | test {len(split.test):,}")
    tiny = dict(epochs=2, steps=5, batch=512, patience=2, probe_n=5000)
    for v in VARIANTS:
        _, hint = variant_spec(v)
        hp = resolve_hp({"hint": hint}, ROOT)
        hp.update(tiny)
        r = run_hint(cfg, data, split, 0, hp, log=lambda *a: None)
        hr = r.get("host_recall") or {}
        pr = r.get("probe_hid") or {}
        print(f"  {v:15s} test macro-F1 {r['metrics']['macro_f1']:.3f} | worst-host p10 {hr.get('p10', float('nan')):.3f}"
              f" | host probe {pr.get('acc', float('nan')):.3f} (majority {pr.get('majority', float('nan')):.3f})")
    group, hint = variant_spec("hint_gnn")
    c2 = copy.deepcopy(cfg)
    c2["tuning"].update(trials=2, gnn_epochs=1, gnn_steps=3)
    out = tune_hint(c2, {"dataset": "ton", "split": "p1H", "hint": hint, "trials": 2, "tune_key": "hint__check"}, ROOT,
                    lambda *a: None)
    print(f"  tuning: best val macro-F1 {out['best_val_macro_f1']:.3f} with {out['best_params']}")
    # diagnostic D1 (seen vs unseen attacker hosts, less graph context)
    from symdig.diag import run_diag_host
    d1 = run_diag_host(cfg, {"dataset": "ton", "split": "p1B", "seed": 0, "variants": ["gnn_plain", "flow_plain"],
                             "hp_override": tiny, "xgb_override": {"n_estimators": 20}}, ROOT, lambda *a: None)
    for mname, sets in d1["models"].items():
        print(f"  D1 {mname:10s} " + " | ".join(f"{k} {v['metrics']['macro_f1']:.3f}" for k, v in sets.items()))
    print("\nOK")


if __name__ == "__main__":
    main()
