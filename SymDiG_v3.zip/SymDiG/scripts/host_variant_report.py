"""Are unseen attacker hosts also unseen attack variants? (IDS2018: families group sub-attacks.)

    python scripts/host_variant_report.py                  # ids2018
    python scripts/host_variant_report.py --dataset ids2018 --max-hosts 12

NF-CSE-CIC-IDS2018-v2 labels sub-attacks (e.g. DoS = GoldenEye / Hulk / Slowloris /
SlowHTTPTest); the cache keeps only the 6 families. This script re-reads the raw `Attack`
column of the CSV (aligned row by row with the cache) and prints, per family, which sub-attacks
each attacking source host runs and whether the host is a training or a test host in the
current p1B split. Hosts appear as h1, h2, ... (by number of flows); only counts are printed.
The last lines give, per family, the share of test flows whose sub-attack never occurs in
training: those test flows are a new attack variant, not only a new host.
"""
import argparse
import json
import os
import sys

import numpy as np
import pandas as pd
import yaml

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symdig.data import NetFlowData, canonical_attack, find_csv, get_split  # noqa: E402
from symdig.jobs import load_config  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="ids2018")
    ap.add_argument("--split", default="p1B")
    ap.add_argument("--max-hosts", type=int, default=12, help="hosts listed per family (largest first)")
    ap.add_argument("--results", default="results")
    ap.add_argument("--config", default="configs/default.yaml")
    a = ap.parse_args()
    snap = os.path.join(a.results, "config.yaml")
    cfg = yaml.safe_load(open(snap)) if os.path.exists(snap) else load_config(a.config)
    if cfg["data"].get("max_rows"):
        sys.exit("data.max_rows is set: the cache is a subsample and cannot be aligned with the CSV")
    data = NetFlowData(cfg, a.dataset)
    y = data.y_multi
    src, _ = data.ip_arrays()
    path = find_csv(cfg["paths"]["data_root"], a.dataset)
    print(f"reading the Attack column of {os.path.basename(path)} ...", flush=True)
    raw = pd.concat([c["Attack"].astype(str).str.strip()
                     for c in pd.read_csv(path, usecols=["Attack"], chunksize=5_000_000)], ignore_index=True)
    if len(raw) != len(y):
        sys.exit(f"row count differs: CSV {len(raw):,} vs cache {len(y):,}")
    fam = raw.map(lambda s: canonical_attack(s, a.dataset, True))
    names = data.classes
    if not (fam.map({n: i for i, n in enumerate(names)}).to_numpy() == y).all():
        sys.exit("the CSV labels do not match the cache labels row by row (different CSV?)")
    sub_codes, sub_names = pd.factorize(raw)
    sp = get_split(cfg, data, a.split)
    in_test = np.zeros(len(y), bool)
    in_test[sp.test] = True
    in_train = np.zeros(len(y), bool)
    in_train[sp.train] = True
    in_train[sp.val] = True

    summary = []
    for c in range(1, len(names)):
        m = np.flatnonzero(y == c)
        subs = np.unique(sub_codes[m])
        hosts, cnt = np.unique(src[m], return_counts=True)
        order = np.argsort(-cnt)
        sub_lab = [str(sub_names[s]) for s in subs]
        print(f"\n=== {names[c]}: {len(hosts)} source hosts, {len(subs)} sub-attack label(s)")
        if len(subs) > 1 or len(hosts) <= a.max_hosts:
            w = max(10, max(len(s) for s in sub_lab) + 1)
            print(f"{'host':6s} {'side':5s} {'flows':>10s} | " + " ".join(f"{s[:w]:>{w}s}" for s in sub_lab))
            for r, j in enumerate(order[: a.max_hosts]):
                mh = m[src[m] == hosts[j]]
                side = "test" if in_test[mh].any() else ("train" if in_train[mh].any() else "-")
                cells = [int((sub_codes[mh] == s).sum()) for s in subs]
                print(f"h{r + 1:<5d} {side:5s} {cnt[j]:>10,} | " + " ".join(f"{x:>{w},}" for x in cells))
            if len(order) > a.max_hosts:
                print(f"... {len(order) - a.max_hosts} smaller hosts not listed")
        te = m[in_test[m]]
        tr = m[in_train[m]]
        seen = set(np.unique(sub_codes[tr]).tolist())
        unseen = [s for s in np.unique(sub_codes[te]) if s not in seen]
        frac = float(np.isin(sub_codes[te], unseen).mean()) if len(te) else float("nan")
        summary.append((names[c], len(te), frac, [str(sub_names[s]) for s in unseen]))
    print(f"\nTest flows whose sub-attack never occurs in training ({a.split}):")
    for n, nte, f, un in summary:
        print(f"  {n:15s} test flows {nte:>10,} | unseen sub-attack {100 * f:5.1f}%" + (f"  {un}" if un else ""))
    # p1H has the same test set as p1B: make_tables.py uses this file for both
    out = os.path.join(a.results, "variants")
    os.makedirs(out, exist_ok=True)
    f = os.path.join(out, f"{a.dataset}.json")
    json.dump({"split": a.split, "split_tag": sp.meta.get("tag"),
               "classes": {n: {"test_flows": int(nte), "unseen_frac": None if f_ != f_ else float(f_), "unseen": un}
                           for n, nte, f_, un in summary}}, open(f, "w"), indent=1)
    print(f"\nwrote {f} (make_tables.py reports macro-F1 without the variant-shift classes)")


if __name__ == "__main__":
    main()
