"""Why does coupling forward/reverse edges help a lot on the motif benchmark (E3) but little on the
real datasets (E2 rung 2 vs 1: +0.1 to +1.4)? CPU only, a few minutes.

    python scripts/graph_stats.py                    # ton unsw ids2018 bot (those in the cache)

Per dataset, on the IP-centric multigraph (one edge per flow):
  multiplicity   flows per ordered host pair (u, v); share of flows on pairs with M >= 4 / 16 / 64 / 256
  reciprocity    share of ordered pairs whose reverse pair (v, u) also carries flows, and the share of
                 flows (all / attack only) that sit on such reciprocated pairs
Proposition 1 says coupling matters when a motif mixes directions over high-multiplicity pairs; if few
attack flows sit on reciprocated pairs, the real data rarely presents that case.
"""
import argparse
import os
import sys

import numpy as np
import yaml

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symdig.data import NetFlowData, is_ready  # noqa: E402
from symdig.jobs import load_config  # noqa: E402


def stats(src, dst, y, n_nodes):
    key = src.astype(np.int64) * n_nodes + dst.astype(np.int64)
    pairs, inv, mult = np.unique(key, return_inverse=True, return_counts=True)
    u, v = pairs // n_nodes, pairs % n_nodes
    rev = v * n_nodes + u
    pos = np.searchsorted(pairs, rev)
    pos[pos >= len(pairs)] = 0
    recip = (pairs[pos] == rev) & (u != v)
    m_flow = mult[inv]
    r_flow = recip[inv]
    att = y != 0
    out = {"flows": len(key), "pairs": len(pairs), "mean_mult": len(key) / len(pairs),
           "recip_pairs": float(recip.mean()), "flows_on_recip": float(r_flow.mean()),
           "attack_flows_on_recip": float(r_flow[att].mean()) if att.any() else float("nan")}
    for t in (4, 16, 64, 256):
        out[f"m{t}"] = float((m_flow >= t).mean())
        out[f"att_m{t}"] = float((m_flow[att] >= t).mean()) if att.any() else float("nan")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="*", default=["ton", "unsw", "ids2018", "bot"])
    ap.add_argument("--results", default="results")
    ap.add_argument("--config", default="configs/default.yaml")
    a = ap.parse_args()
    snap = os.path.join(a.results, "config.yaml")
    cfg = yaml.safe_load(open(snap)) if os.path.exists(snap) else load_config(a.config)
    print(f"{'dataset':8s} {'flows':>12s} {'pairs':>10s} {'mean M':>8s} | {'flows on pairs with M>=':>26s} | "
          f"{'reciprocated':>12s} {'flows on recip.':>15s} {'attack flows on recip.':>22s}")
    print(f"{'':8s} {'':>12s} {'':>10s} {'':>8s} | {'4':>5s} {'16':>6s} {'64':>6s} {'256':>6s} | "
          f"{'pairs':>12s} {'':>15s} {'':>22s}")
    for ds in a.datasets:
        if not is_ready(cfg, ds):
            print(f"{ds:8s} not in the cache, skipped")
            continue
        data = NetFlowData(cfg, ds)
        s = stats(data.src, data.dst, data.y_multi, data.num_nodes)
        pc = lambda x: f"{100 * x:5.1f}%"
        print(f"{ds:8s} {s['flows']:>12,} {s['pairs']:>10,} {s['mean_mult']:>8.1f} | {pc(s['m4'])} {pc(s['m16'])} "
              f"{pc(s['m64'])} {pc(s['m256'])} | {pc(s['recip_pairs']):>12s} {pc(s['flows_on_recip']):>15s} "
              f"{pc(s['attack_flows_on_recip']):>22s}")
        print(f"{'  attack':8s} {'':>12s} {'':>10s} {'':>8s} | {pc(s['att_m4'])} {pc(s['att_m16'])} "
              f"{pc(s['att_m64'])} {pc(s['att_m256'])} |")


if __name__ == "__main__":
    main()
