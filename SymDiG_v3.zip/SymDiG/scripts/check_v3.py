"""End-to-end check of the code-v3 additions on a tiny synthetic dataset (GPU or CPU, ~2-4 minutes).
Run once on the experiment machine before `python run.py plan X1 SC`:

    python scripts/check_v3.py

  X1  endpoint scoring (ES) on ladder rungs 1 and 2: trains 2 short epochs, checks that every test
      target is scored (coverage 1.0) and reports the share of targets whose own edge was sampled.
  SC  full-graph E-GraphSAGE and E-GraphSAGE + C3S on 10 % and 100 % of the data; then a full-graph run
      under a tiny memory cap (GPU only) to check that running out of memory is recorded, not raised.
Writes only under results_check_v3/.
"""
import copy
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tests"))

from synthetic import SPEC, make  # noqa: E402
from symdig.executors import run_gnn  # noqa: E402
from symdig.jobs import load_config  # noqa: E402
from symdig.planner import smoke_config  # noqa: E402
from symdig.scale import run_scale  # noqa: E402

ROOT = "results_check_v3"


def main():
    shutil.rmtree(ROOT, ignore_errors=True)
    os.makedirs(f"{ROOT}/dataset", exist_ok=True)
    os.makedirs(f"{ROOT}/ckpt", exist_ok=True)
    make(f"{ROOT}/dataset/NF-ToN-IoT-v2.csv", SPEC["NF-ToN-IoT-v2.csv"], 60000, 0)
    cfg = smoke_config(load_config("configs/default.yaml"))
    cfg["paths"].update(data_root=f"{ROOT}/dataset", cache=f"{ROOT}/cache", results=ROOT)
    cfg["data"]["max_rows"] = None
    cfg["runtime"] = {"threads": 4, "num_workers": 2}
    quiet = lambda *a: None
    from symdig.data import prepare
    prepare(cfg, "ton", log=quiet)

    print("X1 endpoint scoring")
    for rung in (1, 2):
        for es in (False, True):
            ov = {"model.force": False, "model.score_all": True} if es else {}
            r = run_gnn(cfg, {"kind": "gnn", "dataset": "ton", "model": f"ladder{rung}", "split": "p1A", "task": "multi",
                              "seed": 0, "overrides": ov}, ROOT, quiet)
            assert r["metrics"] is not None
            extra = (f" | test coverage {r['test_seed_coverage']:.2f} | own edge in graph "
                     f"{r['test_target_in_graph']:.2f}") if es else ""
            print(f"  rung {rung}{'b (ES)' if es else '     '} macro-F1 {r['metrics']['macro_f1']:.3f}{extra}")
            if es:
                assert abs(r["test_seed_coverage"] - 1.0) < 1e-9

    print("SC full-graph vs C3S (E-GraphSAGE)")
    c2 = copy.deepcopy(cfg)
    c2["experiments"]["sc"] = {"steps": 20, "eval_every": 5, "patience": 3, "max_minutes": 5}
    for frac in (0.1, 1.0):
        for mode in ("fullgraph", "c3s"):
            r = run_scale(c2, {"kind": "scale", "dataset": "ton", "model": "egsage", "seed": 0, "mode": mode,
                               "frac": frac, "mem_cap_gb": None}, ROOT, quiet)
            m = (r.get("metrics") or {}).get("macro_f1")
            print(f"  {mode:9s} frac {frac:4.2f}: {r['status']} | steps {r.get('steps')} | "
                  f"{r.get('sec_per_step') or 0:.3f} s/step | peak VRAM {r.get('peak_vram_gb') or 0:.2f} GB | "
                  f"macro-F1 {m if m is None else round(m, 3)}")
            assert r["status"] == "ok" and m is not None
    import torch
    if torch.cuda.is_available():
        r = run_scale(c2, {"kind": "scale", "dataset": "ton", "model": "egsage", "seed": 0, "mode": "fullgraph",
                           "frac": 1.0, "mem_cap_gb": 0.01}, ROOT, quiet)
        print(f"  fullgraph under a 0.01 GB cap: {r['status']} ({r.get('oom_stage')})")
        assert r["status"] == "OOM"
    print("check_v3: all good")


if __name__ == "__main__":
    main()
