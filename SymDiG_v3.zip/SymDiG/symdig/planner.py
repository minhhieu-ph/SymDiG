"""Expands each experiment of the proposal into job specs.

E1  diagnosis: seed/twin coverage of the samplers (no training) + Multi-GNN "as released"
E2  ablation ladder 0-4 on the four datasets
E3  synthetic motifs: survival vs multiplicity (empirical vs Proposition 1) + ladder 0-4
E4  same-frame comparison: tuned baselines on p1A (+ ports ablation) and on the FeCoGraph protocol p2
E5  robustness: host-disjoint split p1B + cross-dataset binary transfer
E6  deployability: graph sizes (IP vs IP:PORT vs line graph), VRAM / throughput / latency, 16 GB cap
E7  adaptive traffic injection (pair / reverse / flood) against trained detectors
X1  endpoint scoring (ES): every target scored from its endpoints, no forcing (ladder rungs 1b / 2b)
SC  coverage-scale trade-off: full-graph vs C3S training of E-GraphSAGE over data fractions
"""
import copy

from .jobs import job_id

from .data import HOST_SPLIT_VERSION, HOST_SPLITS

PRIO = {"reeval": 5, "prepare": 0, "coverage": 10, "survival": 10, "sizes": 10, "tune": 20, "hint_tune": 20,
        "gnn": 40, "tabular": 40, "hint": 40, "diag_host": 15,
        "fecograph": 45, "hybrid": 50, "transfer": 60, "scale": 65, "deploy": 70, "evasion": 80}


def spec(exp, kind, dataset, after=(), **kw):
    s = {"exp": exp, "kind": kind, "dataset": dataset, "after": [a for a in after if a],
         "priority": PRIO.get(kind, 50), "cfg_hash": Planner.CFG_HASH}
    s.update(kw)
    if s.get("split") in HOST_SPLITS and HOST_SPLIT_VERSION >= 2:
        s["split_v"] = HOST_SPLIT_VERSION   # new ids for p1B / p1H jobs only; every other job id is unchanged
    return s


class Planner:
    CFG_HASH = None

    def __init__(self, cfg, datasets=None, seeds=None, cfg_hash=None):
        Planner.CFG_HASH = cfg_hash
        self.cfg = cfg
        self.e = cfg["experiments"]
        self.datasets = datasets
        self.seeds_override = seeds
        self.specs = []

    # --------------------------------------------------------------- helpers
    def ds(self, default):
        return list(self.datasets) if self.datasets else list(default)

    def seeds(self, dataset):
        if self.seeds_override is not None:
            return list(self.seeds_override)
        return list(self.e["seeds_large"] if dataset == "bot" else self.e["seeds"])

    def add(self, s):
        self.specs.append(s)
        return job_id(s)

    def prep(self, dataset):
        return self.add(spec("prepare", "prepare", dataset))

    def tune_split(self, split):
        """Hyper-parameters are selected on the validation part of the SAME protocol the model is
        evaluated on (experiments.tune_on_eval_split). Tuning on p1A and testing on p1B/p2 would let
        the selection see labels of flows that are test flows under p1B/p2."""
        if split in ("p1B", "p2") and self.e.get("tune_on_eval_split", True):
            return split
        return "p1A"

    def tune(self, model, dataset, split="p1A", features="plain"):
        if self.cfg["models"][model]["kind"] == "fecograph":
            return None
        kind = self.cfg["models"][model]["kind"]
        td = self.cfg["tuning"]["gnn_datasets" if kind == "gnn" else "datasets"]
        tds = dataset if dataset in td else td[0]
        key = f"{model}__{tds}" + ("" if split == "p1A" else f"__{split}")
        extra = {}
        if features != "plain":                    # (plain tune specs stay byte-identical: same job ids)
            key += "__hn" if features == "hostnorm" else f"__{features}"
            extra["features"] = features
        return self.add(spec("tune", "tune", tds, after=[self.prep(tds)], model=model, split=split,
                             task="multi", trials=int(self.cfg["tuning"]["trials"]), **extra)), key

    def hint_tune(self, group, dataset, split):
        """Equal-budget tuning of a HINT hyper-parameter group on the split's validation part."""
        from .hint_spec import variant_spec
        _, hint = variant_spec(group)
        graph = hint["force"].get("graph", hint["base"].get("graph", True))
        td = self.cfg["tuning"]["gnn_datasets" if graph else "datasets"]
        tds = dataset if dataset in td else td[0]
        key = f"hint__{group}__{tds}__{split}"
        return self.add(spec("tune", "hint_tune", tds, after=[self.prep(tds)], model=group, split=split,
                             task="multi", hint=hint, trials=int(self.cfg["tuning"]["trials"]), tune_key=key)), key

    def final(self, exp, model, dataset, split, seed, task="multi", overrides=None, tuned=True):
        kind = self.cfg["models"][model]["kind"]
        after = [self.prep(dataset)]
        tkey = None
        if tuned and kind != "fecograph":
            tid, tkey = self.tune(model, dataset, self.tune_split(split))
            after.append(tid)
        s = spec(exp, kind, dataset, after=after, model=model, split=split, task=task, seed=seed,
                 tuned=tkey, overrides=overrides or {})
        return self.add(s)

    # --------------------------------------------------------------- experiments
    def E1(self):
        for d in self.ds(self.e["datasets"]):
            p = self.prep(d)
            for fo in self.e["e1_fanouts"]:
                self.add(spec("E1", "coverage", d, after=[p], split="p1A", fanout=fo,
                              batches=int(self.e["e1_batches"])))
            for s in self.seeds(d):
                self.add(spec("E1", "gnn", d, after=[p], model="ladder0", split="p1A", task="multi", seed=s,
                              preset="multignn_paper", overrides={}))

    def E2(self):
        for d in self.ds(self.e["datasets"]):
            p = self.prep(d)
            for rung in range(5):
                for s in self.seeds(d):
                    self.add(spec("E2", "gnn", d, after=[p], model=f"ladder{rung}", split="p1A", task="multi",
                                  seed=s, overrides={}))

    def E3(self):
        for M in self.cfg["motif"]["multiplicities"]:
            d = f"motif_m{M}"
            p = self.prep(d)
            self.add(spec("E3", "survival", d, after=[p], split="p1A", fanout=[20, 20]))
            for rung in range(5):
                for s in self.e["e3_seeds"]:
                    self.add(spec("E3", "gnn", d, after=[p], model=f"ladder{rung}", split="p1A", task="multi",
                                  seed=s, overrides={"data.ports": False}))

    def E4(self):
        for d in self.ds(self.e["datasets"]):
            for m in self.e["e4_models"]:
                for s in self.seeds(d):
                    self.final("E4", m, d, "p1A", s)
            for m in ("xgboost", "symdig"):
                for s in self.seeds(d):
                    self.final("E4", m, d, "p1A", s, overrides={"data.ports": False})
        for d in self.ds(self.e["e4_p2_datasets"]):
            for m in self.e["e4_p2_models"]:
                for s in self.seeds(d):
                    self.final("E4", m, d, "p2", s)

    def E5(self):
        dss = self.ds(self.e["datasets"])
        for d in dss:
            for m in self.e["e5_models"]:
                for s in self.seeds(d):
                    self.final("E5", m, d, "p1B", s)
        for m in self.e["e5_transfer_models"]:
            kind = self.cfg["models"][m]["kind"]
            for src in dss:
                for s in self.seeds(src)[:3]:
                    if kind == "gnn":
                        src_id = self.final("E5", m, src, "p1A", s, task="binary")
                    for tgt in dss:
                        if tgt == src:
                            continue
                        after = [self.prep(src), self.prep(tgt)]
                        tid, tkey = self.tune(m, src)
                        after.append(tid)
                        if kind == "gnn":
                            after.append(src_id)
                        self.add(spec("E5", "transfer", tgt, after=after, model=m, source=src, split="p1A",
                                      task="binary", seed=s, tuned=tkey,
                                      source_job=src_id if kind == "gnn" else None))

    def E6(self):
        for d in self.ds(self.e["e6_datasets"]):
            p = self.prep(d)
            self.add(spec("E6", "sizes", d, after=[p], fracs=self.e["e6_fracs"]))
            for m in self.e["e6_models"]:
                tid, tkey = self.tune(m, d)
                for cap in self.e["e6_mem_caps_gb"]:
                    self.add(spec("E6", "deploy", d, after=[p, tid], model=m, split="p1A", task="multi", seed=0,
                                  tuned=tkey, frac=1.0, mem_cap_gb=cap, steps=int(self.e["e6_profile_steps"])))
            for f in self.e["e6_fracs"]:
                if f < 1.0:
                    tid, tkey = self.tune("symdig", d)
                    self.add(spec("E6", "deploy", d, after=[p, tid], model="symdig", split="p1A", task="multi",
                                  seed=0, tuned=tkey, frac=f, mem_cap_gb=None, steps=int(self.e["e6_profile_steps"])))

    def E7(self):
        d = self.e["e7_dataset"]
        if self.datasets:
            d = self.datasets[0]
        for m in self.e["e7_models"]:
            for s in self.seeds(d)[:3]:
                src = self.final("E4", m, d, "p1A", s)
                self.add(spec("E7", "evasion", d, after=[self.prep(d), src], model=m, split="p1A", task="multi",
                              seed=s, source_job=src, classes=self.e["e7_classes"],
                              strategies=self.e["e7_strategies"], k=self.e["e7_k"]))

    def E8(self):
        """Hybrid: tuned rung-2 GNN context (and label-free graph statistics) as XGBoost features."""
        gm = self.e.get("e8_gnn_model", "multignn_fixed")
        for d in self.ds(self.e["datasets"]):
            p = self.prep(d)
            for split in self.e.get("e8_splits", ["p1A", "p1B"]):
                gt, gkey = self.tune(gm, d, self.tune_split(split))
                xt, xkey = self.tune("xgboost", d, self.tune_split(split))
                for s in self.seeds(d)[:int(self.e.get("e8_seeds", 3))]:
                    self.add(spec("E8", "hybrid", d, after=[p, gt, xt], model=gm, split=split, task="multi", seed=s,
                                  tuned=gkey, xgb_tuned=xkey, overrides={}))

    def T1(self):
        """The user's TargetEdgeLoader as the sampler of ladder rung 1 (everything else as E2)."""
        for d in self.ds(self.e["datasets"]):
            p = self.prep(d)
            for be in self.e.get("t1_backends", ["tel_orig", "tel_fixed"]):
                ov = {"sampler.backend": be}
                self.add(spec("T1", "coverage", d, after=[p], split="p1A", fanout=list(self.cfg["sampler"]["fanout"]),
                              batches=int(self.e["e1_batches"]), overrides=ov))
                for s in self.seeds(d):
                    self.add(spec("T1", "gnn", d, after=[p], model="ladder1", split="p1A", task="multi",
                                  seed=s, overrides=ov))

    def H(self, pilot=False):
        """Host-invariant NIDS (HINT). Split p1H = p1B test set + attacker-disjoint validation.
        pilot=True (experiment HP): untuned defaults, 3 datasets, 3 seeds, core variants only."""
        from .hint_spec import variant_spec
        hc = self.e.get("h", {}) or {}
        split = "p1H"
        dss = self.ds(hc.get("pilot_datasets", ["ton", "ids2018", "unsw"]) if pilot else self.e["datasets"])
        variants = (hc.get("pilot_variants", ["gnn_plain", "hint_gnn", "hint_gnn_nodro", "hint_flow",
                                              "flow_plain"]) if pilot
                    else hc.get("variants", ["gnn_plain", "hint_gnn", "hint_gnn_nohn", "hint_gnn_noadv",
                                             "hint_gnn_nodro", "hint_flow", "hint_flow_ftt", "flow_plain"]))
        # the pilot decides the direction: when planned together with other experiments, its jobs
        # are claimed right after the cheap re-evaluations (priority is not part of the job id)
        first = {"priority": 15} if pilot else {}
        for d in dss:
            p = self.prep(d)
            seeds = self.seeds(d)[:3] if pilot else self.seeds(d)
            for m in ("xgboost", "mlp"):
                for feat in ("plain", "hostnorm"):
                    after, tkey = [p], None
                    if not pilot:
                        tid, tkey = self.tune(m, d, split, features=feat)
                        after.append(tid)
                    for s in seeds:
                        self.add(spec("H", "tabular", d, after=after, model=m, split=split, task="multi", seed=s,
                                      tuned=tkey, features=feat, overrides={}, **first))
            for v in variants:
                group, hint = variant_spec(v)
                after, hkey = [p], None
                if not pilot:
                    tid, hkey = self.hint_tune(group, d, split)
                    after.append(tid)
                for s in seeds:
                    self.add(spec("H", "hint", d, after=after, model=v, split=split, task="multi", seed=s,
                                  hint=hint, hint_tuned=hkey, **first))
            if not pilot:                      # no trade-off on the random split?
                for v in ("gnn_plain", "hint_gnn"):
                    group, hint = variant_spec(v)
                    tid, hkey = self.hint_tune(group, d, split)
                    for s in seeds:
                        self.add(spec("H", "hint", d, after=[p, tid], model=v, split="p1A", task="multi", seed=s,
                                      hint=hint, hint_tuned=hkey))
        d = hc.get("lambda_dataset", "ton")
        if not pilot and d in dss:             # adversary strength: p1H accuracy vs host probe
            group, hint = variant_spec("hint_gnn")
            tid, hkey = self.hint_tune(group, d, split)
            for lam in hc.get("lambdas", [0.0, 0.03, 0.1, 0.3, 1.0]):
                h2 = {"base": dict(hint["base"]), "force": dict(hint["force"], adv_lambda=float(lam))}
                for s in self.seeds(d)[:3]:
                    self.add(spec("H", "hint", d, after=[self.prep(d), tid], model="hint_gnn_lambda", split=split,
                                  task="multi", seed=s, hint=h2, hint_tuned=hkey, sweep_lambda=float(lam)))

    def HP(self):
        self.H(pilot=True)

    def D1(self):
        """Diagnostic: same model scored on held-out flows of SEEN attacker hosts and on the unseen
        hosts of p1B (symdig/diag.py). Untuned defaults, like the HP pilot."""
        for d in self.ds(self.e.get("d1_datasets", ["ids2018", "ton", "unsw"])):
            p = self.prep(d)
            for s in self.seeds(d)[: int(self.e.get("d1_seeds", 3))]:
                self.add(spec("D1", "diag_host", d, after=[p], split="p1B", task="multi", seed=s,
                              variants=["gnn_plain", "flow_plain"], xgboost=True))

    def X1(self):
        """Endpoint scoring (ES): the sampler of rung 1 (asymmetric) or rung 2 (coupled) WITHOUT target
        forcing, and every target scored from the embeddings of its endpoints plus its own attributes
        (the design of our earlier DiG-RSB pipeline). Everything else as E2. The ES switch is a spec
        override (model.score_all), so the hashed ladder and every E2 job id stay unchanged."""
        x = self.e.get("x1", {}) or {}
        for d in self.ds(x.get("datasets", self.e["datasets"])):
            p = self.prep(d)
            for rung in x.get("rungs", [1, 2]):
                for s in self.seeds(d):
                    self.add(spec("X1", "gnn", d, after=[p], model=f"ladder{rung}", split="p1A", task="multi",
                                  seed=s, overrides={"model.force": False, "model.score_all": True}))

    def SC(self):
        """Full-graph E-GraphSAGE (whole graph and all training targets per step, uncapped, GPU to itself)
        vs E-GraphSAGE + C3S (mini-batches, 16 GB cap) on the same stratified fractions of p1A."""
        x = self.e.get("sc", {}) or {}
        for d in self.ds(x.get("datasets", ["unsw", "ton", "ids2018", "bot"])):
            p = self.prep(d)
            for f in x.get("fracs", [0.02, 0.1, 0.5, 1.0]):
                for s in x.get("seeds", [0]):
                    for cap in x.get("fullgraph_caps_gb", [None]):
                        self.add(spec("SC", "scale", d, after=[p], model="egsage", split="p1A", task="multi",
                                      seed=s, mode="fullgraph", frac=float(f), mem_cap_gb=cap))
                    self.add(spec("SC", "scale", d, after=[p], model="egsage", split="p1A", task="multi",
                                  seed=s, mode="c3s", frac=float(f), mem_cap_gb=x.get("c3s_cap_gb", 16)))

    def R1(self):
        """Re-evaluate every E1/E2 checkpoint with randomly ordered evaluation batches."""
        before = list(self.specs)
        self.specs = []
        self.E1()
        self.E2()
        srcs = [s for s in self.specs if s["kind"] == "gnn"]
        self.specs = before
        for s in srcs:
            sid = job_id(s)
            self.add(spec("R1", "reeval", s["dataset"], after=[sid], source_job=sid))

    def B0(self):
        """Untuned per-flow baselines on p1A (sets the bar before tuning)."""
        for d in self.ds(self.e["datasets"]):
            p = self.prep(d)
            for m in ("xgboost", "mlp"):
                for s in self.seeds(d)[:3]:
                    self.add(spec("B0", "tabular", d, after=[p], model=m, split="p1A", task="multi", seed=s,
                                  tuned=None, overrides={}))

    def tune_all(self):
        for m in self.e["e4_models"]:
            kind = self.cfg["models"][m]["kind"]
            for d in self.ds(self.cfg["tuning"]["gnn_datasets" if kind == "gnn" else "datasets"]):
                self.tune(m, d)

    def plan(self, exps):
        for x in exps:
            if x == "tune":
                self.tune_all()
            else:
                getattr(self, x)()
        return self.specs


def smoke_config(cfg):
    """Tiny version of every experiment (minutes): use with --results results_smoke."""
    c = copy.deepcopy(cfg)
    c["data"]["max_rows"] = 200_000
    c["data"]["val_max"] = 2_000
    c["train"].update(epochs=2, max_steps_per_epoch=3, batch_size=512, eval_batch_size=4096, patience=2, log_every=1)
    c["model"]["hidden"] = 32
    c["sampler"]["fanout"] = [5, 5]
    c["multignn_paper"]["sampler"] = {"fanout": [10, 10]}
    c["multignn_paper"]["model"]["hidden"] = 32
    c["tuning"].update(trials=2, gnn_epochs=1, gnn_steps=2)
    c["motif"].update(n_nodes=500, multiplicities=[1, 16])
    for k in ("xgboost", "rf"):
        c["tabular_defaults"][k]["n_estimators"] = 20
    c["tabular_defaults"]["mlp"].update(epochs=2, steps_per_epoch=5)
    c["fecograph"].update(epochs=20, eval_every=5, patience=2)
    e = c["experiments"]
    e.update(seeds=[0], seeds_large=[0], e1_fanouts=[[5, 5]], e1_batches=3, e3_seeds=[0], e6_fracs=[0.1, 1.0],
             e6_profile_steps=3, e6_mem_caps_gb=[None], e7_k=[0, 2], e4_p2_datasets=["ton"])
    c["protocols"]["p2"]["sample_frac"] = 0.2
    return c
