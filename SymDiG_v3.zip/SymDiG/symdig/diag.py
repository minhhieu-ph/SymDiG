"""Diagnostic D1: does a model fail on unseen attacker hosts because the hosts are new, or because
its pipeline is broken for those classes?

Same model, same training run, two test sets on the attacker-disjoint split p1B:
  seen   = a stratified random 5 % (at most 300k flows) of the training targets, held out from the
           loss before training. Their hosts ARE in training; their edges stay in the graph for
           message passing (unlabelled), exactly like validation flows.
  unseen = the p1B test set (attacker hosts never seen in training).
For the GNN the unseen set is also scored with less graph context:
  ctx=train  neighbours sampled from the training graph only (test flows do not see other test
             flows, except targets in the same batch);
  ctx=none   no sampled neighbours (the batch's targets only).

Reading: a class with high F1 on `seen` and low F1 on `unseen` is learned, but tied to its
training hosts. If the GNN's unseen F1 recovers with ctx=none, the sampled graph context of the
new hosts is what misleads it. Models: the plain GNN (sampler fix, no HINT), the plain flow
network, and XGBoost; all with default (untuned) hyper-parameters, like the HP pilot.
"""
import copy

import numpy as np

from .data import Split, _strat, get_split, NetFlowData
from .hostnorm import host_recall, make_stores
from .metrics import classification_metrics


def seen_holdout(y, train, seed, frac=0.05, cap=300_000):
    rng = np.random.default_rng(seed + 11)
    f = min(frac, cap / max(len(train), 1))
    seen = np.sort(_strat(y, np.asarray(train, np.int64), f, rng, min_keep=1))
    return seen, np.setdiff1d(train, seen, assume_unique=False)


def _tabular(c, data, split, seen, seed, log, override=None):
    from .tabular import fit_predict
    store, store_te = make_stores(c, data, split, "none")
    tr, va, te = np.sort(split.train), np.sort(split.val), np.sort(split.test)
    Xtr, ytr = store.gather(tr), data.y[tr]
    Xva, yva = store.gather(va), data.y[va]
    ev = np.concatenate([te, seen])
    Xev = store_te.gather(ev)
    params = dict(c["tabular_defaults"]["xgboost"])
    params.update(override or {})
    pev, _, _, info = fit_predict("xgboost", params, Xtr, ytr, Xva, yva, Xev, data.n_classes, seed,
                                  int(c["runtime"].get("threads", 4)), log)
    out = {}
    for name, ids, p in (("unseen", te, pev[: len(te)]), ("seen", seen, pev[len(te):])):
        yy = data.y[ids]
        out[name] = {"context": "flow", "n": int(len(ids)), "metrics": classification_metrics(yy, p, data.classes),
                     "host_recall": host_recall(yy, p.argmax(1), data.src[ids])}
        log(f"  xgboost {name}: macro-F1 {out[name]['metrics']['macro_f1']:.4f}")
    return out


def run_diag_host(cfg, spec, root, log):
    from .hint import run_hint
    from .hint_spec import resolve_hp, variant_spec
    c = copy.deepcopy(cfg)
    c["train"]["num_workers"] = int(c["runtime"].get("num_workers", 2))
    data = NetFlowData(c, spec["dataset"], task="multi")
    split = get_split(c, data, spec.get("split", "p1B"))
    seed = int(spec["seed"])
    seen, tr2 = seen_holdout(data.y, split.train, seed)
    sp2 = Split(split.name, tr2, split.val, split.test, split.graph_train, split.graph_test, split.meta)
    log(f"  D1: {len(seen):,} seen-host flows held out of {len(split.train):,} training targets; "
        f"unseen-host test {len(split.test):,}")
    te = np.sort(split.test)
    out = {"n_seen": int(len(seen)), "n_unseen": int(len(te)), "models": {}, "classes": data.classes,
           "split_meta": split.meta}
    for v in spec.get("variants", ["gnn_plain", "flow_plain"]):
        _, hint = variant_spec(v)
        hp = resolve_hp({"hint": hint}, root)
        hp.update(spec.get("hp_override") or {})          # scripts/check_hint.py: tiny runs
        graph = bool(hp["graph"])
        extra = [("seen", seen, "full")] + ([("unseen_ctx_train", te, "train"), ("unseen_ctx_none", te, "none")]
                                            if graph else [])
        r = run_hint(c, data, sp2, seed, hp, log, probe=False, extra_eval=extra)
        m = {"unseen": {"context": "full", "n": int(len(te)), "metrics": r["metrics"], "host_recall": r["host_recall"]}}
        m.update(r["extra"])
        out["models"][v] = m
    if spec.get("xgboost", True):
        out["models"]["xgboost"] = _tabular(c, data, sp2, seen, seed, log, spec.get("xgb_override"))
    return out
