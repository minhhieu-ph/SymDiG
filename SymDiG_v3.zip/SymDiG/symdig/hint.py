"""HINT: host-invariant training for flow-based NIDS.

Problem (measured in E5/E8): models trained on a random split learn WHO the attacker is, not what
the attack looks like; on an attacker-disjoint split every model loses 10-50 macro-F1 points and
graph context makes it worse. HINT borrows the speech-recognition answer to speaker memorisation:

  1. per-host normalisation  (per-speaker CMVN)              symdig/hostnorm.py
  2. encoder: edge GNN with forced targets (graph=True) or a flow network (MLP / FT-Transformer)
  3. adversarial host head    (speaker-adversarial training / DANN): a classifier predicts the
                              source host from the representation through a gradient-reversal
                              layer, so the encoder is pushed to drop host identity
  4. GroupDRO over source hosts: the classification loss is weighted towards the hardest hosts

Every component can be switched off (hp keys hostnorm / adv_lambda / dro / graph), so the plain
GNN and MLP baselines and all ablations run through the same code path. Model selection uses the
validation part of the split; with split p1H that validation set is attacker-disjoint as well.

hp (defaults in DEFAULTS; a job's spec["hint"] = {"base": {...}, "force": {...}}; tuned values are
applied between base and force, so ablation switches always win):
  graph, hostnorm (none|both|only), adv_lambda, dro, dro_eta, K (host buckets), encoder (mlp|ftt),
  hidden, layers, dropout, lr, weight_decay, epochs, steps, batch, patience, d_token, blocks,
  heads, loss_power, probe_n
"""
import copy
import json
import math
import os
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .data import NetFlowData, get_split, graph_for
from .hostnorm import host_recall, make_stores
from .loader import SubgraphBatches, make_loader, to_device
from .metrics import classification_metrics
from .models import build_model
from .trainer import autocast, class_weights, get_device, predict, set_seed

from .hint_spec import DEFAULTS, VARIANTS, resolve_hp, variant_spec  # noqa: F401


# ----------------------------------------------------------------------------- building blocks
def host_buckets(data, train_ids, K):
    """Source host -> bucket id: the K source hosts with most training flows get their own
    bucket, all other hosts share bucket `n_top` ('other'). Returns (bucket per node, n_buckets)."""
    src = data.src[np.asarray(train_ids, np.int64)]
    hosts, cnt = np.unique(src, return_counts=True)
    top = hosts[np.argsort(-cnt, kind="stable")[:int(K)]]
    b = np.full(data.num_nodes, len(top), np.int64)
    b[top] = np.arange(len(top))
    return b, len(top) + 1


class _GRL(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lam):
        ctx.lam = lam
        return x.view_as(x)

    @staticmethod
    def backward(ctx, g):
        return -ctx.lam * g, None


class HostHead(nn.Module):
    def __init__(self, d, n):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(d, 128), nn.ReLU(), nn.Linear(128, n))

    def forward(self, h, lam):
        return self.net(_GRL.apply(h, lam))


class GroupDRO:
    """Online GroupDRO (Sagawa et al.): exponentiated-gradient weights over groups."""

    def __init__(self, n, eta, device):
        self.q = torch.ones(n, device=device) / n
        self.eta = float(eta)

    def loss(self, per_sample, groups):
        n = self.q.numel()
        sums = torch.zeros(n, device=per_sample.device).index_add_(0, groups, per_sample)
        cnts = torch.zeros(n, device=per_sample.device).index_add_(0, groups, torch.ones_like(per_sample))
        present = cnts > 0
        gl = sums[present] / cnts[present]
        with torch.no_grad():
            self.q[present] = self.q[present] * torch.exp(self.eta * gl.detach())
            self.q /= self.q.sum()
        qp = self.q[present]
        return (qp * gl).sum() / qp.sum()


class FlowNet(nn.Module):
    """Per-flow encoder: MLP or FT-Transformer (feature tokenizer + Transformer, CLS readout)."""

    def __init__(self, d_in, n_classes, encoder="mlp", hidden=128, layers=2, dropout=0.2, d_token=32, blocks=2,
                 heads=4):
        super().__init__()
        self.encoder = encoder
        if encoder == "mlp":
            mods, d = [], d_in
            for _ in range(int(layers)):
                mods += [nn.Linear(d, hidden), nn.BatchNorm1d(hidden), nn.ReLU(), nn.Dropout(dropout)]
                d = hidden
            self.enc = nn.Sequential(*mods)
            d_enc = hidden
        elif encoder == "ftt":
            self.tok_w = nn.Parameter(torch.randn(d_in, d_token) * d_token ** -0.5)
            self.tok_b = nn.Parameter(torch.zeros(d_in, d_token))
            self.cls_tok = nn.Parameter(torch.zeros(1, 1, d_token))
            layer = nn.TransformerEncoderLayer(d_token, heads, 2 * d_token, dropout, batch_first=True, norm_first=True)
            self.tr = nn.TransformerEncoder(layer, int(blocks), enable_nested_tensor=False)
            self.norm = nn.LayerNorm(d_token)
            d_enc = d_token
        else:
            raise ValueError(encoder)
        self.hid = nn.Sequential(nn.Linear(d_enc, hidden // 2), nn.ReLU(), nn.Dropout(dropout))
        self.out = nn.Linear(hidden // 2, n_classes)
        self.hid_dim = hidden // 2

    def forward(self, x):
        if self.encoder == "mlp":
            e = self.enc(x)
        else:
            t = x.unsqueeze(-1) * self.tok_w + self.tok_b
            t = torch.cat([self.cls_tok.expand(len(x), -1, -1), t], 1)
            e = self.norm(self.tr(t)[:, 0])
        h = self.hid(e)
        return {"logits": self.out(h), "hid": h}


class FlowBatches(torch.utils.data.Dataset):
    """Random mini-batches of training flows (features gathered in DataLoader workers)."""

    def __init__(self, store, labels, targets, batch, seed, epoch, max_batches):
        t = np.random.default_rng([int(seed), int(epoch), 11]).permutation(np.asarray(targets, np.int64))
        self.chunks = [t[i:i + batch] for i in range(0, len(t), batch)][:max_batches]
        self.store, self.labels = store, labels

    def __len__(self):
        return len(self.chunks)

    def __getitem__(self, i):
        ids = self.chunks[i]
        return {"x": torch.from_numpy(self.store.gather(ids)), "y": torch.from_numpy(self.labels[ids].astype(np.int64)),
                "targets": torch.from_numpy(ids)}


@torch.no_grad()
def predict_flow(model, store, ids, device, amp=True, bs=65536, return_hid=False):
    model.eval()
    ids = np.sort(np.asarray(ids, np.int64))
    P, H = [], []
    for i in range(0, len(ids), bs):
        x = torch.from_numpy(store.gather(ids[i:i + bs])).to(device)
        with autocast(amp, device):
            out = model(x)
        P.append(torch.softmax(out["logits"].float(), 1).cpu().numpy())
        if return_hid:
            H.append(out["hid"].float().cpu().numpy())
    P = np.concatenate(P) if P else np.zeros((0, 1), np.float32)
    return (P, np.concatenate(H)) if return_hid else P


def host_probe(H, grp, other, seed, n=60000):
    """Linear probe: how well can the source host be read off a representation?
    Accuracy on held-out flows of the same hosts vs. the majority-host baseline."""
    from sklearn.linear_model import LogisticRegression
    idx = np.flatnonzero(grp != other)
    if len(idx) < 100 or len(np.unique(grp[idx])) < 2:
        return None
    rng = np.random.default_rng(seed)
    idx = rng.permutation(idx)[:int(n)]
    cut = int(0.8 * len(idx))
    a, b = idx[:cut], idx[cut:]
    mu, sd = H[a].mean(0), H[a].std(0) + 1e-6
    clf = LogisticRegression(max_iter=300)
    clf.fit((H[a] - mu) / sd, grp[a])
    acc = float((clf.predict((H[b] - mu) / sd) == grp[b]).mean())
    mode = np.bincount(grp[a]).argmax()
    return {"acc": acc, "majority": float((grp[b] == mode).mean()), "n_hosts": int(len(np.unique(grp[idx]))),
            "n": int(len(idx))}


# ----------------------------------------------------------------------------- training
def run_hint(c, data, split, seed, hp, log=print, probe=True, evaluate_test=True, extra_eval=None):
    """extra_eval: optional [(name, flow ids, context)] scored after the test set with the selected
    model (diagnostic D1). context (graph models only): "full" = the test graph, as for the test set;
    "train" = neighbours sampled from the training graph only (test flows do not see other test flows,
    except targets in the same batch); "none" = no sampled neighbours (the batch's targets only)."""
    set_seed(seed)
    device = get_device()
    t = c["train"]
    amp = bool(t.get("amp", True))
    C = data.n_classes
    tr = np.asarray(split.train, np.int64)
    st_tr, st_te = make_stores(c, data, split, hp["hostnorm"])
    buckets, nb = host_buckets(data, tr, hp["K"])
    other = nb - 1
    counts = np.bincount(data.y[tr], minlength=C)
    w = class_weights(counts, "wce", float(hp["loss_power"]))
    w = w.to(device) if w is not None else None

    graph = bool(hp["graph"])
    if graph:
        mcfg = {"arch": "hetero", "coupled": True, "force": True, "conv": "gine", "hidden": int(hp["hidden"]),
                "layers": int(hp["layers"]), "dropout": float(hp["dropout"])}
        model = build_model(mcfg, st_tr.dim, C).to(device)
        hid_dim = model.cls[3].out_features
        mode = {"coupled": True, "force": True}
        g_tr = graph_for(data, split, "train")
    else:
        model = FlowNet(st_tr.dim, C, hp["encoder"], int(hp["hidden"]), int(hp["layers"]), float(hp["dropout"]),
                        int(hp["d_token"]), int(hp["blocks"]), int(hp["heads"])).to(device)
        hid_dim = model.hid_dim
        mode, g_tr = None, None
    lam_max = float(hp["adv_lambda"])
    head = HostHead(hid_dim, nb).to(device) if lam_max > 0 else None
    params = list(model.parameters()) + (list(head.parameters()) if head is not None else [])
    opt = torch.optim.AdamW(params, lr=float(hp["lr"]), weight_decay=float(hp["weight_decay"]))
    dro = GroupDRO(nb, hp["dro_eta"], device) if hp["dro"] else None
    epochs, steps, bs = int(hp["epochs"]), int(hp["steps"]), int(hp["batch"])
    total = max(1, epochs * steps)
    log(f"  HINT: graph={graph} hostnorm={hp['hostnorm']} adv_lambda={lam_max} dro={bool(hp['dro'])} "
        f"encoder={'gnn' if graph else hp['encoder']} | train {len(tr):,} | host buckets {nb} | d_in {st_tr.dim}")

    def evaluate(ids, store, g, with_hid=False):
        if graph:
            out = predict(model, g, store, data.y, ids, mode, c, seed, return_hid=with_hid)
            return (out[0], out[3]) if with_hid else out[0]
        return predict_flow(model, store, ids, device, amp, return_hid=with_hid)

    step, best, best_state, bad, curve = 0, -1.0, None, 0, []
    t_start = time.time()
    for ep in range(epochs):
        model.train()
        if head is not None:
            head.train()
        if graph:
            ds = SubgraphBatches(g_tr, st_tr, data.y, tr, bs, mode, c["sampler"], shuffle=True, seed=seed, epoch=ep,
                                 max_batches=steps)
        else:
            ds = FlowBatches(st_tr, data.y, tr, bs, seed, ep, steps)
        losses, adv_acc = [], []
        for b in make_loader(ds, int(t.get("num_workers", 2))):
            if graph:
                pt = b["targets"].numpy()[b["present"].numpy()]
                if len(pt) == 0:
                    continue
                y = b["y"].to(device)
                inp = to_device(b, device)
            else:
                pt = b["targets"].numpy()
                y = b["y"].to(device)
                inp = b["x"].to(device)
            grp = torch.from_numpy(buckets[data.src[pt]]).to(device)
            with autocast(amp, device):
                out = model(inp)
            logits, hid = out["logits"].float(), out["hid"].float()
            if dro is not None:
                loss = dro.loss(F.cross_entropy(logits, y, weight=w, reduction="none"), grp)
            else:
                loss = F.cross_entropy(logits, y, weight=w)
            if head is not None:
                p = step / total
                lam = lam_max * (2.0 / (1.0 + math.exp(-10.0 * p)) - 1.0)     # DANN schedule
                hl = head(hid, lam)
                loss = loss + F.cross_entropy(hl, grp)
                adv_acc.append(float((hl.argmax(1) == grp).float().mean()))
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, float(t.get("grad_clip", 1.0)))
            opt.step()
            step += 1
            losses.append(loss.item())
        pv = evaluate(split.val, st_tr, g_tr)
        yv = data.y[np.sort(split.val)]
        ok = ~np.isnan(pv[:, 0])
        f1 = classification_metrics(yv[ok], pv[ok], data.classes)["macro_f1"] if ok.any() else -1.0
        curve.append({"epoch": ep + 1, "loss": float(np.mean(losses)) if losses else None, "val_macro_f1": f1,
                      "adv_host_acc": float(np.mean(adv_acc)) if adv_acc else None})
        log(f"  epoch {ep + 1:3d} | loss {curve[-1]['loss'] or float('nan'):.4f} | val macro-F1 {f1:.4f}"
            + (f" | adversary host acc {curve[-1]['adv_host_acc']:.3f}" if adv_acc else ""))
        if f1 > best + 1e-4:
            best, bad = f1, 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            bad += 1
            if bad >= int(hp["patience"]):
                log(f"  early stop at epoch {ep + 1}")
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    res = {"val_best_macro_f1": best, "curve": curve, "train_sec": time.time() - t_start, "steps": step,
           "n_host_buckets": int(nb)}
    if not evaluate_test:
        return res

    te = np.sort(np.asarray(split.test, np.int64))
    g_te = graph_for(data, split, "test") if graph else None
    pt_ = evaluate(te, st_te, g_te)
    yt = data.y[te]
    ok = ~np.isnan(pt_[:, 0])
    res["metrics"] = classification_metrics(yt[ok], pt_[ok], data.classes)
    res["host_recall"] = host_recall(yt[ok], pt_[ok].argmax(1), data.src[te][ok])
    res["classes"] = data.classes
    res["n_train"], res["n_test"] = int(len(tr)), int(len(te))
    log(f"  test macro-F1 {res['metrics']['macro_f1']:.4f}"
        + (f" | worst-host recall p10 {res['host_recall']['p10']:.3f}" if res["host_recall"] else ""))

    if extra_eval:
        res["extra"] = {}
        c_none = copy.deepcopy(c)
        c_none["sampler"]["fanout"] = []
        for name, ids, ctx in extra_eval:
            ids = np.sort(np.asarray(ids, np.int64))
            if graph:
                g = g_tr if ctx == "train" else g_te
                pr, cov, _ = predict(model, g, st_te, data.y, ids, mode, c_none if ctx == "none" else c, seed)
            else:
                pr, cov = predict_flow(model, st_te, ids, device, amp), 1.0
            yy = data.y[ids]
            okx = ~np.isnan(pr[:, 0])
            res["extra"][name] = {"context": ctx, "coverage": float(cov), "n": int(len(ids)),
                                  "metrics": classification_metrics(yy[okx], pr[okx], data.classes),
                                  "host_recall": host_recall(yy[okx], pr[okx].argmax(1), data.src[ids][okx])}
            log(f"  {name} ({ctx} context): macro-F1 {res['extra'][name]['metrics']['macro_f1']:.4f} on {len(ids):,} flows")

    if probe:
        rng = np.random.default_rng(seed + 7)
        cand = tr[buckets[data.src[tr]] != other]
        sample = np.sort(rng.choice(cand, min(int(hp["probe_n"]), len(cand)), replace=False)) if len(cand) else cand
        if len(sample):
            grp_s = buckets[data.src[sample]]
            _, Hs = evaluate(sample, st_tr, g_tr, with_hid=True)
            okh = ~np.isnan(Hs[:, 0])
            res["probe_hid"] = host_probe(Hs[okh], grp_s[okh], other, seed, hp["probe_n"])
            res["probe_input"] = host_probe(st_tr.gather(sample), grp_s, other, seed, hp["probe_n"])
            if res["probe_hid"]:
                log(f"  host probe: representation {res['probe_hid']['acc']:.3f} | input "
                    f"{(res['probe_input'] or {}).get('acc', float('nan')):.3f} | majority {res['probe_hid']['majority']:.3f}")
    return res


# ----------------------------------------------------------------------------- jobs
def _setup(cfg, spec):
    c = copy.deepcopy(cfg)
    c["train"]["num_workers"] = int(c["runtime"].get("num_workers", 2))
    data = NetFlowData(c, spec["dataset"], task=spec.get("task", "multi"))
    split = get_split(c, data, spec["split"])
    return c, data, split


def run_hint_job(cfg, spec, root, log):
    c, data, split = _setup(cfg, spec)
    hp = resolve_hp(spec, root)
    res = run_hint(c, data, split, int(spec["seed"]), hp, log)
    res["hp"] = hp
    res["split_meta"] = split.meta
    return res


def tune_hint(cfg, spec, root, log):
    """Equal-budget Optuna search (tuning.trials) on the split's validation part; shortened
    schedule (tuning.gnn_epochs x tuning.gnn_steps), as for every other model."""
    from .tuning import _RandomTrial, _suggest_optuna
    c, data, split = _setup(cfg, spec)
    base = dict(DEFAULTS)
    base.update((spec.get("hint") or {}).get("base") or {})
    base.update((spec.get("hint") or {}).get("force") or {})
    space = {"lr": ("logfloat", 1e-4, 3e-3), "hidden": ("cat", [64, 128, 256]), "dropout": ("float", 0.0, 0.4)}
    if float(base["adv_lambda"]) > 0:
        space["adv_lambda"] = ("logfloat", 0.01, 1.0)
    if base["dro"]:
        space["dro_eta"] = ("logfloat", 1e-3, 0.1)
    tcfg = cfg["tuning"]
    history = []

    def objective(sample):
        hp = dict(base)
        for k, s in space.items():
            hp[k] = sample(k, s)
        hp.update(epochs=int(tcfg["gnn_epochs"]), steps=int(tcfg["gnn_steps"]), patience=3)
        t0 = time.time()
        r = run_hint(c, data, split, 0, hp, log=lambda *_: None, probe=False, evaluate_test=False)
        history.append({"score": r["val_best_macro_f1"], "sec": time.time() - t0})
        log(f"  [tune {spec['tune_key']}] trial {len(history)}: val macro-F1 {r['val_best_macro_f1']:.4f}")
        return r["val_best_macro_f1"]

    n = int(spec.get("trials", tcfg["trials"]))
    try:
        import optuna
        optuna.logging.set_verbosity(optuna.logging.WARNING)
        study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=0))
        study.optimize(lambda tr: objective(lambda k, s: _suggest_optuna(tr, k, s)), n_trials=n)
        best, best_score = dict(study.best_params), study.best_value
    except ImportError:
        rng = np.random.default_rng(0)
        best, best_score = None, -1.0
        for _ in range(n):
            trial = _RandomTrial(rng)
            sc = objective(trial.suggest)
            if sc > best_score:
                best, best_score = dict(trial.params), sc
    out = {"tune_key": spec["tune_key"], "best_params": best, "best_val_macro_f1": best_score, "trials": history}
    os.makedirs(os.path.join(root, "tuned"), exist_ok=True)
    f = os.path.join(root, "tuned", f"{spec['tune_key']}.json")
    with open(f + ".tmp", "w") as fh:
        json.dump(out, fh, indent=1)
    os.replace(f + ".tmp", f)
    return out
