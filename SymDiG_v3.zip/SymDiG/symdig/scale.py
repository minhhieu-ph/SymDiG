"""SC: the coverage-scale trade-off, measured.

Full-graph pipelines (E-GraphSAGE and the line-graph / contrastive models built on it) score every
target, but hold the whole graph and every training target in GPU memory at each step; to fit a
GPU they train on a subsample of the flows (2-10 % in the papers we audit). C3S scores every target
with mini-batches, so its memory does not grow with the dataset. Same backbone (E-GraphSAGE on
IP:PORT nodes), same untuned hyper-parameters, same stratified data fractions:

  mode=fullgraph  full-batch training on the whole training graph (loss on all training targets at
                  every step, validation every `eval_every` steps, early stopping on validation
                  macro-F1), full-graph inference on the test graph.
  mode=c3s        the mini-batch trainer (trainer.train_and_evaluate) with the coupled, forced
                  sampler: the E-GraphSAGE backbone with C3S.

Recorded: status (ok / OOM and the stage that ran out of memory), peak GPU memory, seconds per
step, training time and test macro-F1. A full-graph run is uncapped and has the GPU to itself, so
its peak memory says directly whether it would fit a 16 GB or 40 GB card; a run can also be capped
explicitly (spec mem_cap_gb), in which case running out of memory is the result.
"""
import time

import numpy as np

from .data import get_split, graph_for, subset_split
from .metrics import classification_metrics


def _is_oom(ex):
    import torch
    return isinstance(ex, torch.cuda.OutOfMemoryError) or "out of memory" in str(ex).lower()


def _gather(store, eids, chunk=2_000_000):
    """All edge features of a graph, gathered in chunks (bounded float64 temporaries)."""
    out = np.empty((len(eids), store.dim), np.float32)
    for i in range(0, len(eids), chunk):
        out[i:i + chunk] = store.gather(eids[i:i + chunk])
    return out


def full_batch(data, store, eids):
    """The whole graph induced by `eids` as one batch dict for EdgeGNN.forward (targets set later)."""
    import torch
    eids = np.sort(np.asarray(eids, np.int64))
    s, t = data.src[eids], data.dst[eids]
    nodes = np.unique(np.concatenate([s, t]))
    ei = np.stack([np.searchsorted(nodes, s), np.searchsorted(nodes, t)])
    n = len(nodes)
    x_node = np.zeros((n, 2), np.float32)
    x_node[:, 0] = 1.0
    ei_t = torch.from_numpy(ei)
    return {"num_nodes": n, "x_node": torch.from_numpy(x_node), "ei_f": ei_t, "ei_r": ei_t.flip(0),
            "xf": torch.from_numpy(_gather(store, eids)), "shared": True}, eids


def _probs(model, b, tpos, amp, dev):
    import torch
    from .trainer import autocast
    model.eval()
    with torch.no_grad(), autocast(amp, dev):
        out = model(dict(b, tpos=tpos))
    return torch.softmax(out["logits"].float(), 1).cpu().numpy()


def run_fullgraph(c, data, split, seed, log, out, steps=300, eval_every=10, patience=5, max_minutes=120):
    """Fills `out` as it goes, so the stage that ran out of memory survives the exception."""
    import torch
    import torch.nn.functional as F
    from .hardware import peak_vram_gb, reset_peak
    from .models import build_model
    from .trainer import autocast, class_weights, get_device, set_seed, to_device
    set_seed(seed)
    dev = get_device()
    t = c["train"]
    amp = t["amp"]
    out["stage"] = "load"
    store = data.make_store(split.graph_train, c["data"].get("ports", True), seed=0)
    reset_peak()
    t0 = time.time()
    b, eids = full_batch(data, store, split.graph_train)
    out["graph_train"] = {"nodes": int(b["num_nodes"]), "edges": int(len(eids))}
    tr, va = np.sort(split.train), np.sort(split.val)
    tp_tr = torch.from_numpy(np.searchsorted(eids, tr))
    tp_va = torch.from_numpy(np.searchsorted(eids, va))
    y_tr = torch.from_numpy(data.y[tr].astype(np.int64))
    model = build_model(c["model"], store.dim, data.n_classes).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=float(t["lr"]), weight_decay=float(t["weight_decay"]))
    w = class_weights(np.bincount(data.y[tr], minlength=data.n_classes), t["loss"], float(t.get("loss_power", 0.5)))
    w = w.to(dev) if w is not None else None
    b = to_device(b, dev)
    tp_tr, tp_va, y_tr = tp_tr.to(dev), tp_va.to(dev), y_tr.to(dev)
    out["load_sec"] = time.time() - t0
    out["stage"] = "train"
    best, best_f1, bad, step_times, curve = None, -1.0, 0, [], []
    t_train = time.time()
    for step in range(1, int(steps) + 1):
        model.train()
        t1 = time.time()
        with autocast(amp, dev):
            logits = model(dict(b, tpos=tp_tr))["logits"]
        loss = F.cross_entropy(logits.float(), y_tr, weight=w)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), float(t["grad_clip"]))
        opt.step()
        if dev.type == "cuda":
            torch.cuda.synchronize()
        step_times.append(time.time() - t1)
        del logits
        if step % int(eval_every) == 0 or step == int(steps):
            pv = _probs(model, b, tp_va, amp, dev)
            f1 = classification_metrics(data.y[va], pv, data.classes)["macro_f1"]
            curve.append([step, float(loss.item()), float(f1)])
            log(f"  full-graph step {step:4d} | loss {loss.item():.4f} | val macro-F1 {f1:.4f} | "
                f"{np.mean(step_times[-eval_every:]):.2f}s/step | VRAM {peak_vram_gb() or 0:.1f} GB")
            if f1 > best_f1 + 1e-4:
                best_f1, bad = f1, 0
                best = {k: v.detach().clone() for k, v in model.state_dict().items()}
            else:
                bad += 1
                if bad >= int(patience):
                    log(f"  early stop at step {step}")
                    break
        if time.time() - t_train > 60 * float(max_minutes):
            log(f"  time budget of {max_minutes} min reached at step {step}")
            out["time_budget_hit"] = True
            break
    out.update(steps=len(step_times), sec_per_step=float(np.mean(step_times)), train_sec=time.time() - t_train,
               val_best_macro_f1=best_f1, curve=curve, peak_vram_train_gb=peak_vram_gb())
    if best is not None:
        model.load_state_dict(best)
    # inference on the test graph (all flows; test targets unlabelled in message passing)
    out["stage"] = "eval"
    del b, opt
    if dev.type == "cuda":
        torch.cuda.empty_cache()
    t2 = time.time()
    bt, eids_te = full_batch(data, store, split.graph_test)
    te = np.sort(split.test)
    tp_te = torch.from_numpy(np.searchsorted(eids_te, te)).to(dev)
    bt = to_device(bt, dev)
    pt = _probs(model, bt, tp_te, amp, dev)
    out["test_inference_sec"] = time.time() - t2
    out["metrics"] = classification_metrics(data.y[te], pt, data.classes)
    out["graph_test"] = {"nodes": int(bt["num_nodes"]), "edges": int(len(eids_te))}
    out["stage"] = "done"


def run_scale(cfg, spec, root, log):
    import torch
    from .executors import _data, resolve
    from .trainer import get_device, train_and_evaluate
    c = resolve(cfg, spec, root)
    data = _data(c, spec)
    split = get_split(c, data, "p1A")
    frac = float(spec.get("frac", 1.0))
    if frac < 1.0:
        split = subset_split(split, frac, data.y_multi, seed=0)
    dev = get_device()
    cap = spec.get("mem_cap_gb")
    mode = spec["mode"]
    out = {"mode": mode, "frac": frac, "mem_cap_gb": cap, "model": spec.get("model"),
           "n_train": int(len(split.train)), "n_test": int(len(split.test)),
           "n_graph_train": int(len(split.graph_train)),
           "gpu_name": torch.cuda.get_device_name(0) if dev.type == "cuda" else "cpu",
           "gpu_total_gb": torch.cuda.get_device_properties(0).total_memory / 2 ** 30 if dev.type == "cuda" else None}
    if cap and dev.type == "cuda":
        torch.cuda.set_per_process_memory_fraction(min(1.0, float(cap) / out["gpu_total_gb"]))
    log(f"  SC {mode} | frac {frac} | cap {cap} GB | train targets {out['n_train']:,} | "
        f"train graph {out['n_graph_train']:,} edges")
    sc = (cfg.get("experiments") or {}).get("sc", {}) or {}
    try:
        if mode == "fullgraph":
            run_fullgraph(c, data, split, int(spec.get("seed", 0)), log, out,
                          steps=int(spec.get("steps", sc.get("steps", 300))),
                          eval_every=int(sc.get("eval_every", 10)), patience=int(sc.get("patience", 5)),
                          max_minutes=float(sc.get("max_minutes", 120)))
            out["status"] = "ok"
        elif mode == "c3s":
            r, _, _ = train_and_evaluate(c, data, split, int(spec.get("seed", 0)), log=log)
            hw = r["hardware"]
            out.update(metrics=r["metrics"], val_best_macro_f1=r["val_best_macro_f1"], steps=hw["steps"],
                       sec_per_step=hw["sec_per_step"], train_sec=hw["sec_per_step"] * hw["steps"],
                       epochs_run=hw.get("epochs_run"), peak_vram_train_gb=hw.get("peak_vram_gb"),
                       test_inference_sec=hw.get("test_inference_sec"), graph_train=r.get("graph_train"))
            out["status"] = "ok"
        else:
            raise ValueError(f"unknown SC mode {mode}")
    except (RuntimeError, MemoryError) as ex:   # running out of memory is a result, not a failure
        if isinstance(ex, RuntimeError) and not _is_oom(ex):
            raise
        out["status"] = "OOM"
        out["oom_stage"] = out.get("stage", "train")
        out["oom_message"] = str(ex)[:300]
        log(f"  OOM: {str(ex)[:200]}")
    finally:
        if dev.type == "cuda":
            out["peak_vram_gb"] = torch.cuda.max_memory_allocated() / 2 ** 30
            out["peak_reserved_gb"] = torch.cuda.max_memory_reserved() / 2 ** 30
            if cap:
                torch.cuda.set_per_process_memory_fraction(1.0)
            torch.cuda.empty_cache()
    m = out.get("metrics")
    log(f"  SC {mode} frac {frac}: {out['status']}" + (f" ({out['oom_stage']})" if out["status"] == "OOM" else "")
        + (f" | test macro-F1 {m['macro_f1']:.4f}" if m else "")
        + (f" | peak VRAM {out['peak_vram_gb']:.1f} GB" if out.get("peak_vram_gb") is not None else ""))
    return out
